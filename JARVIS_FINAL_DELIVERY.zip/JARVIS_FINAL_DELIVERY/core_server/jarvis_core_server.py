#!/usr/bin/env python3
"""Minimal dependency-free JARVIS permanent core server.

The server owns device-independent state and exposes authenticated sync/task
boundaries. It deliberately does not execute arbitrary OS commands remotely.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

HOST = os.getenv("JARVIS_CORE_HOST", "127.0.0.1")
PORT = int(os.getenv("JARVIS_CORE_PORT", "8765"))
TOKEN = os.getenv("JARVIS_CORE_TOKEN", "")
DATA_DIR = Path(os.getenv("JARVIS_CORE_DATA", str(Path.home() / ".jarvis_core")))
STATE_FILE = DATA_DIR / "state.json"
LOCK = threading.RLock()


def load_state() -> dict:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not STATE_FILE.exists():
        state = {"revision": 0, "updated_at": 0, "memory": {}, "tasks": []}
        save_state(state)
        return state
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {"revision": 0, "updated_at": 0, "memory": {}, "tasks": []}


def save_state(state: dict) -> None:
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2))
    tmp.replace(STATE_FILE)


def auth_ok(handler: BaseHTTPRequestHandler) -> bool:
    if not TOKEN:
        return False
    value = handler.headers.get("Authorization", "")
    expected = "Bearer " + TOKEN
    return secrets.compare_digest(value, expected)


def json_bytes(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "JARVIS-Core/1.0"

    def log_message(self, fmt: str, *args) -> None:
        return

    def send_json(self, status: int, payload: object) -> None:
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 5_000_000:
            raise ValueError("payload_too_large")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/health":
            with LOCK:
                state = load_state()
            self.send_json(200, {"ok": True, "status": "ok", "service": "jarvis-core", "revision": state["revision"], "auth_required": True})
            return
        if not auth_ok(self):
            self.send_json(401, {"ok": False, "reason": "unauthorized"})
            return
        if path == "/v1/state":
            with LOCK:
                state = load_state()
            self.send_json(200, {"ok": True, "revision": state["revision"], "memory": state["memory"]})
            return
        self.send_json(404, {"ok": False, "reason": "not_found"})

    def do_POST(self) -> None:
        if not auth_ok(self):
            self.send_json(401, {"ok": False, "reason": "unauthorized"})
            return
        path = urlparse(self.path).path
        try:
            payload = self.read_json()
        except Exception as exc:
            self.send_json(400, {"ok": False, "reason": str(exc)})
            return

        if path == "/v1/sync":
            with LOCK:
                state = load_state()
                client_revision = int(payload.get("revision", 0))
                incoming = payload.get("memory", {})
                if not isinstance(incoming, dict):
                    self.send_json(400, {"ok": False, "reason": "memory_must_be_object"})
                    return
                conflict = client_revision < state["revision"] and bool(state["memory"])
                if not conflict:
                    state["memory"] = incoming
                    state["revision"] += 1
                    state["updated_at"] = int(time.time() * 1000)
                    save_state(state)
                self.send_json(200, {"ok": True, "revision": state["revision"], "conflict": conflict, "memory": state["memory"]})
            return

        if path == "/v1/execute":
            action = str(payload.get("action", "")).strip()
            if not action:
                self.send_json(400, {"ok": False, "reason": "action_required"})
                return
            task_id = hashlib.sha256(f"{time.time_ns()}:{action}".encode()).hexdigest()[:24]
            with LOCK:
                state = load_state()
                state["tasks"].append({"id": task_id, "action": action[:1000], "status": "ACCEPTED", "created_at": int(time.time() * 1000)})
                state["tasks"] = state["tasks"][-500:]
                save_state(state)
            self.send_json(202, {"ok": True, "task_id": task_id, "status": "ACCEPTED", "execution": "client_or_authorized_worker_required"})
            return

        self.send_json(404, {"ok": False, "reason": "not_found"})


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Set JARVIS_CORE_TOKEN before starting the core server")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    print(f"JARVIS Core listening on {HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
