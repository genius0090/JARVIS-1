#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

echo "=== JARVIS DIAGNOSTICS ==="
echo "Java:"; java -version 2>&1 | head -3 || true
echo "Gradle:";
if [[ -x "$PROJECT_DIR/gradlew" ]]; then "$PROJECT_DIR/gradlew" --version 2>&1 | head -12 || true
elif command -v gradle >/dev/null 2>&1; then gradle --version | head -12 || true
else echo "Gradle unavailable"; fi

echo "Android SDK:"
if [[ -n "${ANDROID_HOME:-}" ]]; then echo "$ANDROID_HOME"; elif [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then echo "$ANDROID_SDK_ROOT"; elif [[ -d "$HOME/android-sdk" ]]; then echo "$HOME/android-sdk"; else echo "NOT FOUND"; fi

echo "Source files: $(find app/src/main/java -name '*.kt' | wc -l)"
echo "Resources: $(find app/src/main/res -type f | wc -l)"
echo "Manifest: $([[ -f app/src/main/AndroidManifest.xml ]] && echo OK || echo MISSING)"
echo "=== END DIAGNOSTICS ==="
