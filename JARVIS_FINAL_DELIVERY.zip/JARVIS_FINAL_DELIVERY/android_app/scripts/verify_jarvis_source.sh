#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

fail=0
required=(
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/jarvis/allinone/MainActivity.kt
  app/src/main/java/com/jarvis/allinone/JarvisReactiveOrbView.kt
  app/src/main/java/com/jarvis/allinone/JarvisOrbService.kt
  app/src/main/java/com/jarvis/allinone/JarvisUnifiedActionRouter.kt
  app/src/main/java/com/jarvis/allinone/JarvisUnifiedDecisionEngine.kt
  app/src/main/java/com/jarvis/allinone/JarvisLocalAiClient.kt
  app/src/main/java/com/jarvis/allinone/JarvisPermanentCore.kt
)

for f in "${required[@]}"; do
  [[ -f "$f" ]] || { echo "MISSING: $f"; fail=1; }
done

if [[ -f local.properties ]]; then
  echo "ERROR: machine-specific local.properties is present"
  fail=1
fi

if find app/src/main -type f \( -name '*.before*' -o -name '*backup*' -o -name '*.bak' \) | grep -q .; then
  echo "ERROR: historical source backup found under production source"
  fail=1
fi

if grep -RInE 'Deepak|Deepu|Genius|Boss' app/src/main/java 2>/dev/null | grep -v 'JARVIS' >/dev/null; then
  echo "ERROR: personal identity seed found in source"
  fail=1
fi

KOTLIN_COUNT=$(find app/src/main/java -name '*.kt' | wc -l)
echo "Active Kotlin files: $KOTLIN_COUNT"

if [[ $fail -ne 0 ]]; then
  echo "JARVIS SOURCE VERIFY: FAIL"
  exit 1
fi

echo "JARVIS SOURCE VERIFY: PASS"
