#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

if [[ -x "$PROJECT_DIR/gradlew" ]]; then
  GRADLE=("$PROJECT_DIR/gradlew")
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "ERROR: Gradle unavailable."
  exit 30
fi

"${GRADLE[@]}" assembleDebug --stacktrace
APK="$(find app/build/outputs/apk -type f -name '*.apk' | head -n 1)"
[[ -n "$APK" ]] || { echo "ERROR: APK not produced."; exit 31; }

if command -v adb >/dev/null 2>&1; then
  echo "Installing: $APK"
  adb install -r "$APK"
  echo "APK install completed."
  echo "Launch manually and run the JARVIS smoke-test checklist."
else
  echo "APK built: $APK"
  echo "ADB is unavailable in this environment; install is manual."
fi
