#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

echo "=== JARVIS BUILD FOUNDATION ==="
echo "Project: $PROJECT_DIR"
java -version

if [[ -n "${ANDROID_HOME:-}" ]]; then
  echo "ANDROID_HOME=$ANDROID_HOME"
elif [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT"
elif [[ -d "$HOME/android-sdk" ]]; then
  export ANDROID_HOME="$HOME/android-sdk"
  echo "ANDROID_HOME=$ANDROID_HOME"
else
  echo "ERROR: Android SDK path not found. Set ANDROID_HOME or ANDROID_SDK_ROOT."
  exit 20
fi

if [[ -x "$PROJECT_DIR/gradlew" ]]; then
  GRADLE=("$PROJECT_DIR/gradlew")
else
  if ! command -v gradle >/dev/null 2>&1; then
    echo "ERROR: Gradle wrapper and system Gradle are both unavailable."
    exit 21
  fi
  GRADLE=(gradle)
fi

"${GRADLE[@]}" --version
"${GRADLE[@]}" clean
"${GRADLE[@]}" assembleDebug --stacktrace

APK="$(find app/build/outputs/apk -type f -name '*.apk' | head -n 1)"
if [[ -z "$APK" ]]; then
  echo "ERROR: Build reported success but no APK was produced."
  exit 22
fi

echo "=== JARVIS BUILD FOUNDATION: SUCCESS ==="
echo "APK: $PROJECT_DIR/$APK"
