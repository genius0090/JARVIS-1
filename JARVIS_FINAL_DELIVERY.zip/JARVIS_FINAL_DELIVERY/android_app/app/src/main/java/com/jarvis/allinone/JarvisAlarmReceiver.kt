package com.jarvis.allinone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class JarvisAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        JarvisNotificationCenter.setup(context)
    }
}
