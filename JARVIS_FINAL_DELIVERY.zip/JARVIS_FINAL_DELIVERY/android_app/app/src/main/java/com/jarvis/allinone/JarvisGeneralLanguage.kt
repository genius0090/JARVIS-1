package com.jarvis.allinone

object JarvisGeneralLanguage {
    enum class Language { AUTO,HINDI,ENGLISH,MIXED,OTHER }

    fun detect(text:String):Language{
        val h=text.any{it in 'ऀ'..'ॿ'}
        val e=text.any{it in 'A'..'Z'||it in 'a'..'z'}
        return when{
            h&&e->Language.MIXED
            h->Language.HINDI
            e->Language.ENGLISH
            else->Language.AUTO
        }
    }
}
