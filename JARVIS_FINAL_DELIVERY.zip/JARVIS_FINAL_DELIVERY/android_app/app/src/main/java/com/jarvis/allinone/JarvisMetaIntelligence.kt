package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisMetaIntelligence {

    private const val PREFS = "jarvis_meta_intelligence"
    private const val STYLE = "response_style"
    private const val UNKNOWN = "unknowns"
    private const val SECOND_BRAIN = "second_brain"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun append(context: Context, key: String, value: String) {
        val old = prefs(context).getString(key, "[]") ?: "[]"
        val array = JSONArray(old)
        array.put(value)
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun learnResponseStyle(
        context: Context,
        example: String,
        styleHint: String
    ): String {
        val item = JSONObject()
            .put("example", example)
            .put("styleHint", styleHint)
            .put("timestamp", System.currentTimeMillis())

        append(context, STYLE, item.toString())
        return item.toString()
    }

    fun detectUnknown(
        context: Context,
        task: String,
        missingInformation: String,
        confidence: Float
    ): String {
        val item = JSONObject()
            .put("task", task)
            .put("missingInformation", missingInformation)
            .put("confidence", confidence)
            .put("timestamp", System.currentTimeMillis())

        append(context, UNKNOWN, item.toString())
        return item.toString()
    }

    fun addSecondBrainNote(
        context: Context,
        topic: String,
        note: String,
        source: String = "jarvis"
    ): String {
        val item = JSONObject()
            .put("topic", topic)
            .put("note", note)
            .put("source", source)
            .put("timestamp", System.currentTimeMillis())

        append(context, SECOND_BRAIN, item.toString())
        return item.toString()
    }

    fun searchSecondBrain(
        context: Context,
        query: String
    ): List<String> {
        val result = mutableListOf<String>()
        val raw = prefs(context).getString(SECOND_BRAIN, "[]") ?: "[]"
        val array = JSONArray(raw)

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val topic = item.optString("topic")
            val note = item.optString("note")

            if (topic.contains(query, true) ||
                note.contains(query, true)
            ) {
                result.add(item.toString())
            }
        }

        return result
    }

    fun status(context: Context): String {
        return JSONObject()
            .put(
                "responseStyle",
                JSONArray(prefs(context).getString(STYLE, "[]"))
            )
            .put(
                "unknowns",
                JSONArray(prefs(context).getString(UNKNOWN, "[]"))
            )
            .put(
                "secondBrain",
                JSONArray(prefs(context).getString(SECOND_BRAIN, "[]"))
            )
            .toString()
    }
}
