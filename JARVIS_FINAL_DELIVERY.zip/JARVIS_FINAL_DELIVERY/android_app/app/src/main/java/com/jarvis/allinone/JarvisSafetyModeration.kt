package com.jarvis.allinone

object JarvisSafetyModeration {
    enum class Result { ALLOW, CONFIRM, BLOCK }

    fun check(action:String,sensitive:Boolean=false,highImpact:Boolean=false):Result{
        if(action.isBlank()) return Result.BLOCK
        if(highImpact) return Result.CONFIRM
        if(sensitive) return Result.CONFIRM
        return Result.ALLOW
    }
}
