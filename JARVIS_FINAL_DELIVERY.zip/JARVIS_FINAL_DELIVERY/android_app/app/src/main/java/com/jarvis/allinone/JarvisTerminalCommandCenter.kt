package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object JarvisTerminalCommandCenter {

    private const val PREFS = "jarvis_terminal_center"
    private const val HISTORY = "history"

    data class Result(
        val command: String,
        val output: String,
        val exitCode: Int,
        val success: Boolean
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val safeCommands = setOf(
        "pwd", "ls", "ls -la", "ls -l", "id", "whoami", "uname",
        "uname -a", "date", "uptime", "df", "df -h", "du", "du -h",
        "getprop", "ps", "ps -A", "settings list system",
        "settings list secure", "settings list global"
    )

    private fun isSafeCommand(command: String): Boolean {
        val clean = command.trim()
        if (clean.length > 256) return false
        if (clean.any { it in charArrayOf(';', '|', '&', '`', '$', '>', '<') }) return false
        if (clean.contains("..")) return false
        return safeCommands.contains(clean) ||
            clean.startsWith("ls ") ||
            clean.startsWith("cat /proc/") ||
            clean.startsWith("cat /sys/") ||
            clean.startsWith("getprop ")
    }

    private fun saveHistory(context: Context, result: Result) {
        val array = JSONArray(
            prefs(context).getString(HISTORY, "[]") ?: "[]"
        )

        array.put(
            JSONObject()
                .put("command", result.command)
                .put("output", result.output)
                .put("exitCode", result.exitCode)
                .put("success", result.success)
                .put("timestamp", System.currentTimeMillis())
        )

        while (array.length() > 100) {
            array.remove(0)
        }

        prefs(context).edit()
            .putString(HISTORY, array.toString())
            .apply()
    }

    fun execute(
        context: Context,
        command: String,
        timeoutMs: Long = 15000L
    ): Result {
        if (command.isBlank()) {
            return Result("", "Empty command", -1, false)
        }

        if (JarvisEmergencyStop.isStopped(context)) {
            return Result(
                command,
                "Emergency STOP active",
                -2,
                false
            )
        }

        if (JarvisTaskRecovery.isCancellationRequested(context)) {
            return Result(
                command,
                "Task cancellation requested",
                -3,
                false
            )
        }

        if (!isSafeCommand(command)) {
            val result = Result(
                command,
                "Command blocked by JARVIS safe terminal policy. Use an approved diagnostic command or an explicitly authorized execution path.",
                -5,
                false
            )
            saveHistory(context, result)
            return result
        }

        val started = System.currentTimeMillis()

        return try {
            val process = ProcessBuilder(
                "sh",
                "-c",
                command
            )
                .redirectErrorStream(true)
                .start()

            val output = StringBuilder()

            val reader = BufferedReader(
                InputStreamReader(process.inputStream)
            )

            while (reader.ready() ||
                process.isAlive
            ) {
                while (reader.ready()) {
                    output.append(reader.readLine()).append('\n')
                }

                if (System.currentTimeMillis() - started >= timeoutMs) {
                    process.destroyForcibly()

                    val result = Result(
                        command,
                        output.toString().trim() +
                            "\nCommand timed out.",
                        -4,
                        false
                    )

                    saveHistory(context, result)
                    return result
                }

                Thread.sleep(25)
            }

            while (reader.ready()) {
                output.append(reader.readLine()).append('\n')
            }

            val exitCode = process.exitValue()

            val result = Result(
                command,
                output.toString().trim(),
                exitCode,
                exitCode == 0
            )

            saveHistory(context, result)
            result

        } catch (e: Exception) {
            val result = Result(
                command,
                e.message ?: "Command execution failed",
                -1,
                false
            )

            saveHistory(context, result)
            result
        }
    }

    fun history(context: Context): JSONArray =
        JSONArray(
            prefs(context).getString(HISTORY, "[]") ?: "[]"
        )

    fun clearHistory(context: Context) {
        prefs(context).edit()
            .remove(HISTORY)
            .apply()
    }

    fun diagnostics(context: Context): String {
        val runtime = Runtime.getRuntime()

        return JSONObject()
            .put("availableProcessors", runtime.availableProcessors())
            .put("maxMemory", runtime.maxMemory())
            .put("totalMemory", runtime.totalMemory())
            .put("freeMemory", runtime.freeMemory())
            .put("historyEntries", history(context).length())
            .toString()
    }

    fun status(context: Context): String =
        JSONObject()
            .put("terminal", "ready")
            .put("historyEntries", history(context).length())
            .put(
                "emergencyStop",
                JarvisEmergencyStop.isStopped(context)
            )
            .put(
                "cancellationRequested",
                JarvisTaskRecovery.isCancellationRequested(context)
            )
            .toString()
}
