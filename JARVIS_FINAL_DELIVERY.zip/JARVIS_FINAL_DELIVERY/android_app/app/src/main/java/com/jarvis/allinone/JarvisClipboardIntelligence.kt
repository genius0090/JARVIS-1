package com.jarvis.allinone

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

object JarvisClipboardIntelligence {
    fun readText(context: Context): String? {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE)
                as? ClipboardManager ?: return null

        if (!manager.hasPrimaryClip()) return null

        val clip = manager.primaryClip ?: return null
        return if (clip.itemCount > 0)
            clip.getItemAt(0).coerceToText(context).toString()
        else null
    }

    fun setText(context: Context, text: String) {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE)
                as? ClipboardManager ?: return

        manager.setPrimaryClip(ClipData.newPlainText("JARVIS", text))
    }
}
