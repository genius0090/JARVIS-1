package com.jarvis.allinone

import android.content.Context

object JarvisSecurityLab {

    private const val PREFS = "jarvis_security_lab"
    private const val KEY_ENABLED = "lab_enabled"

    fun enable(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, true)
            .apply()
    }

    fun disable(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, false)
            .apply()
    }

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)

    fun isAuthorizedScope(context: Context): Boolean =
        isEnabled(context)

    fun status(context: Context): String =
        if (isEnabled(context))
            "AUTHORIZED SECURITY LAB: ENABLED"
        else
            "AUTHORIZED SECURITY LAB: DISABLED"
}
