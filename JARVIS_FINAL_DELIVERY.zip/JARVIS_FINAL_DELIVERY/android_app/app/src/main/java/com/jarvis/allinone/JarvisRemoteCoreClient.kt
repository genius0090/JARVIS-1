package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Device-independent JARVIS core transport.
 * The Android client never treats a remote core as available unless a real
 * authenticated request succeeds. Local-first operation remains the fallback.
 */
object JarvisRemoteCoreClient {
    private const val PREFS = "jarvis_remote_core"
    private const val KEY_BASE_URL = "base_url"
    private const val KEY_TIMEOUT_MS = "timeout_ms"
    private const val DEFAULT_TIMEOUT = 5000
    private val executor = Executors.newCachedThreadPool()

    fun configure(context: Context, baseUrl: String) {
        val normalized = baseUrl.trim().trimEnd('/')
        require(normalized.startsWith("https://") || normalized.startsWith("http://"))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_BASE_URL, normalized)
            .apply()
    }

    fun baseUrl(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_BASE_URL, "") ?: ""

    fun clearConfiguration(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_BASE_URL)
            .apply()
    }

    fun health(context: Context): JSONObject = request(context, "/health", "GET", null)

    fun sync(context: Context, payload: JSONObject): JSONObject =
        request(context, "/v1/sync", "POST", payload)

    fun execute(context: Context, payload: JSONObject): JSONObject =
        request(context, "/v1/execute", "POST", payload)

    fun isAvailable(context: Context): Boolean = try {
        val result = health(context)
        result.optBoolean("ok", false) || result.optString("status") == "ok"
    } catch (_: Throwable) {
        false
    }

    private fun request(
        context: Context,
        path: String,
        method: String,
        payload: JSONObject?
    ): JSONObject {
        val base = baseUrl(context)
        if (base.isBlank()) return JSONObject().put("ok", false).put("reason", "core_not_configured")

        val url = URL(base + path)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(KEY_TIMEOUT_MS, DEFAULT_TIMEOUT)
            readTimeout = connectTimeout
            useCaches = false
            doInput = true
            setRequestProperty("Accept", "application/json")
            JarvisKeystoreSecretStore.read(context, JarvisKeystoreSecretStore.KEY_CORE_TOKEN)
                ?.takeIf { it.isNotBlank() }
                ?.let { setRequestProperty("Authorization", "Bearer $it") }
        }

        try {
            if (payload != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            return try {
                JSONObject(body.ifBlank { "{}" })
                    .put("http_status", code)
                    .put("ok", code in 200..299)
            } catch (_: Throwable) {
                JSONObject().put("ok", code in 200..299).put("http_status", code).put("body", body)
            }
        } finally {
            connection.disconnect()
        }
    }
}
