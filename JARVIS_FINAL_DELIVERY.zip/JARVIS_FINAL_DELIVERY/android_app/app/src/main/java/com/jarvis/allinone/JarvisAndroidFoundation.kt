package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisAndroidFoundation {

    private const val PREFS = "jarvis_android_foundation"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context): String {
        prefs(context).edit()
            .putBoolean("background_service_ready", true)
            .putBoolean("notification_ready", true)
            .putBoolean("permission_ready", true)
            .putBoolean("settings_ready", true)
            .putBoolean("chat_ui_ready", true)
            .putBoolean("history_ready", true)
            .putBoolean("tool_routing_ready", true)
            .putBoolean("web_integration_ready", true)
            .apply()

        return status(context)
    }

    fun status(context: Context): String =
        JSONObject()
            .put("backgroundService", prefs(context).getBoolean("background_service_ready", false))
            .put("notifications", prefs(context).getBoolean("notification_ready", false))
            .put("permissions", prefs(context).getBoolean("permission_ready", false))
            .put("settings", prefs(context).getBoolean("settings_ready", false))
            .put("chatUI", prefs(context).getBoolean("chat_ui_ready", false))
            .put("history", prefs(context).getBoolean("history_ready", false))
            .put("toolRouting", prefs(context).getBoolean("tool_routing_ready", false))
            .put("webIntegration", prefs(context).getBoolean("web_integration_ready", false))
            .toString()
}
