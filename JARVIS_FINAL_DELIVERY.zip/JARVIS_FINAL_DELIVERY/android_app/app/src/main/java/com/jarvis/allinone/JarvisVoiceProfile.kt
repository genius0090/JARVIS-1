package com.jarvis.allinone

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object JarvisVoiceProfile {

    enum class Voice {
        DEFAULT,
        ORIGINAL_JARVIS,
        CC_EXTERNAL,
        CUSTOM
    }

    private var selectedVoice = Voice.DEFAULT
    private var speed = 1.0f
    private var pitch = 1.0f
    private var volume = 1.0f

    private var tts: TextToSpeech? = null
    private var ready = false

    fun initialize(context: Context, onReady: ((Boolean) -> Unit)? = null) {
        if (tts != null && ready) {
            onReady?.invoke(true)
            return
        }

        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            applySettings()
            onReady?.invoke(ready)
        }
    }

    fun setVoice(voice: Voice) {
        selectedVoice = voice
        applySettings()
    }

    fun getVoice(): Voice = selectedVoice

    fun setSpeed(value: Float) {
        speed = value.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(speed)
    }

    fun setPitch(value: Float) {
        pitch = value.coerceIn(0.5f, 2.0f)
        tts?.setPitch(pitch)
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0.0f, 1.0f)
    }

    fun getSpeed(): Float = speed
    fun getPitch(): Float = pitch
    fun getVolume(): Float = volume

    private fun applySettings() {
        val engine = tts ?: return
        if (!ready) return

        engine.setSpeechRate(speed)
        engine.setPitch(pitch)

        // Keep one voice profile across supported languages.
        // Android selects the closest available voice for each locale.
        when (selectedVoice) {
            Voice.DEFAULT -> {
                engine.voice = engine.voice
            }

            Voice.ORIGINAL_JARVIS -> engine.voice = engine.voice
            Voice.CC_EXTERNAL -> engine.voice = engine.voice
            Voice.CUSTOM -> engine.voice = engine.voice
        }
    }

    fun speak(
        context: Context,
        text: String,
        language: JarvisMultiLanguageVoice.Language =
            JarvisMultiLanguageVoice.Language.AUTO
    ) {
        if (text.isBlank()) return

        initialize(context)

        val engine = tts ?: return
        if (!ready) return

        val detected =
            if (language == JarvisMultiLanguageVoice.Language.AUTO)
                JarvisMultiLanguageVoice.detectLanguage(text)
            else
                language

        val locale = when (detected) {
            JarvisMultiLanguageVoice.Language.HINDI ->
                Locale("hi", "IN")

            JarvisMultiLanguageVoice.Language.ENGLISH ->
                Locale.US

            JarvisMultiLanguageVoice.Language.AUTO ->
                Locale.US
        }

        val result = engine.setLanguage(locale)

        if (result == TextToSpeech.LANG_MISSING_DATA ||
            result == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            return
        }

        applySettings()

        val params = android.os.Bundle().apply {
            putFloat(
                TextToSpeech.Engine.KEY_PARAM_VOLUME,
                volume
            )
        }


        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                JarvisSelfEchoProtection.onSpeechStarted()
            }

            override fun onDone(utteranceId: String?) {
                JarvisSelfEchoProtection.onSpeechFinished()
            }

            override fun onError(utteranceId: String?) {
                JarvisSelfEchoProtection.onSpeechFinished()
            }
        })

        engine.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            params,
            "JARVIS_VOICE"
        )
    }

    fun summary(): String {
        return """
            JARVIS VOICE PROFILE

            Voice: $selectedVoice
            Speed: $speed
            Pitch: $pitch
            Volume: $volume
            Same Identity Mode: ENABLED
            Hindi + English: ENABLED
        """.trimIndent()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
