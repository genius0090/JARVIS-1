package com.jarvis.allinone

object JarvisSystemControl {
    enum class Action {
        OPEN_APP, OPEN_SETTINGS, CHECK_BATTERY,
        CHECK_STORAGE, CHECK_NETWORK, DEVICE_STATUS
    }

    data class Request(
        val action: Action,
        val argument: String? = null
    )

    private var latest: Request? = null

    fun request(action: Action, argument: String? = null): Request {
        return Request(action, argument).also { latest = it }
    }

    fun latest(): Request? = latest
    fun clear() { latest = null }
}
