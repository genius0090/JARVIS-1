package com.jarvis.allinone

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * User-controlled foreground wake service. Android owns microphone permission
 * and background-service restrictions; this service never attempts to bypass them.
 */
class JarvisWakeService : Service() {
    companion object {
        const val ACTION_START = "com.jarvis.allinone.action.START_WAKE"
        const val ACTION_STOP = "com.jarvis.allinone.action.STOP_WAKE"
        const val EXTRA_COMMAND = "jarvis_command"
        private const val CHANNEL = "jarvis_wake"
        private const val NOTIFICATION_ID = 99
    }

    private var recognizer: SpeechRecognizer? = null
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopWake()
            else -> startWake()
        }
        return START_STICKY
    }

    private fun startWake() {
        if (Build.VERSION.SDK_INT >= 23 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return
        }
        startForeground(NOTIFICATION_ID, notification())
        JarvisBackgroundWake.enable()
        listen()
    }

    private fun listen() {
        if (isFinishingState()) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

            override fun onError(error: Int) {
                scheduleRestart()
            }

            override fun onResults(results: android.os.Bundle?) {
                val values = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val recognized = values.firstOrNull()?.trim().orEmpty()
                if (recognized.isNotBlank() && JarvisBackgroundWake.matches(recognized)) {
                    val lower = recognized.lowercase(Locale.getDefault())
                    val wakePhrases = listOf("hey jarvis", "jarvis utho", "jarvis suno", "jarvis", "wake")
                    val command = wakePhrases.firstNotNullOfOrNull { phrase ->
                        if (lower == phrase) "" else lower.removePrefix(phrase).trim().takeIf { it.isNotBlank() }
                    } ?: ""
                    launchCommand(command)
                }
                scheduleRestart()
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            recognizer?.startListening(intent)
        } catch (_: Throwable) {
            scheduleRestart()
        }
    }

    private fun launchCommand(command: String) {
        val activity = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_COMMAND, command)
        }
        startActivity(activity)
    }

    private fun scheduleRestart() {
        if (restarting || isFinishingState()) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (!isFinishingState()) listen()
        }, 650L)
    }

    private fun isFinishingState(): Boolean = !JarvisBackgroundWake.isEnabled() || stopRequested

    private var stopRequested = false

    private fun stopWake() {
        stopRequested = true
        JarvisBackgroundWake.disable()
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopRequested = true
        JarvisBackgroundWake.disable()
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "JARVIS Wake Listener", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL)
                .setContentTitle("JARVIS Wake Listener")
                .setContentText("Listening for the configured JARVIS wake phrase")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("JARVIS Wake Listener")
                .setContentText("Listening for the configured JARVIS wake phrase")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }

    override fun onBind(intent: Intent?): IBinder? = null
}
