package com.jarvis.allinone

object JarvisRecallableMemory {
    data class Memory(
        val id: Long,
        val key: String,
        val value: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    private val memories = mutableListOf<Memory>()
    private var nextId = 1L

    fun remember(key: String, value: String): Long {
        val id = nextId++
        memories += Memory(id, key, value)
        return id
    }

    fun recall(query: String): List<Memory> {
        val q = query.lowercase()
        return memories.filter {
            it.key.lowercase().contains(q) ||
            it.value.lowercase().contains(q)
        }
    }

    fun all(): List<Memory> = memories.toList()

    fun forget(id: Long): Boolean =
        memories.removeIf { it.id == id }
}
