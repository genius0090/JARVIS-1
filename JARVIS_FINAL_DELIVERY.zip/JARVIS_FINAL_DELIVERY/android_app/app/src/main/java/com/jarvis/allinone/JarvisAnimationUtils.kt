package com.jarvis.allinone

import android.animation.*
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator

object JarvisAnimationUtils {

    fun appear(view: View, duration: Long = 280) {
        view.alpha = 0f
        view.scaleX = 0.88f
        view.scaleY = 0.88f

        view.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(duration)
            .setInterpolator(OvershootInterpolator(0.8f))
            .start()
    }

    fun disappear(view: View, duration: Long = 220, end: (() -> Unit)? = null) {
        view.animate()
            .alpha(0f)
            .scaleX(0.9f)
            .scaleY(0.9f)
            .setDuration(duration)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                end?.invoke()
            }
            .start()
    }

    fun pulse(view: View, duration: Long = 900) {
        view.animate()
            .scaleX(1.06f)
            .scaleY(1.06f)
            .setDuration(duration / 2)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(duration / 2)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
            }
            .start()
    }

    fun floating(view: View) {
        val animator = ObjectAnimator.ofFloat(
            view,
            View.TRANSLATION_Y,
            -4f,
            4f
        )

        animator.duration = 1800
        animator.repeatCount = ValueAnimator.INFINITE
        animator.repeatMode = ValueAnimator.REVERSE
        animator.interpolator = AccelerateDecelerateInterpolator()
        animator.start()

        view.setTag(R.id.jarvis_animation_tag, animator)
    }

    fun stopFloating(view: View) {
        (view.getTag(R.id.jarvis_animation_tag) as? Animator)?.cancel()
        view.translationY = 0f
    }
}
