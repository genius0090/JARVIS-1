package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisPersonalIntelligence {

    private const val PREFS = "jarvis_personal_intelligence"
    private const val INTENTS = "intents"
    private const val ROUTINES = "routines"
    private const val DECISIONS = "decisions"
    private const val GOALS = "goals"
    private const val MISTAKES = "mistakes"
    private const val KNOWLEDGE = "knowledge"

    data class Prediction(
        val intent: String,
        val confidence: Float,
        val reason: String
    )

    data class Goal(
        val id: String,
        val title: String,
        val active: Boolean
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun append(context: Context, key: String, value: String) {
        val p = prefs(context)
        val array = JSONArray(p.getString(key, "[]"))
        array.put(value)
        p.edit().putString(key, array.toString()).apply()
    }

    fun learnIntent(context: Context, intent: String) {
        if (intent.isNotBlank()) append(context, INTENTS, intent.trim())
    }

    fun learnRoutine(context: Context, routine: String) {
        if (routine.isNotBlank()) append(context, ROUTINES, routine.trim())
    }

    fun rememberDecision(context: Context, decision: String) {
        if (decision.isNotBlank()) append(context, DECISIONS, decision.trim())
    }

    fun addGoal(context: Context, id: String, title: String) {
        if (id.isBlank() || title.isBlank()) return
        val obj = JSONObject()
            .put("id", id)
            .put("title", title)
            .put("active", true)
        append(context, GOALS, obj.toString())
    }

    fun completeGoal(context: Context, id: String) {
        val p = prefs(context)
        val old = JSONArray(p.getString(GOALS, "[]"))
        val updated = JSONArray()

        for (i in 0 until old.length()) {
            val item = JSONObject(old.getString(i))
            if (item.optString("id") == id) item.put("active", false)
            updated.put(item.toString())
        }

        p.edit().putString(GOALS, updated.toString()).apply()
    }

    fun recordMistake(context: Context, pattern: String) {
        if (pattern.isNotBlank()) append(context, MISTAKES, pattern.trim())
    }

    fun addKnowledge(context: Context, subject: String, value: String) {
        if (subject.isBlank() || value.isBlank()) return
        val obj = JSONObject()
            .put("subject", subject.trim())
            .put("value", value.trim())
        append(context, KNOWLEDGE, obj.toString())
    }

    fun predict(context: Context, input: String): Prediction {
        val query = input.trim().lowercase()
        if (query.isBlank()) {
            return Prediction("", 0f, "Empty input")
        }

        val stored = JSONArray(prefs(context).getString(INTENTS, "[]"))
        var best = ""
        var bestScore = 0

        for (i in 0 until stored.length()) {
            val known = stored.optString(i).lowercase()
            val score = known.split(" ")
                .count { it.length > 2 && query.contains(it) }

            if (score > bestScore) {
                bestScore = score
                best = stored.optString(i)
            }
        }

        val confidence = when {
            bestScore >= 3 -> 0.9f
            bestScore == 2 -> 0.7f
            bestScore == 1 -> 0.5f
            else -> 0f
        }

        return Prediction(
            best,
            confidence,
            if (best.isBlank()) "No learned intent match"
            else "Matched learned intent pattern"
        )
    }

    fun activeGoals(context: Context): List<Goal> {
        val result = mutableListOf<Goal>()
        val array = JSONArray(prefs(context).getString(GOALS, "[]"))

        for (i in 0 until array.length()) {
            val obj = JSONObject(array.getString(i))
            if (obj.optBoolean("active", false)) {
                result.add(
                    Goal(
                        obj.optString("id"),
                        obj.optString("title"),
                        true
                    )
                )
            }
        }

        return result
    }

    fun status(context: Context): String {
        val p = prefs(context)
        return "Personal Intelligence ready | " +
            "intents=${JSONArray(p.getString(INTENTS, "[]")).length()} | " +
            "routines=${JSONArray(p.getString(ROUTINES, "[]")).length()} | " +
            "decisions=${JSONArray(p.getString(DECISIONS, "[]")).length()} | " +
            "goals=${JSONArray(p.getString(GOALS, "[]")).length()} | " +
            "mistakes=${JSONArray(p.getString(MISTAKES, "[]")).length()} | " +
            "knowledge=${JSONArray(p.getString(KNOWLEDGE, "[]")).length()}"
    }
}
