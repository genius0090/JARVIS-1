package com.jarvis.allinone

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

object JarvisAdbBridge {

    data class Result(
        val success: Boolean,
        val output: String,
        val error: String = ""
    )

    fun isAdbAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("which", "adb"))
            process.waitFor(2, TimeUnit.SECONDS)
            process.exitValue() == 0
        } catch (_: Exception) {
            false
        }
    }

    private fun safeAdbCommand(command: String): Boolean {
        val clean = command.trim()
        if (clean.length > 256) return false
        if (clean.any { it in charArrayOf(';', '|', '&', '`', '$', '>', '<') }) return false
        return clean == "adb devices" ||
            clean == "adb get-state" ||
            clean.startsWith("adb shell getprop") ||
            clean.startsWith("adb shell dumpsys ") ||
            clean.startsWith("adb shell pm list packages")
    }

    fun execute(command: String): Result {
        if (command.isBlank()) {
            return Result(false, "", "Empty command")
        }

        if (!safeAdbCommand(command)) {
            return Result(false, "", "ADB command blocked by safe diagnostic policy")
        }

        return try {
            val process = Runtime.getRuntime().exec(command.split(" ").toTypedArray())

            val output = BufferedReader(
                InputStreamReader(process.inputStream)
            ).use { it.readText() }

            val error = BufferedReader(
                InputStreamReader(process.errorStream)
            ).use { it.readText() }

            process.waitFor(10, TimeUnit.SECONDS)

            Result(
                success = process.exitValue() == 0,
                output = output.trim(),
                error = error.trim()
            )
        } catch (e: Exception) {
            Result(false, "", e.message ?: "ADB execution failed")
        }
    }

    fun deviceStatus(): Result {
        return execute("adb devices")
    }

    fun shell(command: String): Result {
        if (command.isBlank()) {
            return Result(false, "", "Empty shell command")
        }
        val clean = command.trim()
        if (clean.any { it in charArrayOf(';', '|', '&', '`', '$', '>', '<') }) {
            return Result(false, "", "ADB shell command blocked by safe diagnostic policy")
        }
        if (!(clean.startsWith("getprop") || clean.startsWith("dumpsys ") || clean == "pm list packages")) {
            return Result(false, "", "Only approved diagnostic ADB shell commands are allowed")
        }
        return execute("adb shell $clean")
    }

    fun summary(context: Context): String {
        if (!isAdbAvailable()) {
            return """
                JARVIS ADB DEVICE BRIDGE

                ADB executable not available
                on this Android environment.

                Bridge foundation: READY
            """.trimIndent()
        }

        val result = deviceStatus()

        return buildString {
            append("JARVIS ADB DEVICE BRIDGE\n\n")
            append("ADB: AVAILABLE\n")
            append("Status:\n")
            append(
                if (result.success)
                    result.output.ifBlank { "No device detected" }
                else
                    result.error.ifBlank { "Unable to query devices" }
            )
        }
    }
}
