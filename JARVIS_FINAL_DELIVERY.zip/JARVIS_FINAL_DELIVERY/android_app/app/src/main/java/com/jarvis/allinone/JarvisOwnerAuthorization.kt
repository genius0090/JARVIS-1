package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisOwnerAuthorization {
    fun initialize(c: Context) = statusJson(c)

    fun authorize(
        c: Context,
        ownerVerified: Boolean,
        sessionValid: Boolean,
        deviceAuthorized: Boolean,
        actionPermitted: Boolean,
        confirmation: Boolean
    ): Boolean {
        if (!ownerVerified) return false
        if (!sessionValid) return false
        if (!deviceAuthorized) return false
        if (!actionPermitted) return false
        return confirmation
    }

    fun statusJson(c: Context) = JSONObject()
        .put("owner_authorization", "ENABLED")
        .put("owner_authentication_required", true)
        .put("valid_session_required", true)
        .put("authorized_device_required", true)
        .put("action_permission_required", true)
        .put("confirmation_boundary", true)
        .put("fail_closed", true)

    fun healthCheck(c: Context) = JSONObject()
        .put("owner_authorization", "IMPLEMENTED")
        .put("owner_authenticated_check", "ENABLED")
        .put("session_validity_check", "ENABLED")
        .put("device_authorization_check", "ENABLED")
        .put("action_permission_check", "ENABLED")
        .put("confirmation_check", "ENABLED")
        .put("fail_closed", "ENABLED")
}