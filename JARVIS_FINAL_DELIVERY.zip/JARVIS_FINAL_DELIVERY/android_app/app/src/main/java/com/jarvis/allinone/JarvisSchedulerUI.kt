package com.jarvis.allinone

import android.content.Context

object JarvisSchedulerUI {
    fun scheduler(context: Context) = state("scheduler", "Scheduler", "READY", "Reminder, alarm and scheduled-task controls", true)
    fun create(context: Context) = state("schedule_create", "Create Schedule", "READY", "Create a scheduled JARVIS task", true)
    fun recurring(context: Context) = state("schedule_recurring", "Recurring Schedule", "READY", "Configure recurring task definitions", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
