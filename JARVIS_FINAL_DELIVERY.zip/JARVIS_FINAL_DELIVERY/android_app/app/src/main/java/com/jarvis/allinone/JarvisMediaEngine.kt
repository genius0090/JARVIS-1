package com.jarvis.allinone

import android.content.Context
import android.media.MediaMetadataRetriever
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Local-first media project/timeline engine.
 * It owns project state and produces verified FFmpeg plans. Actual processing
 * occurs only when a real FFmpeg runtime is configured; no fake export success.
 */
object JarvisMediaEngine {
    private const val PREFS = "jarvis_media_engine"
    private const val KEY_PROJECTS = "projects"
    private const val KEY_FFMPEG = "ffmpeg_binary"

    data class Result(val success: Boolean, val message: String, val output: String = "")

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(c: Context) {
        if (!prefs(c).contains(KEY_PROJECTS)) prefs(c).edit().putString(KEY_PROJECTS, "[]").apply()
    }

    fun configureFfmpeg(c: Context, path: String): Boolean {
        val file = File(path)
        if (!file.exists() || !file.isFile || !file.canExecute()) return false
        prefs(c).edit().putString(KEY_FFMPEG, file.absolutePath).apply()
        return true
    }

    fun ffmpegPath(c: Context): String = prefs(c).getString(KEY_FFMPEG, "") ?: ""

    fun ffmpegAvailable(c: Context): Boolean = ffmpegPath(c).let { it.isNotBlank() && File(it).canExecute() }

    fun createProject(c: Context, name: String): String {
        initialize(c)
        val id = UUID.randomUUID().toString()
        val arr = JSONArray(prefs(c).getString(KEY_PROJECTS, "[]") ?: "[]")
        arr.put(JSONObject().put("id", id).put("name", name.ifBlank { "JARVIS Media Project" }).put("created_at", System.currentTimeMillis()).put("tracks", JSONArray()).put("history", JSONArray()))
        prefs(c).edit().putString(KEY_PROJECTS, arr.toString()).apply()
        return id
    }

    fun addClip(c: Context, projectId: String, path: String, startMs: Long = 0, endMs: Long = -1): Result {
        val file = File(path)
        if (!file.exists() || !file.isFile) return Result(false, "Media file not found")
        val project = project(c, projectId) ?: return Result(false, "Project not found")
        val tracks = project.optJSONArray("tracks") ?: JSONArray()
        val clip = JSONObject().put("path", file.absolutePath).put("start_ms", startMs).put("end_ms", endMs)
        tracks.put(clip)
        project.put("tracks", tracks)
        updateProject(c, project)
        return Result(true, "Clip added", clip.toString())
    }

    fun inspect(path: String): JSONObject {
        val file = File(path)
        if (!file.exists()) return JSONObject().put("ok", false).put("reason", "file_not_found")
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            JSONObject()
                .put("ok", true)
                .put("path", file.absolutePath)
                .put("duration_ms", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)
                .put("width", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0)
                .put("height", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0)
                .put("mime", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "")
        } catch (e: Throwable) {
            JSONObject().put("ok", false).put("reason", e.message ?: "media_inspection_failed")
        } finally { r.release() }
    }

    fun concatPlan(c: Context, projectId: String, output: String): Result {
        val project = project(c, projectId) ?: return Result(false, "Project not found")
        val tracks = project.optJSONArray("tracks") ?: return Result(false, "No media clips")
        if (tracks.length() == 0) return Result(false, "No media clips")
        if (!ffmpegAvailable(c)) return Result(false, "FFmpeg runtime is not configured; export plan created but cannot execute locally")

        val listFile = File(c.cacheDir, "jarvis_concat_${projectId}.txt")
        val lines = buildString {
            for (i in 0 until tracks.length()) {
                val path = tracks.getJSONObject(i).optString("path")
                append("file '").append(path.replace("'", "'\\''")).append("'\n")
            }
        }
        listFile.writeText(lines)
        val command = listOf(ffmpegPath(c), "-y", "-f", "concat", "-safe", "0", "-i", listFile.absolutePath, "-c", "copy", output)
        return Result(true, "FFmpeg export ready", JSONArray(command).toString())
    }

    fun execute(c: Context, command: List<String>): Result {
        if (command.isEmpty()) return Result(false, "Empty media command")
        if (!ffmpegAvailable(c)) return Result(false, "FFmpeg runtime is not configured")
        return try {
            val process = ProcessBuilder(command).redirectErrorStream(true).start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            Result(code == 0, if (code == 0) "Media export complete" else "Media export failed", output)
        } catch (e: Throwable) { Result(false, e.message ?: "media_execution_failed") }
    }

    fun projects(c: Context): JSONArray = JSONArray(prefs(c).getString(KEY_PROJECTS, "[]") ?: "[]")

    private fun project(c: Context, id: String): JSONObject? {
        val arr = projects(c)
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") == id) return arr.getJSONObject(i)
        return null
    }

    private fun updateProject(c: Context, project: JSONObject) {
        val arr = projects(c)
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") == project.optString("id")) { arr.put(i, project); break }
        prefs(c).edit().putString(KEY_PROJECTS, arr.toString()).apply()
    }

    fun status(c: Context) = JSONObject()
        .put("media_engine", "IMPLEMENTED")
        .put("project_store", "ENABLED")
        .put("timeline_state", "ENABLED")
        .put("media_inspection", "ENABLED")
        .put("ffmpeg_runtime", if (ffmpegAvailable(c)) "AVAILABLE" else "NOT_CONFIGURED")
}
