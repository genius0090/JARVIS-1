package com.jarvis.allinone

import android.content.Context
import android.os.Environment
import java.io.File

object JarvisStorageCleanup {

    data class CleanupReport(
        val totalBytes: Long,
        val freeBytes: Long,
        val largeFiles: List<File>,
        val emptyDirectories: List<File>,
        val cacheBytes: Long
    )

    fun scan(context: Context): CleanupReport {
        val root = Environment.getExternalStorageDirectory()

        val largeFiles = mutableListOf<File>()
        val emptyDirectories = mutableListOf<File>()
        var cacheBytes = 0L

        fun walk(file: File) {
            if (!file.exists()) return

            if (file.isFile) {
                if (file.length() >= 100L * 1024L * 1024L) {
                    largeFiles.add(file)
                }
                return
            }

            val children = file.listFiles() ?: return

            if (children.isEmpty()) {
                emptyDirectories.add(file)
                return
            }

            for (child in children) {
                if (child.isDirectory && child.name.equals("cache", true)) {
                    cacheBytes += child.walkSize()
                } else {
                    walk(child)
                }
            }
        }

        walk(root)

        return CleanupReport(
            totalBytes = root.totalSpace,
            freeBytes = root.freeSpace,
            largeFiles = largeFiles.sortedByDescending { it.length() }.take(50),
            emptyDirectories = emptyDirectories.take(100),
            cacheBytes = cacheBytes
        )
    }

    fun summary(context: Context): String {
        val r = scan(context)

        val used = r.totalBytes - r.freeBytes
        val large = r.largeFiles.sumOf { it.length() }

        return buildString {
            append("JARVIS STORAGE REPORT\n\n")
            append("Used: ${formatBytes(used)}\n")
            append("Free: ${formatBytes(r.freeBytes)}\n")
            append("Large files: ${r.largeFiles.size}\n")
            append("Large-file size: ${formatBytes(large)}\n")
            append("Empty folders: ${r.emptyDirectories.size}\n")
            append("Cache candidates: ${formatBytes(r.cacheBytes)}\n\n")
            append("Cleanup requires confirmation before deletion.")
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        if (bytes < 1024 * 1024) return "%.1f KB".format(bytes / 1024.0)
        if (bytes < 1024 * 1024 * 1024)
            return "%.1f MB".format(bytes / (1024.0 * 1024.0))
        return "%.1f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
    }

    private fun File.walkSize(): Long {
        if (isFile) return length()
        return listFiles()?.sumOf { it.walkSize() } ?: 0L
    }
}
