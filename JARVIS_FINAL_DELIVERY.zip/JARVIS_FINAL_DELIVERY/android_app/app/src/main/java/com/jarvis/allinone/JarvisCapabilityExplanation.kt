package com.jarvis.allinone

object JarvisCapabilityExplanation {
    fun explain(capability: String): String = JarvisCapabilityAwareness.explain(capability)
}
