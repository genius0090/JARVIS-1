package com.jarvis.allinone

object JarvisAffectiveDialogue {
    enum class Tone { NEUTRAL, CALM, ENCOURAGING, CONCISE, SERIOUS }

    private var tone=Tone.NEUTRAL

    fun setTone(value:Tone){tone=value}
    fun getTone()=tone

    fun adapt(text:String):String=when(tone){
        Tone.NEUTRAL->text
        Tone.CALM->text
        Tone.ENCOURAGING->text
        Tone.CONCISE->text
        Tone.SERIOUS->text
    }
}
