package com.jarvis.allinone

object JarvisAgentPlanner {
    data class Step(
        val id: Int,
        val description: String,
        val dependency: Int? = null,
        var completed: Boolean = false
    )

    private val steps = mutableListOf<Step>()

    fun createPlan(tasks: List<String>): List<Step> {
        steps.clear()
        tasks.forEachIndexed { index, task ->
            steps += Step(
                id = index + 1,
                description = task,
                dependency = if (index == 0) null else index
            )
        }
        return steps.toList()
    }

    fun complete(id: Int): Boolean {
        val step = steps.firstOrNull { it.id == id } ?: return false
        step.completed = true
        return true
    }

    fun current(): List<Step> = steps.toList()

    fun next(): Step? =
        steps.firstOrNull { !it.completed }

    fun clear() = steps.clear()
}
