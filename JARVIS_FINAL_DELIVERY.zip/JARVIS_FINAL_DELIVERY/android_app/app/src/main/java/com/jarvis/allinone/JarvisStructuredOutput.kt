package com.jarvis.allinone

import org.json.JSONArray
import org.json.JSONObject

object JarvisStructuredOutput {
    fun objectResult(status:String,message:String):JSONObject=
        JSONObject().put("status",status).put("message",message)

    fun listResult(items:List<String>):JSONArray=
        JSONArray(items)
}
