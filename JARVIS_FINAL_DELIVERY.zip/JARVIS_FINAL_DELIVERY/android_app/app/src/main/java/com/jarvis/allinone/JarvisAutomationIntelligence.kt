package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisAutomationIntelligence {

    private const val PREFS = "jarvis_automation_intelligence"
    private const val AUTOMATIONS = "automations"
    private const val FORECASTS = "forecasts"
    private const val RESOURCES = "resources"
    private const val OFFLINE = "offline"
    private const val COMMANDS = "commands"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun append(context: Context, key: String, value: String) {
        val old = prefs(context).getString(key, "[]") ?: "[]"
        val array = JSONArray(old)
        array.put(value)
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun composeAutomation(
        context: Context,
        name: String,
        trigger: String,
        actions: List<String>
    ): String {
        val item = JSONObject()
            .put("name", name)
            .put("trigger", trigger)
            .put("actions", JSONArray(actions))
            .put("createdAt", System.currentTimeMillis())
            .put("enabled", true)

        append(context, AUTOMATIONS, item.toString())
        return item.toString()
    }

    fun recordFailureForecast(
        context: Context,
        task: String,
        risk: String,
        reason: String
    ): String {
        val item = JSONObject()
            .put("task", task)
            .put("risk", risk)
            .put("reason", reason)
            .put("timestamp", System.currentTimeMillis())

        append(context, FORECASTS, item.toString())
        return item.toString()
    }

    fun recordResourceState(
        context: Context,
        task: String,
        cpu: Float,
        memory: Float,
        battery: Int,
        network: Boolean
    ): String {
        val item = JSONObject()
            .put("task", task)
            .put("cpu", cpu)
            .put("memory", memory)
            .put("battery", battery)
            .put("network", network)
            .put("timestamp", System.currentTimeMillis())

        append(context, RESOURCES, item.toString())
        return item.toString()
    }

    fun chooseResourceMode(
        battery: Int,
        networkAvailable: Boolean,
        heavyTask: Boolean
    ): String {
        return when {
            !networkAvailable && heavyTask -> "OFFLINE_LIGHT"
            battery < 20 && heavyTask -> "BATTERY_SAVER"
            heavyTask -> "DEEP"
            else -> "NORMAL"
        }
    }

    fun registerOfflineSubstitution(
        context: Context,
        onlineTask: String,
        offlineAlternative: String
    ): String {
        val item = JSONObject()
            .put("onlineTask", onlineTask)
            .put("offlineAlternative", offlineAlternative)
            .put("createdAt", System.currentTimeMillis())

        append(context, OFFLINE, item.toString())
        return item.toString()
    }

    fun learnCommand(
        context: Context,
        spokenCommand: String,
        normalizedCommand: String
    ): String {
        val item = JSONObject()
            .put("spoken", spokenCommand)
            .put("normalized", normalizedCommand)
            .put("timestamp", System.currentTimeMillis())

        append(context, COMMANDS, item.toString())
        return item.toString()
    }

    fun status(context: Context): String {
        return JSONObject()
            .put("automations", JSONArray(prefs(context).getString(AUTOMATIONS, "[]")))
            .put("forecasts", JSONArray(prefs(context).getString(FORECASTS, "[]")))
            .put("resources", JSONArray(prefs(context).getString(RESOURCES, "[]")))
            .put("offlineSubstitutions", JSONArray(prefs(context).getString(OFFLINE, "[]")))
            .put("personalCommands", JSONArray(prefs(context).getString(COMMANDS, "[]")))
            .toString()
    }
}
