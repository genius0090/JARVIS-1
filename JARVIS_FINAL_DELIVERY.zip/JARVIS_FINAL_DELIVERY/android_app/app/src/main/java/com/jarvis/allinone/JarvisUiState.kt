package com.jarvis.allinone

import org.json.JSONObject

data class JarvisUiState(
    val id: String,
    val title: String,
    val status: String,
    val detail: String = "",
    val actionable: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson() = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("status", status)
        .put("detail", detail)
        .put("actionable", actionable)
        .put("timestamp", timestamp)
}
