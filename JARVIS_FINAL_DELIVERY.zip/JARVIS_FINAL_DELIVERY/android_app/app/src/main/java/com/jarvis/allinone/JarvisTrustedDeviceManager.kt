package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisTrustedDeviceManager {

    private const val PREFS = "jarvis_trusted_devices"
    private const val KEY_DEVICES = "devices"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context): JSONObject {
        if (!prefs(context).contains(KEY_DEVICES)) {
            prefs(context).edit()
                .putString(KEY_DEVICES, JSONArray().toString())
                .apply()
        }
        return statusJson(context)
    }

    fun registerDevice(
        context: Context,
        deviceId: String,
        deviceType: String,
        deviceName: String,
        ownerVerified: Boolean
    ): Boolean {
        if (!ownerVerified || deviceId.isBlank()) return false

        val array = JSONArray(prefs(context).getString(KEY_DEVICES, "[]"))

        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).optString("device_id") == deviceId) {
                val item = array.getJSONObject(i)
                item.put("device_type", deviceType)
                item.put("device_name", deviceName)
                item.put("trusted", true)
                item.put("status", "ACTIVE")
                item.put("last_activity", System.currentTimeMillis())
                prefs(context).edit()
                    .putString(KEY_DEVICES, array.toString())
                    .apply()
                return true
            }
        }

        array.put(
            JSONObject()
                .put("device_id", deviceId)
                .put("device_type", deviceType)
                .put("device_name", deviceName)
                .put("trusted", true)
                .put("status", "ACTIVE")
                .put("last_activity", System.currentTimeMillis())
        )

        prefs(context).edit()
            .putString(KEY_DEVICES, array.toString())
            .apply()

        return true
    }

    fun updateActivity(context: Context, deviceId: String): Boolean {
        val array = JSONArray(prefs(context).getString(KEY_DEVICES, "[]"))

        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            if (item.optString("device_id") == deviceId) {
                item.put("last_activity", System.currentTimeMillis())
                prefs(context).edit()
                    .putString(KEY_DEVICES, array.toString())
                    .apply()
                return true
            }
        }

        return false
    }

    fun setTrusted(
        context: Context,
        deviceId: String,
        trusted: Boolean,
        ownerVerified: Boolean
    ): Boolean {
        if (!ownerVerified) return false

        val array = JSONArray(prefs(context).getString(KEY_DEVICES, "[]"))

        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            if (item.optString("device_id") == deviceId) {
                item.put("trusted", trusted)
                item.put("status", if (trusted) "ACTIVE" else "UNTRUSTED")
                item.put("last_activity", System.currentTimeMillis())

                prefs(context).edit()
                    .putString(KEY_DEVICES, array.toString())
                    .apply()

                return true
            }
        }

        return false
    }

    fun devices(context: Context): JSONArray =
        JSONArray(prefs(context).getString(KEY_DEVICES, "[]"))

    fun isTrusted(context: Context, deviceId: String): Boolean {
        val array = devices(context)

        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            if (item.optString("device_id") == deviceId) {
                return item.optBoolean("trusted", false) &&
                    item.optString("status") == "ACTIVE"
            }
        }

        return false
    }

    fun statusJson(context: Context): JSONObject {
        val array = devices(context)

        return JSONObject()
            .put("device_count", array.length())
            .put("devices", array)
            .put("device_management", "ENABLED")
            .put("trust_management", "ENABLED")
            .put("revoke_boundary", "ENABLED")
            .put("plaintext_secrets_stored", false)
    }

    fun healthCheck(context: Context): JSONObject {
        return JSONObject()
            .put("trusted_device_management", "IMPLEMENTED")
            .put("device_list", "ENABLED")
            .put("device_type", "ENABLED")
            .put("device_status", "ENABLED")
            .put("last_activity", "ENABLED")
            .put("trust_state", "ENABLED")
            .put("trusted_device_revoke_boundary", "ENABLED")
            .put("owner_verification_gate", "ENABLED")
            .put("plaintext_secrets", "NOT STORED")
    }
}
