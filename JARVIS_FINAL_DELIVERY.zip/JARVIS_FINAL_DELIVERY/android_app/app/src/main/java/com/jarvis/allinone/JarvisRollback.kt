package com.jarvis.allinone

object JarvisRollback {
    data class Snapshot(val id:String,val createdAt:Long=System.currentTimeMillis())

    private val snapshots=ArrayDeque<Snapshot>()

    fun create(id:String):Snapshot{
        val s=Snapshot(id)
        snapshots.addLast(s)
        if(snapshots.size>20) snapshots.removeFirst()
        return s
    }

    fun latest()=snapshots.lastOrNull()
    fun all()=snapshots.toList()
    fun clear()=snapshots.clear()
}
