package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisCrossDeviceHandoff {

    private const val PREFS = "jarvis_cross_device_handoff"
    private const val HANDOFFS = "handoffs"

    data class Handoff(
        val id: String,
        val sourceDevice: String,
        val targetDevice: String,
        val task: String,
        val context: String,
        val timestamp: Long
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun read(context: Context): JSONArray =
        JSONArray(prefs(context).getString(HANDOFFS, "[]") ?: "[]")

    private fun write(context: Context, data: JSONArray) {
        prefs(context).edit().putString(HANDOFFS, data.toString()).apply()
    }

    fun createHandoff(
        context: Context,
        sourceDevice: String,
        targetDevice: String,
        task: String,
        taskContext: String
    ): Handoff {
        val id = "handoff_${System.currentTimeMillis()}"

        val item = JSONObject()
            .put("id", id)
            .put("sourceDevice", sourceDevice)
            .put("targetDevice", targetDevice)
            .put("task", task)
            .put("context", taskContext)
            .put("timestamp", System.currentTimeMillis())

        val data = read(context)
        data.put(item)
        write(context, data)

        return Handoff(
            id,
            sourceDevice,
            targetDevice,
            task,
            taskContext,
            item.getLong("timestamp")
        )
    }

    fun latest(context: Context): Handoff? {
        val data = read(context)
        if (data.length() == 0) return null

        val item = data.getJSONObject(data.length() - 1)

        return Handoff(
            item.getString("id"),
            item.getString("sourceDevice"),
            item.getString("targetDevice"),
            item.getString("task"),
            item.getString("context"),
            item.getLong("timestamp")
        )
    }

    fun history(context: Context): List<Handoff> {
        val data = read(context)
        val result = mutableListOf<Handoff>()

        for (i in 0 until data.length()) {
            val item = data.getJSONObject(i)
            result.add(
                Handoff(
                    item.getString("id"),
                    item.getString("sourceDevice"),
                    item.getString("targetDevice"),
                    item.getString("task"),
                    item.getString("context"),
                    item.getLong("timestamp")
                )
            )
        }

        return result
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(HANDOFFS).apply()
    }

    fun status(context: Context): String =
        JSONObject()
            .put("handoffs", read(context))
            .put("count", read(context).length())
            .toString()
}
