package com.jarvis.allinone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class JarvisShareReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Share-action foundation; actual content remains protected
        // until JARVIS processes the user's explicit request.
    }
}
