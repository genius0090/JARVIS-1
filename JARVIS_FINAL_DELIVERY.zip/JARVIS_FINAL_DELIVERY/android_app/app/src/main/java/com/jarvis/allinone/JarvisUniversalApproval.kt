package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisUniversalApproval {
    enum class Level { NORMAL, SENSITIVE, HIGH_IMPACT }

    data class Request(
        val action: String,
        val reason: String,
        val impact: String,
        val level: Level = Level.NORMAL
    )

    private var current: Request? = null
    private var approved = false

    fun request(
        action: String,
        reason: String,
        impact: String,
        level: Level = Level.NORMAL
    ): Request {
        val r = Request(action, reason, impact, level)
        current = r
        approved = false
        return r
    }

    fun requiresApproval(level: Level): Boolean =
        level != Level.NORMAL

    fun allow(): Boolean {
        approved = true
        return true
    }

    fun deny() {
        approved = false
    }

    fun isApproved(): Boolean = approved
    fun currentRequest(): Request? = current

    fun clear() {
        current = null
        approved = false
    }

    fun status(): String =
        current?.let { "Approval pending: ${it.action}" } ?: "No approval pending"
}
