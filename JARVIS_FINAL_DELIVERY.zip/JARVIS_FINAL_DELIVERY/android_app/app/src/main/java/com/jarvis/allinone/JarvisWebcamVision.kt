package com.jarvis.allinone

object JarvisWebcamVision {
    private var enabled=false
    private var lastDescription:String?=null

    fun activate(){enabled=true}
    fun deactivate(){enabled=false}
    fun isActive()=enabled

    fun analyze(description:String):String?{
        if(!enabled)return null
        lastDescription=description
        return description
    }

    fun lastResult()=lastDescription
}
