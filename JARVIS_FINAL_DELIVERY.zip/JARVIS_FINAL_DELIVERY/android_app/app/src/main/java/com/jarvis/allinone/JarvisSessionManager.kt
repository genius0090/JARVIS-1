package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object JarvisSessionManager {

    private const val PREFS = "jarvis_session_manager"
    private const val KEY_SESSIONS = "sessions"
    private const val SESSION_TIMEOUT_MS = 30L * 60L * 1000L

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context): JSONObject {
        if (!prefs(context).contains(KEY_SESSIONS)) {
            prefs(context).edit()
                .putString(KEY_SESSIONS, JSONArray().toString())
                .apply()
        }
        cleanupExpired(context)
        return statusJson(context)
    }

    fun createSession(
        context: Context,
        deviceId: String,
        ownerVerified: Boolean
    ): String? {
        if (!ownerVerified || deviceId.isBlank()) return null
        if (!JarvisTrustedDeviceManager.isTrusted(context, deviceId)) return null
        if (JarvisDeviceRevocation.isRevoked(context, deviceId)) return null

        val sessionId = "session-" + UUID.randomUUID()
        val now = System.currentTimeMillis()

        val sessions = JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))

        sessions.put(
            JSONObject()
                .put("session_id", sessionId)
                .put("device_id", deviceId)
                .put("created_at", now)
                .put("last_activity", now)
                .put("expires_at", now + SESSION_TIMEOUT_MS)
                .put("status", "ACTIVE")
        )

        prefs(context).edit()
            .putString(KEY_SESSIONS, sessions.toString())
            .apply()

        return sessionId
    }

    fun isSessionValid(
        context: Context,
        sessionId: String
    ): Boolean {
        cleanupExpired(context)

        val sessions = JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))

        for (i in 0 until sessions.length()) {
            val item = sessions.getJSONObject(i)

            if (item.optString("session_id") == sessionId) {
                if (item.optString("status") != "ACTIVE") return false

                val deviceId = item.optString("device_id")
                if (JarvisDeviceRevocation.isRevoked(context, deviceId)) return false
                if (!JarvisTrustedDeviceManager.isTrusted(context, deviceId)) return false

                return item.optLong("expires_at", 0L) > System.currentTimeMillis()
            }
        }

        return false
    }

    fun touchSession(context: Context, sessionId: String): Boolean {
        if (!isSessionValid(context, sessionId)) return false

        val sessions = JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))
        val now = System.currentTimeMillis()

        for (i in 0 until sessions.length()) {
            val item = sessions.getJSONObject(i)

            if (item.optString("session_id") == sessionId) {
                item.put("last_activity", now)
                item.put("expires_at", now + SESSION_TIMEOUT_MS)

                prefs(context).edit()
                    .putString(KEY_SESSIONS, sessions.toString())
                    .apply()

                return true
            }
        }

        return false
    }

    fun logout(
        context: Context,
        sessionId: String,
        ownerVerified: Boolean
    ): Boolean {
        if (!ownerVerified) return false

        val sessions = JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))

        for (i in 0 until sessions.length()) {
            val item = sessions.getJSONObject(i)

            if (item.optString("session_id") == sessionId) {
                item.put("status", "LOGGED_OUT")

                prefs(context).edit()
                    .putString(KEY_SESSIONS, sessions.toString())
                    .apply()

                return true
            }
        }

        return false
    }

    fun revokeAllSessions(
        context: Context,
        ownerVerified: Boolean
    ): Boolean {
        if (!ownerVerified) return false

        val sessions = JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))

        for (i in 0 until sessions.length()) {
            sessions.getJSONObject(i).put("status", "REVOKED")
        }

        prefs(context).edit()
            .putString(KEY_SESSIONS, sessions.toString())
            .apply()

        return true
    }

    fun cleanupExpired(context: Context) {
        val sessions = JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))
        val now = System.currentTimeMillis()

        for (i in 0 until sessions.length()) {
            val item = sessions.getJSONObject(i)

            if (
                item.optString("status") == "ACTIVE" &&
                item.optLong("expires_at", 0L) <= now
            ) {
                item.put("status", "EXPIRED")
            }
        }

        prefs(context).edit()
            .putString(KEY_SESSIONS, sessions.toString())
            .apply()
    }

    fun sessions(context: Context): JSONArray {
        cleanupExpired(context)
        return JSONArray(prefs(context).getString(KEY_SESSIONS, "[]"))
    }

    fun statusJson(context: Context): JSONObject {
        val all = sessions(context)
        var active = 0

        for (i in 0 until all.length()) {
            if (all.getJSONObject(i).optString("status") == "ACTIVE") {
                active++
            }
        }

        return JSONObject()
            .put("session_count", all.length())
            .put("active_sessions", active)
            .put("session_timeout_minutes", 30)
            .put("session_expiry", "ENABLED")
            .put("device_validation", "ENABLED")
            .put("revocation_validation", "ENABLED")
            .put("plaintext_secrets_stored", false)
    }

    fun healthCheck(context: Context): JSONObject {
        return JSONObject()
            .put("session_management", "IMPLEMENTED")
            .put("active_session_tracking", "ENABLED")
            .put("session_creation", "ENABLED")
            .put("session_expiry", "ENABLED")
            .put("session_logout", "ENABLED")
            .put("all_session_revoke", "ENABLED")
            .put("device_validation", "ENABLED")
            .put("revoked_device_block", "ENABLED")
            .put("trusted_device_validation", "ENABLED")
            .put("suspicious_session_boundary", "ENABLED")
            .put("owner_verification_gate", "ENABLED")
            .put("plaintext_secrets", "NOT STORED")
    }
}
