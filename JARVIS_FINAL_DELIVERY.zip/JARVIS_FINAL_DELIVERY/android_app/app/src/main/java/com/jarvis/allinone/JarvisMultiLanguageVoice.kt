package com.jarvis.allinone

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object JarvisMultiLanguageVoice {

    enum class Language {
        AUTO,
        HINDI,
        ENGLISH
    }

    private var selectedLanguage = Language.AUTO
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun setLanguage(language: Language) {
        selectedLanguage = language
    }

    fun getLanguage(): Language = selectedLanguage

    fun detectLanguage(text: String): Language {
        if (selectedLanguage != Language.AUTO) return selectedLanguage

        return if (Regex("[\\u0900-\\u097F]").containsMatchIn(text)) {
            Language.HINDI
        } else {
            Language.ENGLISH
        }
    }

    private fun localeFor(language: Language): Locale {
        return when (language) {
            Language.HINDI -> Locale("hi", "IN")
            Language.ENGLISH -> Locale.US
            Language.AUTO -> Locale.US
        }
    }

    fun initialize(
        context: Context,
        onReady: ((Boolean) -> Unit)? = null
    ) {
        tts?.shutdown()
        ttsReady = false

        tts = TextToSpeech(context.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            onReady?.invoke(ttsReady)
        }
    }

    fun speak(
        context: Context,
        text: String,
        onReady: ((Boolean) -> Unit)? = null
    ) {
        if (text.isBlank()) {
            onReady?.invoke(false)
            return
        }

        if (!ttsReady || tts == null) {
            initialize(context) { ready ->
                if (ready) {
                    speakInternal(text)
                }
                onReady?.invoke(ready)
            }
        } else {
            speakInternal(text)
            onReady?.invoke(true)
        }
    }

    private fun speakInternal(text: String) {
        val engine = tts ?: return
        val locale = localeFor(detectLanguage(text))

        val result = engine.setLanguage(locale)

        if (result == TextToSpeech.LANG_MISSING_DATA ||
            result == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            return
        }


        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                JarvisSelfEchoProtection.onSpeechStarted()
            }

            override fun onDone(utteranceId: String?) {
                JarvisSelfEchoProtection.onSpeechFinished()
            }

            override fun onError(utteranceId: String?) {
                JarvisSelfEchoProtection.onSpeechFinished()
            }
        })

        engine.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "JARVIS_MULTI_LANGUAGE"
        )
    }

    fun supportedLanguages(): List<String> {
        val engine = tts ?: return emptyList()

        val result = mutableListOf<String>()

        val locales = listOf(
            Locale.US,
            Locale.UK,
            Locale("hi", "IN")
        )

        locales.forEach { locale ->
            val support = engine.isLanguageAvailable(locale)

            if (support >= TextToSpeech.LANG_AVAILABLE) {
                result += locale.displayLanguage
            }
        }

        return result.distinct()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    fun summary(): String {
        return """
            JARVIS MULTI-LANGUAGE VOICE

            Mode: $selectedLanguage
            Hindi: READY
            English: READY
            Auto Detection: READY
            TTS Engine: ${if (ttsReady) "READY" else "INITIALIZATION REQUIRED"}
        """.trimIndent()
    }
}
