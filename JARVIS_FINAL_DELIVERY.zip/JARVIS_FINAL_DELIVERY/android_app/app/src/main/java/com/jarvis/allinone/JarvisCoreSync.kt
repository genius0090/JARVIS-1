package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

/** Central-core synchronization boundary for device-independent JARVIS state. */
object JarvisCoreSync {
    private const val PREFS = "jarvis_core_sync"
    private const val KEY_REVISION = "core_revision"

    fun revision(context: Context): Long = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_REVISION, 0L)

    fun sync(context: Context): JSONObject {
        JarvisCentralMemory.initialize(context)
        val payload = JSONObject()
            .put("revision", revision(context))
            .put("memory", snapshot(context))
        val response = JarvisRemoteCoreClient.sync(context, payload)
        if (response.optBoolean("ok", false)) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(KEY_REVISION, response.optLong("revision", revision(context)))
                .apply()
            JarvisAuditTrail.record("CORE_SYNC", if (response.optBoolean("conflict", false)) "CONFLICT" else "SUCCESS")
        }
        return response
    }

    fun snapshot(context: Context): JSONObject {
        val memory = JarvisCentralMemory.allMemories(context).map { it.toJson() }
        val conversations = JarvisCentralMemory.conversations(context).map { it.toJson() }
        return JSONObject()
            .put("memory_id", JarvisCentralMemory.memoryId(context))
            .put("memories", org.json.JSONArray(memory))
            .put("conversations", org.json.JSONArray(conversations))
    }

    fun status(context: Context): JSONObject = JSONObject()
        .put("sync_enabled", true)
        .put("remote_configured", JarvisRemoteCoreClient.baseUrl(context).isNotBlank())
        .put("revision", revision(context))
        .put("offline_fallback", true)
        .put("conflict_safe", true)
}
