package com.jarvis.allinone

object JarvisSelfEchoProtection {
    @Volatile private var speaking = false
    @Volatile private var mutedForListening = false

    fun onSpeechStarted() {
        speaking = true
        mutedForListening = true
    }

    fun onSpeechFinished() {
        speaking = false
        mutedForListening = false
    }

    fun shouldIgnoreInput(): Boolean =
        speaking || mutedForListening

    fun isSpeaking(): Boolean = speaking

    fun reset() {
        speaking = false
        mutedForListening = false
    }

    fun status(): String =
        if (shouldIgnoreInput()) "Self-echo protection active"
        else "Self-echo protection ready"
}
