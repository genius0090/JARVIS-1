package com.jarvis.allinone

import android.content.Context

/** Local/private model policy. It selects policy; it does not pretend to install models. */
object JarvisPrivateAIModels {
    enum class Mode { LOCAL, ONLINE, AUTO }
    private const val PREFS = "jarvis_private_ai_models"
    private const val KEY_MODE = "mode"

    fun setMode(context: Context, value: Mode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MODE, value.name).apply()
    }

    fun mode(context: Context): Mode = runCatching {
        Mode.valueOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MODE, Mode.AUTO.name) ?: Mode.AUTO.name)
    }.getOrDefault(Mode.AUTO)

    fun shouldUseLocal(context: Context, sensitive: Boolean = false): Boolean =
        sensitive || mode(context) == Mode.LOCAL
}
