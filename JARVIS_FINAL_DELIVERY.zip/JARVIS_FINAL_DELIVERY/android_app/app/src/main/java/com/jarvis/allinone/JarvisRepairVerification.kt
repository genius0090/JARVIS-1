package com.jarvis.allinone

object JarvisRepairVerification {
    data class Verification(val repaired:Boolean,val verified:Boolean,val message:String)

    fun verify(repaired:Boolean,testPassed:Boolean,message:String)=
        Verification(repaired,testPassed,message)
}
