package com.jarvis.allinone

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

object JarvisBrowserManager {

    fun openUrl(context: Context, url: String): Boolean {
        val clean = url.trim()
        if (clean.isEmpty()) return false

        val finalUrl = when {
            clean.startsWith("http://") || clean.startsWith("https://") -> clean
            else -> "https://$clean"
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl))
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun searchWeb(context: Context, query: String): Boolean {
        val q = query.trim()
        if (q.isEmpty()) return false

        val encoded = URLEncoder.encode(q, "UTF-8")
        return openUrl(
            context,
            "https://www.google.com/search?q=$encoded"
        )
    }

    fun handleCommand(context: Context, command: String): Boolean {
        val text = command.trim()
        if (text.isEmpty()) return false

        val lower = text.lowercase()

        return when {
            lower.startsWith("http://") ||
            lower.startsWith("https://") -> openUrl(context, text)

            lower.startsWith("open website ") ->
                openUrl(context, text.removePrefix("open website ").trim())

            lower.startsWith("open site ") ->
                openUrl(context, text.removePrefix("open site ").trim())

            lower.startsWith("search web ") ->
                searchWeb(context, text.removePrefix("search web ").trim())

            lower.startsWith("search ") ->
                searchWeb(context, text.removePrefix("search ").trim())

            lower.startsWith("google ") ->
                searchWeb(context, text.removePrefix("google ").trim())

            else -> false
        }
    }
}
