package com.jarvis.allinone

object JarvisLoopProtection {
    private val counts=mutableMapOf<String,Int>()
    private var maxAttempts=3

    fun setMaxAttempts(value:Int){maxAttempts=value.coerceAtLeast(1)}

    fun allow(task:String):Boolean{
        val count=(counts[task]?:0)+1
        counts[task]=count
        return count<=maxAttempts
    }

    fun reset(task:String){counts.remove(task)}
    fun clear(){counts.clear()}
}
