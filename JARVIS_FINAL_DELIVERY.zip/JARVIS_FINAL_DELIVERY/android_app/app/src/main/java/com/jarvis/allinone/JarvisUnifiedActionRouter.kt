package com.jarvis.allinone

object JarvisUnifiedActionRouter {
    enum class Route {
        CHAT, VOICE, MEMORY, FILES, STORAGE, BROWSER,
        VISION, PC, SYSTEM, MEDIA, DATA, PLANNING,
        SECURITY, REPAIR, TERMINAL, SANDBOX, CREATION,
        OSINT, AIR_VISUAL, DEVICE, RECOVERY, PROACTIVE,
        UNKNOWN
    }

    data class Decision(
        val route: Route,
        val reason: String,
        val requiresApproval: Boolean = false
    )

    fun route(
        intent: String,
        sensitive: Boolean = false
    ): Decision {
        val text = intent.lowercase()

        val route = when {
            text.contains("terminal") || text.contains("command line") || text.contains("shell") -> Route.TERMINAL
            text.contains("sandbox") || text.contains("simulate") || text.contains("simulation") || text.contains("safe test") -> Route.SANDBOX
            text.contains("air visual") || text.contains("hologram") || text.contains("projection") -> Route.AIR_VISUAL
            text.contains("osint") || text.contains("recon") || text.contains("threat") || text.contains("security analysis") -> Route.OSINT
            text.contains("proactive") || text.contains("briefing") || text.contains("monitor") -> Route.PROACTIVE
            text.contains("video") || text.contains("audio") || text.contains("youtube") || text.contains("movie") || text.contains("timeline") || text.contains("edit video") -> Route.MEDIA
            text.contains("document") || text.contains("presentation") || text.contains("spreadsheet") || text.contains("website") || text.contains("create") -> Route.CREATION
            text.contains("pc") || text.contains("computer") -> Route.PC
            text.contains("call ") || text.startsWith("dial ") || text.contains("phone call") || text.contains("sms ") || text.contains("text message") || text.contains("calendar") || text.contains("wifi") || text.contains("wi-fi") || text.contains("bluetooth") || text.contains("location settings") || text.contains("sound settings") || text.contains("display settings") -> Route.DEVICE
            text.contains("trusted device") || text.contains("laptop") || text.contains("phone") -> Route.DEVICE
            text.contains("recovery") || text.contains("lost phone") || text.contains("restore") -> Route.RECOVERY
            text.contains("security") || text.contains("permission") -> Route.SECURITY
            text.contains("repair") || text.contains("fix") -> Route.REPAIR
            text.contains("camera") || text.contains("image") || text.contains("object") || text.contains("webcam") -> Route.VISION
            text.contains("data") || text.contains("csv") -> Route.DATA
            text.contains("plan") || text.contains("steps") -> Route.PLANNING
            text.contains("memory") || text.contains("remember") -> Route.MEMORY
            text.contains("file") || text.contains("folder") -> Route.FILES
            text.contains("storage") || text.contains("download") -> Route.STORAGE
            text.contains("website") || text.contains("browser") || text.contains("search") -> Route.BROWSER
            text.contains("battery") || text.contains("settings") -> Route.SYSTEM
            else -> Route.CHAT
        }

        return Decision(
            route = route,
            reason = "Context-based capability routing",
            requiresApproval = sensitive
        )
    }
}
