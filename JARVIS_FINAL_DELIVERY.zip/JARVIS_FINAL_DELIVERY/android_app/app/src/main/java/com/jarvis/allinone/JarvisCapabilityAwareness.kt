package com.jarvis.allinone

/** Truthful capability registry: source support is not confused with runtime availability. */
object JarvisCapabilityAwareness {
    enum class State { AVAILABLE, CONFIGURED_BUT_UNVERIFIED, EXTERNAL_DEPENDENCY, NOT_AVAILABLE }

    private val capabilities = linkedMapOf(
        "voice" to State.CONFIGURED_BUT_UNVERIFIED,
        "memory" to State.AVAILABLE,
        "browser" to State.AVAILABLE,
        "files" to State.AVAILABLE,
        "storage" to State.AVAILABLE,
        "downloads" to State.AVAILABLE,
        "vision" to State.CONFIGURED_BUT_UNVERIFIED,
        "pc_bridge" to State.CONFIGURED_BUT_UNVERIFIED,
        "security" to State.AVAILABLE,
        "self_repair" to State.CONFIGURED_BUT_UNVERIFIED,
        "planning" to State.AVAILABLE,
        "reasoning" to State.CONFIGURED_BUT_UNVERIFIED,
        "media" to State.EXTERNAL_DEPENDENCY,
        "ffmpeg" to State.EXTERNAL_DEPENDENCY,
        "air_visual" to State.EXTERNAL_DEPENDENCY,
        "remote_core" to State.EXTERNAL_DEPENDENCY
    )

    fun state(name: String): State = capabilities[name.trim().lowercase()] ?: State.NOT_AVAILABLE
    fun isAvailable(name: String): Boolean = state(name) == State.AVAILABLE
    fun available(): List<String> = capabilities.filterValues { it == State.AVAILABLE }.keys.toList()
    fun all(): Map<String, State> = capabilities.toMap()

    fun explain(name: String): String = when (val s = state(name)) {
        State.AVAILABLE -> "$name: available"
        State.CONFIGURED_BUT_UNVERIFIED -> "$name: source/configuration present; runtime verification pending"
        State.EXTERNAL_DEPENDENCY -> "$name: requires external runtime/hardware/service"
        State.NOT_AVAILABLE -> "$name: not available"
    }

    fun status(): String = capabilities.entries.joinToString("\n") { "${it.key}: ${it.value.name}" }
}
