package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

/** Persistent owner preference memory; authentication secrets are excluded. */
object JarvisPreferenceMemory {
    private const val PREFS = "jarvis_preference_memory"
    private const val KEY_VALUES = "values"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun set(context: Context, key: String, value: String) {
        if (key.isBlank()) return
        val json = JSONObject(prefs(context).getString(KEY_VALUES, "{}") ?: "{}")
        json.put(key.take(200), value.take(5000))
        prefs(context).edit().putString(KEY_VALUES, json.toString()).apply()
    }

    fun get(context: Context, key: String): String? =
        JSONObject(prefs(context).getString(KEY_VALUES, "{}") ?: "{}").optString(key, null)

    fun all(context: Context): Map<String, String> {
        val json = JSONObject(prefs(context).getString(KEY_VALUES, "{}") ?: "{}")
        val out = linkedMapOf<String, String>()
        json.keys().forEach { k -> out[k] = json.optString(k) }
        return out
    }

    fun remove(context: Context, key: String) {
        val json = JSONObject(prefs(context).getString(KEY_VALUES, "{}") ?: "{}")
        json.remove(key)
        prefs(context).edit().putString(KEY_VALUES, json.toString()).apply()
    }

    fun clear(context: Context) = prefs(context).edit().remove(KEY_VALUES).apply()
}
