package com.jarvis.allinone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

object JarvisSpeechInput {

    const val REQUEST_CODE = 7319

    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private var pendingActivity: Activity? = null
    private var pendingStart: (() -> Unit)? = null

    private var stateCallback: ((State) -> Unit)? = null
    private var resultCallback: ((String) -> Unit)? = null
    private var errorCallback: ((String) -> Unit)? = null
    private var rmsCallback: ((Float) -> Unit)? = null

    enum class State {
        IDLE,
        LISTENING,
        THINKING,
        ERROR
    }

    fun isAvailable(activity: Activity): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(activity)
    }

    fun start(
        activity: Activity,
        onState: ((State) -> Unit)? = null,
        onResult: ((String) -> Unit)? = null,
        onError: ((String) -> Unit)? = null,
        onRms: ((Float) -> Unit)? = null
    ) {
        stateCallback = onState
        resultCallback = onResult
        errorCallback = onError
        rmsCallback = onRms
        pendingActivity = activity

        if (!isAvailable(activity)) {
            emitError("Android speech recognition is unavailable")
            return
        }

        if (
            activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingStart = {
                startInternal(activity)
            }
            activity.requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_CODE
            )
            return
        }

        startInternal(activity)
    }

    fun onPermissionResult(
        activity: Activity,
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ): Boolean {
        if (requestCode != REQUEST_CODE) return false

        if (
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            val action = pendingStart
            pendingStart = null
            action?.invoke()
        } else {
            pendingStart = null
            emitError("Microphone permission is required for JARVIS voice input")
        }

        return true
    }

    private fun startInternal(activity: Activity) {
        stopInternal()

        val sr = SpeechRecognizer.createSpeechRecognizer(activity)
        recognizer = sr
        listening = true

        sr.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: Bundle?) {
                emitState(State.LISTENING)
            }

            override fun onBeginningOfSpeech() {
                emitState(State.LISTENING)
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Normalize typical Android dB values into a 0..1 visual intensity.
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                rmsCallback?.invoke(normalized)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                emitState(State.THINKING)
            }

            override fun onError(error: Int) {
                listening = false
                val message = when (error) {
                    SpeechRecognizer.ERROR_AUDIO ->
                        "Microphone audio error"
                    SpeechRecognizer.ERROR_CLIENT ->
                        "Speech recognition client error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Microphone permission denied"
                    SpeechRecognizer.ERROR_NETWORK ->
                        "Speech recognition network error"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Speech recognition network timeout"
                    SpeechRecognizer.ERROR_NO_MATCH ->
                        "I could not understand that"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                        "Speech recognizer is busy"
                    SpeechRecognizer.ERROR_SERVER ->
                        "Speech recognition server error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "No speech detected"
                    else ->
                        "Speech recognition error: $error"
                }
                emitError(message)
                cleanup()
            }

            override fun onResults(results: Bundle?) {
                listening = false

                val matches =
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)

                val text = matches
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()

                if (text.isBlank()) {
                    emitError("No command was recognized")
                } else {
                    emitState(State.THINKING)
                    resultCallback?.invoke(text)
                }

                cleanup()
            }

            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val languageTag = when (JarvisMixedVoice.getLanguage()) {
            JarvisMixedVoice.Language.HINDI ->
                Locale("hi", "IN").toLanguageTag()

            JarvisMixedVoice.Language.ENGLISH ->
                Locale("en", "IN").toLanguageTag()

            JarvisMixedVoice.Language.MIXED,
            JarvisMixedVoice.Language.AUTO -> {
                val system = Locale.getDefault()
                if (system.language == "hi") {
                    Locale("hi", "IN").toLanguageTag()
                } else {
                    Locale("en", "IN").toLanguageTag()
                }
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }

        if (JarvisSelfEchoProtection.shouldIgnoreInput()) {
            cleanup()
            emitError("Voice input temporarily muted while JARVIS is speaking")
            return
        }

        emitState(State.LISTENING)
        sr.startListening(intent)
    }

    fun stop() {
        stopInternal()
        emitState(State.IDLE)
    }

    private fun stopInternal() {
        try {
            recognizer?.stopListening()
        } catch (_: Throwable) {
        }

        try {
            recognizer?.cancel()
        } catch (_: Throwable) {
        }

        try {
            recognizer?.destroy()
        } catch (_: Throwable) {
        }

        recognizer = null
        listening = false
    }

    private fun cleanup() {
        try {
            recognizer?.destroy()
        } catch (_: Throwable) {
        }

        recognizer = null
        listening = false
        pendingActivity = null
    }

    private fun emitState(state: State) {
        stateCallback?.invoke(state)
    }

    private fun emitError(message: String) {
        emitState(State.ERROR)
        errorCallback?.invoke(message)
    }

    fun isListening(): Boolean = listening

    fun status(): String =
        if (listening) "Speech input: LISTENING"
        else "Speech input: IDLE"
}
