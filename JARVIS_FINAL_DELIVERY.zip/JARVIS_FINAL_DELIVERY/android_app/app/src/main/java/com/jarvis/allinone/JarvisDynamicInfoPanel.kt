package com.jarvis.allinone

object JarvisDynamicInfoPanel {
    data class Info(
        val title: String,
        val detail: String,
        val state: String = "INFO"
    )

    private var current: Info? = null

    fun show(title: String, detail: String, state: String = "INFO"): Info {
        return Info(title, detail, state).also { current = it }
    }

    fun current(): Info? = current

    fun clear() {
        current = null
    }

    fun status(): String =
        current?.let { "${it.title}: ${it.detail}" } ?: "No active information"
}
