package com.jarvis.allinone

object JarvisTelemetry {
    data class Event(
        val name: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    private val events = ArrayDeque<Event>()
    private const val MAX_EVENTS = 500

    fun record(name: String) {
        if (events.size >= MAX_EVENTS) events.removeFirst()
        events.addLast(Event(name))
    }

    fun recent(limit: Int = 50): List<Event> =
        events.toList().takeLast(limit.coerceAtLeast(1))

    fun clear() = events.clear()

    fun status(): String = "${events.size} local events"
}
