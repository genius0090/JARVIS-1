package com.jarvis.allinone

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Real local OOXML/website artifact generation without pretending that a JSON record is a file. */
object JarvisOfficeArtifactEngine {
    data class Artifact(val success: Boolean, val type: String, val path: String = "", val sha256: String = "", val error: String = "")

    private fun root(context: Context): File = File(context.filesDir, "jarvis_artifacts").apply { mkdirs() }
    private fun safe(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]+"), "_").take(80).ifBlank { "artifact" }

    fun document(context: Context, title: String, content: String): Artifact {
        val file = File(root(context), "${safe(title)}.docx")
        val xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${paragraphs(content)}</w:body></w:document>"""
        val ok = zip(file, mapOf(
            "[Content_Types].xml" to contentTypes("word/document.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"),
            "_rels/.rels" to rels("rId1", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "word/document.xml"),
            "word/document.xml" to xml
        ))
        return result(file, "DOCX", ok)
    }

    fun spreadsheet(context: Context, name: String, columns: List<String>, rows: List<List<String>>): Artifact {
        val file = File(root(context), "${safe(name)}.xlsx")
        fun cell(v: String, ref: String) = "<c r=\"$ref\" t=\"inlineStr\"><is><t>${escapeXml(v)}</t></is></c>"
        fun col(n: Int): String { var x=n; var s=""; do { s=('A'.code + (x%26)).toChar()+s; x=x/26-1 } while(x>=0); return s }
        val rowsXml = buildString {
            append("<row r=\"1\">")
            columns.forEachIndexed { i, v -> append(cell(v, "${col(i)}1")) }
            append("</row>")
            rows.forEachIndexed { ri, row -> append("<row r=\"${ri+2}\">"); row.forEachIndexed { i,v -> append(cell(v,"${col(i)}${ri+2}")) }; append("</row>") }
        }
        val sheet="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$rowsXml</sheetData></worksheet>"""
        val workbook="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>"""
        val ok = zip(file, mapOf(
            "[Content_Types].xml" to contentTypes("xl/workbook.xml", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml", "xl/worksheets/sheet1.xml"),
            "_rels/.rels" to rels("rId1", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "xl/workbook.xml"),
            "xl/workbook.xml" to workbook,
            "xl/_rels/workbook.xml.rels" to rels("rId1", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "worksheets/sheet1.xml"),
            "xl/worksheets/sheet1.xml" to sheet
        ))
        return result(file, "XLSX", ok)
    }

    fun presentation(context: Context, title: String, slides: List<String>): Artifact {
        val file = File(root(context), "${safe(title)}.pptx")
        val slideXml = { text: String -> """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Text"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US"/><a:t>${escapeXml(text)}</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr/></p:sld>""" }
        val entries=linkedMapOf<String,String>()
        entries["[Content_Types].xml"]="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>${slides.indices.joinToString(""){i->"<Override PartName=\"/ppt/slides/slide${i+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>"}}</Types>"""
        entries["_rels/.rels"]=rels("rId1","http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument","ppt/presentation.xml")
        val slideIds=slides.indices.joinToString(""){i->"<p:sldId id=\"${256+i}\" r:id=\"rId${i+1}\"/>"}
        entries["ppt/presentation.xml"]="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst/><p:sldIdLst>$slideIds</p:sldIdLst><p:sldSz cx="12192000" cy="6858000" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>"""
        val relsXml=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        slides.forEachIndexed{i,_->relsXml.append("<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide${i+1}.xml\"/>")}
        relsXml.append("</Relationships>")
        entries["ppt/_rels/presentation.xml.rels"]=relsXml.toString()
        slides.forEachIndexed{i,t->entries["ppt/slides/slide${i+1}.xml"]=slideXml(t)}
        val ok=zip(file,entries)
        return result(file,"PPTX",ok)
    }

    fun website(context: Context, name: String, html: String, css: String = "", js: String = ""): Artifact {
        val dir=File(root(context),safe(name)).apply{mkdirs()}
        File(dir,"index.html").writeText(html)
        File(dir,"style.css").writeText(css)
        File(dir,"app.js").writeText(js)
        val zipFile=File(root(context),"${safe(name)}.zip")
        val ok=zipDirectory(dir,zipFile)
        return result(zipFile,"WEBSITE_ZIP",ok)
    }

    private fun paragraphs(content:String):String=content.lines().joinToString(""){ "<w:p><w:r><w:t>${escapeXml(it)}</w:t></w:r></w:p>" } + "<w:sectPr/>"
    private fun escapeXml(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun contentTypes(main:String, mainType:String, extra:String?=null):String="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/$main" ContentType="$mainType"/>${if(extra!=null)"<Override PartName=\"/$extra\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" else ""}</Types>"""
    private fun rels(id:String,type:String,target:String)="""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="$id" Type="$type" Target="$target"/></Relationships>"""
    private fun zip(file:File, entries:Map<String,String>):Boolean=try{ZipOutputStream(file.outputStream()).use{z->entries.forEach{(n,v)->z.putNextEntry(ZipEntry(n));z.write(v.toByteArray());z.closeEntry()}};true}catch(_:Throwable){false}
    private fun zipDirectory(dir:File,out:File):Boolean=try{ZipOutputStream(out.outputStream()).use{z->dir.walkTopDown().filter{it.isFile}.forEach{f->z.putNextEntry(ZipEntry(dir.toPath().relativize(f.toPath()).toString()));z.write(f.readBytes());z.closeEntry()}};true}catch(_:Throwable){false}
    private fun result(file:File,type:String,ok:Boolean):Artifact{if(!ok||!file.exists())return Artifact(false,type,error="artifact_generation_failed");val hash=MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString(""){"%02x".format(it)};return Artifact(true,type,file.absolutePath,hash)}
}
