package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * #200 OWNER AUTHENTICATION
 *
 * Authentication control layer.
 *
 * This layer manages:
 * - authentication method registration metadata
 * - authenticated sessions
 * - session expiry
 * - failed-attempt tracking
 * - lockout state
 * - authentication audit events
 *
 * It deliberately does NOT store passwords, biometric data,
 * passkeys, recovery secrets or authentication codes in plaintext.
 *
 * Concrete identity methods are added/configured in #201-#203.
 */
object JarvisOwnerAuthentication {

    private const val PREFS = "jarvis_owner_authentication"

    private const val KEY_AUTHENTICATED = "authenticated"
    private const val KEY_SESSION_ID = "session_id"
    private const val KEY_SESSION_CREATED = "session_created"
    private const val KEY_SESSION_EXPIRES = "session_expires"
    private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
    private const val KEY_LOCKOUT_UNTIL = "lockout_until"
    private const val KEY_METHODS = "methods"

    private const val SESSION_DURATION_MS = 12L * 60L * 60L * 1000L
    private const val MAX_FAILED_ATTEMPTS = 5
    private const val LOCKOUT_DURATION_MS = 5L * 60L * 1000L

    enum class MethodType {
        DEVICE_CREDENTIAL,
        BIOMETRIC,
        PASSKEY,
        AUTHENTICATOR,
        RECOVERY,
        TRUSTED_DEVICE,
        FUTURE
    }

    data class AuthMethod(
        val id: String,
        val type: MethodType,
        val label: String,
        val enabled: Boolean,
        val primary: Boolean
    )

    data class Session(
        val sessionId: String,
        val createdAt: Long,
        val expiresAt: Long
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun initialize(context: Context) {
        val p = prefs(context)

        if (!p.contains(KEY_AUTHENTICATED)) {
            p.edit()
                .putBoolean(KEY_AUTHENTICATED, false)
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_UNTIL, 0L)
                .putString(KEY_METHODS, JSONArray().toString())
                .apply()
        }
    }

    fun isAuthenticated(context: Context): Boolean {
        initialize(context)

        val p = prefs(context)

        if (!p.getBoolean(KEY_AUTHENTICATED, false)) {
            return false
        }

        val expires = p.getLong(KEY_SESSION_EXPIRES, 0L)

        if (expires <= System.currentTimeMillis()) {
            logout(context)
            return false
        }

        return true
    }

    fun isLocked(context: Context): Boolean {
        initialize(context)

        val until = prefs(context).getLong(KEY_LOCKOUT_UNTIL, 0L)

        if (until <= System.currentTimeMillis()) {
            if (until != 0L) {
                prefs(context).edit()
                    .putLong(KEY_LOCKOUT_UNTIL, 0L)
                    .putInt(KEY_FAILED_ATTEMPTS, 0)
                    .apply()
            }
            return false
        }

        return true
    }

    fun registerMethod(
        context: Context,
        type: MethodType,
        label: String,
        primary: Boolean = false
    ): String? {
        initialize(context)

        val cleanLabel = label.trim()

        if (cleanLabel.isBlank() || cleanLabel.length > 80) {
            return null
        }

        val methods = methods(context).toMutableList()

        val id = "AUTH-" + UUID.randomUUID().toString()

        if (primary) {
            for (i in methods.indices) {
                methods[i] = methods[i].copy(primary = false)
            }
        }

        methods.add(
            AuthMethod(
                id = id,
                type = type,
                label = cleanLabel,
                enabled = true,
                primary = primary
            )
        )

        saveMethods(context, methods)

        JarvisAuditTrail.record(
            "AUTH_METHOD_REGISTERED",
            type.name
        )

        return id
    }

    fun setMethodEnabled(
        context: Context,
        methodId: String,
        enabled: Boolean
    ): Boolean {
        val methods = methods(context).toMutableList()

        val index = methods.indexOfFirst { it.id == methodId }

        if (index < 0) return false

        methods[index] = methods[index].copy(enabled = enabled)

        saveMethods(context, methods)

        JarvisAuditTrail.record(
            "AUTH_METHOD_STATE",
            if (enabled) "ENABLED" else "DISABLED"
        )

        return true
    }

    fun methods(context: Context): List<AuthMethod> {
        initialize(context)

        val raw = prefs(context).getString(KEY_METHODS, "[]") ?: "[]"

        return runCatching {
            val array = JSONArray(raw)

            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)

                    val type = runCatching {
                        MethodType.valueOf(
                            item.optString(
                                "type",
                                MethodType.FUTURE.name
                            )
                        )
                    }.getOrDefault(MethodType.FUTURE)

                    add(
                        AuthMethod(
                            id = item.optString("id"),
                            type = type,
                            label = item.optString("label"),
                            enabled = item.optBoolean("enabled"),
                            primary = item.optBoolean("primary")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun saveMethods(
        context: Context,
        methods: List<AuthMethod>
    ) {
        val array = JSONArray()

        methods.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("type", it.type.name)
                    .put("label", it.label)
                    .put("enabled", it.enabled)
                    .put("primary", it.primary)
            )
        }

        prefs(context)
            .edit()
            .putString(KEY_METHODS, array.toString())
            .apply()
    }

    /**
     * Called after a legitimate platform/identity verification succeeds.
     * Actual verification is supplied by #201-#203.
     */
    @Synchronized
    fun authenticationSucceeded(context: Context): Session? {
        initialize(context)

        if (isLocked(context)) {
            JarvisAuditTrail.record(
                "OWNER_AUTH_BLOCKED",
                "LOCKED"
            )
            return null
        }

        val now = System.currentTimeMillis()
        val sessionId = "SESSION-" + UUID.randomUUID().toString()
        val expires = now + SESSION_DURATION_MS

        prefs(context)
            .edit()
            .putBoolean(KEY_AUTHENTICATED, true)
            .putString(KEY_SESSION_ID, sessionId)
            .putLong(KEY_SESSION_CREATED, now)
            .putLong(KEY_SESSION_EXPIRES, expires)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()

        JarvisAuditTrail.record(
            "OWNER_AUTH_SUCCESS",
            "SESSION_CREATED"
        )

        return Session(sessionId, now, expires)
    }

    @Synchronized
    fun authenticationFailed(context: Context) {
        initialize(context)

        if (isLocked(context)) {
            return
        }

        val p = prefs(context)
        val attempts = p.getInt(KEY_FAILED_ATTEMPTS, 0) + 1

        if (attempts >= MAX_FAILED_ATTEMPTS) {
            p.edit()
                .putInt(KEY_FAILED_ATTEMPTS, attempts)
                .putLong(
                    KEY_LOCKOUT_UNTIL,
                    System.currentTimeMillis() + LOCKOUT_DURATION_MS
                )
                .apply()

            JarvisAuditTrail.record(
                "OWNER_AUTH_LOCKOUT",
                "MAX_ATTEMPTS"
            )
        } else {
            p.edit()
                .putInt(KEY_FAILED_ATTEMPTS, attempts)
                .apply()

            JarvisAuditTrail.record(
                "OWNER_AUTH_FAILED",
                "ATTEMPT_$attempts"
            )
        }
    }

    @Synchronized
    fun logout(context: Context) {
        initialize(context)

        prefs(context)
            .edit()
            .putBoolean(KEY_AUTHENTICATED, false)
            .remove(KEY_SESSION_ID)
            .remove(KEY_SESSION_CREATED)
            .remove(KEY_SESSION_EXPIRES)
            .apply()

        JarvisAuditTrail.record(
            "OWNER_LOGOUT",
            "SUCCESS"
        )
    }

    fun currentSession(context: Context): Session? {
        if (!isAuthenticated(context)) return null

        val p = prefs(context)

        return Session(
            sessionId = p.getString(KEY_SESSION_ID, "") ?: "",
            createdAt = p.getLong(KEY_SESSION_CREATED, 0L),
            expiresAt = p.getLong(KEY_SESSION_EXPIRES, 0L)
        )
    }

    fun failedAttempts(context: Context): Int =
        prefs(context).getInt(KEY_FAILED_ATTEMPTS, 0)

    fun statusJson(context: Context): String {
        initialize(context)

        val session = currentSession(context)

        return JSONObject()
            .put(
                "ownerAccount",
                JarvisPermanentOwnerAccount.isInitialized(context)
            )
            .put("authenticated", isAuthenticated(context))
            .put("locked", isLocked(context))
            .put("failedAttempts", failedAttempts(context))
            .put("methodCount", methods(context).size)
            .put(
                "session",
                session?.let {
                    JSONObject()
                        .put("id", it.sessionId)
                        .put("createdAt", it.createdAt)
                        .put("expiresAt", it.expiresAt)
                }
            )
            .toString()
    }

    fun healthCheck(context: Context): Boolean {
        initialize(context)

        return JarvisPermanentOwnerAccount.isInitialized(context) &&
                !isLocked(context)
    }
}
