package com.jarvis.allinone

import android.content.Context
import android.media.AudioManager

object JarvisAudioDeviceManager {
    fun currentMode(context: Context): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return "Audio service unavailable"

        return when {
            audio.isBluetoothA2dpOn -> "Bluetooth audio"
            audio.isWiredHeadsetOn -> "Wired headset audio"
            else -> "Phone audio"
        }
    }

    fun isMusicActive(context: Context): Boolean {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return false
        return audio.isMusicActive
    }

    fun status(context: Context): String =
        "${currentMode(context)} | musicActive=${isMusicActive(context)}"
}
