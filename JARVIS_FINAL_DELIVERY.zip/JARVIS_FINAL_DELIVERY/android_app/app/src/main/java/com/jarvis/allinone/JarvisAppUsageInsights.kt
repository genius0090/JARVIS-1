package com.jarvis.allinone

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.util.Calendar

object JarvisAppUsageInsights {

    data class AppUsage(
        val packageName: String,
        val foregroundMs: Long,
        val lastUsed: Long
    )

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager

        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )

        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun getUsage(context: Context): List<AppUsage> {
        if (!hasUsageAccess(context)) return emptyList()

        val manager =
            context.getSystemService(Context.USAGE_STATS_SERVICE)
                    as UsageStatsManager

        val calendar = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -1)
        }

        return manager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            calendar.timeInMillis,
            System.currentTimeMillis()
        )
            .filter { it.totalTimeInForeground > 0 }
            .map {
                AppUsage(
                    packageName = it.packageName,
                    foregroundMs = it.totalTimeInForeground,
                    lastUsed = it.lastTimeUsed
                )
            }
            .sortedByDescending { it.foregroundMs }
    }

    fun summary(context: Context): String {
        if (!hasUsageAccess(context)) {
            return "JARVIS APP USAGE\n\nUsage Access permission required."
        }

        val apps = getUsage(context)

        return buildString {
            append("JARVIS APP USAGE INSIGHTS\n\n")
            append("Apps tracked: ${apps.size}\n\n")

            apps.take(15).forEachIndexed { index, app ->
                append("${index + 1}. ")
                append(app.packageName)
                append(" — ")
                append(formatTime(app.foregroundMs))
                append("\n")
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val minutes = ms / 60_000L
        val hours = minutes / 60L
        val remaining = minutes % 60L

        return if (hours > 0) {
            "${hours}h ${remaining}m"
        } else {
            "${minutes}m"
        }
    }
}
