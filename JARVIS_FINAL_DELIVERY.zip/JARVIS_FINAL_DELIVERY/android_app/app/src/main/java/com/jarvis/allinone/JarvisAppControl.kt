package com.jarvis.allinone

import android.content.Context
import android.content.Intent

object JarvisAppControl {

    fun launchPackage(context: Context, packageName: String): Boolean {
        val intent = context.packageManager
            .getLaunchIntentForPackage(packageName)
            ?: return false

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun openAppInfo(context: Context, packageName: String) {
        val intent = Intent(
            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            android.net.Uri.parse("package:$packageName")
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
