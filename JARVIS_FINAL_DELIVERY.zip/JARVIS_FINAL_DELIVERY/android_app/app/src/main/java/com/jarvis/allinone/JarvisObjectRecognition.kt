package com.jarvis.allinone

object JarvisObjectRecognition {
    data class ObjectResult(
        val name:String,
        val confidence:Float
    )

    private val results=mutableListOf<ObjectResult>()

    fun recognize(name:String,confidence:Float)=
        ObjectResult(name,confidence.coerceIn(0f,1f)).also{results+=it}

    fun latest(): List<ObjectResult> = results.toList()
    fun clear(){results.clear()}
}
