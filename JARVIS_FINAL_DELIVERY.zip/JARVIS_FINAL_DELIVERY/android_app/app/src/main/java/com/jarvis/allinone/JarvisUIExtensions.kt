package com.jarvis.allinone

import android.content.Context

object JarvisUIExtensions {
    fun dashboard(context: Context) = JarvisDashboardUI.dashboard(context)
    fun permissions(context: Context) = JarvisUiState("permissions", "Permission Center", "READY", "Runtime and sensitive-action permissions", true)
    fun approval(context: Context) = JarvisUiState("approval", "Action Approval", "REQUIRES_CONFIRMATION", "Sensitive action approval is handled by the security layer", true)
    fun listening(context: Context) = JarvisUiState("listening", "Listening", "READY", "Voice input and wake pipeline", true)
    fun voice(context: Context) = JarvisUiState("voice", "Voice Conversation", "READY", "TTS/STT and voice profile controls", true)
    fun deviceHealth(context: Context) = JarvisDashboardUI.deviceStatus(context)
    fun resources(context: Context) = JarvisDashboardUI.resourceStatus(context)
    fun models(context: Context) = JarvisUiState("models", "Model Manager", "READY", "Local/private model selection and health", true)
}
