package com.jarvis.allinone

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.URLUtil

object JarvisDownloadManager {

    fun download(context: Context, url: String, title: String? = null): Long {
        val cleanUrl = url.trim()
        require(cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://"))

        val fileName = title?.takeIf { it.isNotBlank() }
            ?: URLUtil.guessFileName(cleanUrl, null, null)

        val request = DownloadManager.Request(Uri.parse(cleanUrl)).apply {
            setTitle(fileName)
            setDescription("JARVIS Download")
            setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                fileName
            )
            setAllowedOverMetered(true)
            setAllowedOverRoaming(true)
        }

        val manager =
            context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        return manager.enqueue(request)
    }

    fun handleCommand(context: Context, command: String): Boolean {
        val text = command.trim()
        val lower = text.lowercase()

        val url = when {
            lower.startsWith("download ") ->
                text.substringAfter("download ").trim()

            lower.startsWith("download file ") ->
                text.substringAfter("download file ").trim()

            else -> return false
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            return false
        }

        download(context, url)
        return true
    }
}
