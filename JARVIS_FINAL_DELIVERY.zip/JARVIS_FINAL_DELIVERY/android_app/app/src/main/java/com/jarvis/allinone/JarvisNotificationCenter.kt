package com.jarvis.allinone

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object JarvisNotificationCenter {
    const val CHANNEL_ID = "jarvis_actions"

    fun setup(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Actions",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            context.getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }
}
