package com.jarvis.allinone

import android.os.Environment
import java.io.File
import java.security.MessageDigest

object JarvisDuplicateFinder {

    data class DuplicateGroup(
        val hash: String,
        val files: List<File>
    )

    fun scan(): List<DuplicateGroup> {
        val root = Environment.getExternalStorageDirectory()
        val bySize = mutableMapOf<Long, MutableList<File>>()

        fun collect(file: File) {
            if (!file.exists()) return

            if (file.isFile && file.length() > 0) {
                bySize.getOrPut(file.length()) { mutableListOf() }.add(file)
                return
            }

            if (file.isDirectory) {
                file.listFiles()?.forEach { collect(it) }
            }
        }

        collect(root)

        return bySize.values
            .filter { it.size > 1 }
            .flatMap { files ->
                files.groupBy { sha256(it) }
                    .filter { it.value.size > 1 }
                    .map { (hash, duplicates) ->
                        DuplicateGroup(hash, duplicates)
                    }
            }
    }

    fun summary(): String {
        val groups = scan()
        val count = groups.sumOf { it.files.size }

        return buildString {
            append("JARVIS DUPLICATE FILE REPORT\n\n")
            append("Duplicate groups: ${groups.size}\n")
            append("Duplicate files: $count\n\n")
            append("No files were deleted or moved.")
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")

        file.inputStream().use { input ->
            val buffer = ByteArray(8192)

            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }

        return digest.digest().joinToString("") {
            "%02x".format(it)
        }
    }
}
