package com.jarvis.allinone

import android.content.Context

object JarvisMediaEditorUI {
    fun imageEditor(context: Context) = state("image_editor", "Image Editor", "READY", "Image workflow entry point", true)
    fun videoEditor(context: Context) = state("video_editor", "Video Editor", "READY", "Timeline-based video workflow entry point", true)
    fun timeline(context: Context) = state("timeline", "Video Timeline", "READY", "Timeline/project state is available to the media engine", true)
    fun export(context: Context) = state("media_export", "Media Export", "READY", "Export through the media pipeline", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
