package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisContextIntelligence {

    private const val PREFS = "jarvis_context_intelligence"
    private const val ACTIONS = "actions"
    private const val PROMISES = "promises"
    private const val CONTEXTS = "contexts"
    private const val SHIELD = "attention_shield"
    private const val FACTS = "facts"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun add(context: Context, key: String, value: String) {
        val old = prefs(context).getString(key, "[]") ?: "[]"
        val array = JSONArray(old)
        array.put(value)
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun convertConversationToAction(context: Context, conversation: String): String {
        val action = JSONObject()
            .put("conversation", conversation)
            .put("createdAt", System.currentTimeMillis())
            .put("status", "pending")
            .toString()
        add(context, ACTIONS, action)
        return action
    }

    fun addPromise(context: Context, promise: String, deadline: Long = 0L): String {
        val item = JSONObject()
            .put("promise", promise)
            .put("deadline", deadline)
            .put("createdAt", System.currentTimeMillis())
            .put("status", "active")
            .toString()
        add(context, PROMISES, item)
        return item
    }

    fun switchContext(context: Context, name: String): String {
        val item = JSONObject()
            .put("name", name)
            .put("timestamp", System.currentTimeMillis())
            .toString()
        add(context, CONTEXTS, item)
        return item
    }

    fun setAttentionShield(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(SHIELD, enabled).apply()
    }

    fun isAttentionShieldEnabled(context: Context): Boolean =
        prefs(context).getBoolean(SHIELD, false)

    fun addFact(context: Context, fact: String): String {
        val item = JSONObject()
            .put("fact", fact)
            .put("timestamp", System.currentTimeMillis())
            .toString()
        add(context, FACTS, item)
        return item
    }

    fun findContradictions(context: Context): List<String> {
        val result = mutableListOf<String>()
        val raw = prefs(context).getString(FACTS, "[]") ?: "[]"
        val array = JSONArray(raw)

        for (i in 0 until array.length()) {
            val current = array.optJSONObject(i)?.optString("fact") ?: continue

            for (j in i + 1 until array.length()) {
                val other = array.optJSONObject(j)?.optString("fact") ?: continue

                if (current.equals(other, ignoreCase = true)) continue

                val currentNeg = current.lowercase().startsWith("not ")
                val otherNeg = other.lowercase().startsWith("not ")

                if (currentNeg != otherNeg &&
                    current.removePrefix("Not ").removePrefix("not ")
                        .equals(
                            other.removePrefix("Not ").removePrefix("not "),
                            ignoreCase = true
                        )
                ) {
                    result.add("$current <> $other")
                }
            }
        }

        return result
    }

    fun freshnessHint(timestamp: Long): String {
        if (timestamp <= 0L) return "unknown"

        val age = System.currentTimeMillis() - timestamp
        return when {
            age < 60_000L -> "fresh"
            age < 3_600_000L -> "recent"
            age < 86_400_000L -> "today"
            age < 7L * 86_400_000L -> "older"
            else -> "stale"
        }
    }

    fun status(context: Context): String {
        return JSONObject()
            .put("attentionShield", isAttentionShieldEnabled(context))
            .put("actions", JSONArray(prefs(context).getString(ACTIONS, "[]")))
            .put("promises", JSONArray(prefs(context).getString(PROMISES, "[]")))
            .put("contexts", JSONArray(prefs(context).getString(CONTEXTS, "[]")))
            .put("facts", JSONArray(prefs(context).getString(FACTS, "[]")))
            .put("contradictions", JSONArray(findContradictions(context)))
            .toString()
    }
}
