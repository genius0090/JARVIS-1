package com.jarvis.allinone

object JarvisCodebaseUnderstanding {
    data class Finding(
        val file: String,
        val category: String,
        val detail: String
    )

    private val findings = mutableListOf<Finding>()

    fun addFinding(file: String, category: String, detail: String) {
        findings += Finding(file, category, detail)
    }

    fun search(query: String): List<Finding> {
        val q = query.lowercase()
        return findings.filter {
            it.file.lowercase().contains(q) ||
            it.category.lowercase().contains(q) ||
            it.detail.lowercase().contains(q)
        }
    }

    fun all(): List<Finding> = findings.toList()
    fun clear() = findings.clear()
}
