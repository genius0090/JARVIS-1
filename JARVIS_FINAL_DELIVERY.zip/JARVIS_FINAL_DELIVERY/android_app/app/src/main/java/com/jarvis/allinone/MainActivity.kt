package com.jarvis.allinone

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

/**
 * JARVIS Command Center UI.
 * This screen is intentionally implemented as a real multi-workspace UI rather
 * than capability-name dialogs. Existing JARVIS services remain the execution layer.
 */
class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(4, 8, 15)
    private val panel = Color.rgb(10, 18, 29)
    private val panel2 = Color.rgb(14, 25, 39)
    private val gold = Color.rgb(255, 190, 55)
    private val cyan = Color.rgb(75, 220, 255)
    private val text = Color.rgb(235, 242, 248)
    private val muted = Color.rgb(145, 164, 181)
    private val danger = Color.rgb(235, 75, 85)

    private lateinit var root: FrameLayout
    private lateinit var workspace: FrameLayout
    private lateinit var orb: JarvisReactiveOrbView
    private lateinit var stateText: TextView
    private lateinit var input: EditText
    private lateinit var title: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initializeServices()
        buildShell()
        showHome()
        requestAudioPermissionIfNeeded()
        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleWakeIntent(intent)
    }

    private fun handleWakeIntent(intent: Intent?) {
        val command = intent?.getStringExtra(JarvisWakeService.EXTRA_COMMAND)?.trim().orEmpty()
        if (command.isNotBlank()) {
            if (!::input.isInitialized) showHome()
            input.setText(command)
            executeJarvisCommand(command)
        }
    }

    private fun initializeServices() {
        try { JarvisAuditTrail.initialize(this) } catch (_: Throwable) {}
        try { JarvisPermanentCore.initialize(this) } catch (_: Throwable) {}
        try { JarvisPermanentOwnerAccount.initialize(this) } catch (_: Throwable) {}
        try { JarvisPermanentOwnerAccount.configurePersonalOwnerProfile(this) } catch (_: Throwable) {}
        try { JarvisCentralMemory.initialize(this) } catch (_: Throwable) {}
        try { JarvisBackupContinuity.initialize(this); JarvisBackupContinuity.maybeAutomaticBackup(this) } catch (_: Throwable) {}
        try { if (JarvisRemoteCoreClient.baseUrl(this).isNotBlank()) Thread { JarvisCoreSync.sync(this) }.start() } catch (_: Throwable) {}
        try { JarvisOwnerAuthentication.initialize(this) } catch (_: Throwable) {}
        try { JarvisOwnerIdentityMethods.initialize(this) } catch (_: Throwable) {}
        try { JarvisNotificationCenter.setup(this) } catch (_: Throwable) {}
        try { JarvisVoiceProfile.initialize(this) } catch (_: Throwable) {}
        startJarvisOrbService()
    }

    private fun startJarvisOrbService() {
        try {
            if (Settings.canDrawOverlays(this)) {
                val intent = Intent(this, JarvisOrbService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            }
        } catch (_: Throwable) {}
    }

    private fun requestAudioPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 42)
        }
    }

    private fun buildShell() {
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 22)
        }
        scroll.addView(outer)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        title = TextView(this).apply { text = "JARVIS"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD; setTextColor(gold) }
        status = TextView(this).apply { text = "● ONLINE"; textSize = 12f; setTextColor(Color.rgb(105, 235, 170)); gravity = Gravity.CENTER_VERTICAL }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(status)
        outer.addView(header)

        val subtitle = TextView(this).apply {
            text = "UNIFIED PERSONAL AI  •  COMMAND CENTER"
            textSize = 10f
            setTextColor(muted)
            letterSpacing = .11f
            setPadding(0, 2, 0, 12)
        }
        outer.addView(subtitle)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("HOME", "CHAT", "TOOLS", "MEMORY", "HISTORY", "SETTINGS").forEachIndexed { i, label ->
            val b = navButton(label)
            b.setOnClickListener { when (i) {
                0 -> showHome(); 1 -> showChat(); 2 -> showTools(); 3 -> showMemory(); 4 -> showHistory(); 5 -> showSettings()
            }}
            nav.addView(b, LinearLayout.LayoutParams(0, 44, 1f).apply { leftMargin = 3; rightMargin = 3 })
        }
        outer.addView(nav)

        workspace = FrameLayout(this)
        outer.addView(workspace, LinearLayout.LayoutParams(-1, -1).apply { topMargin = 12 })
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun navButton(label: String): TextView = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(text)
        background = rounded(panel2, Color.rgb(52, 82, 105), 16f)
        isAllCaps = false
    }

    private fun rounded(fill: Int, stroke: Int, radius: Float = 18f): GradientDrawable = GradientDrawable().apply {
        setColor(fill); cornerRadius = radius; setStroke(1, stroke)
    }

    private fun card(titleText: String, subtitleText: String = "", accent: Int = cyan): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 15, 16, 15); background = rounded(panel, Color.rgb(38, 65, 85), 22f) }
        val t = TextView(this).apply { text = titleText; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(accent) }
        box.addView(t)
        if (subtitleText.isNotBlank()) box.addView(TextView(this).apply { text = subtitleText; textSize = 11f; setTextColor(muted); setPadding(0, 5, 0, 0) })
        return box
    }

    private fun clearWorkspace() { workspace.removeAllViews() }

    private fun showHome() {
        clearWorkspace()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hero = card("JARVIS AI CORE", "Unified command center • context-aware routing • local-first", gold)
        orb = JarvisReactiveOrbView(this).apply {
            state = JarvisReactiveOrbView.State.IDLE
            audioLevel = 0f
            setOnClickListener { showFloatingHudPreview() }
        }
        hero.addView(orb, LinearLayout.LayoutParams(-1, 330).apply { topMargin = 10 })
        stateText = TextView(this).apply { text = "READY • SAY OR TYPE A COMMAND"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(muted); setPadding(0, 10, 0, 8) }
        hero.addView(stateText)
        content.addView(hero)

        input = EditText(this).apply {
            hint = "Ask JARVIS anything…"
            setHintTextColor(Color.rgb(95, 120, 140)); setTextColor(text); textSize = 16f; setSingleLine(true)
            setPadding(18, 14, 18, 14); background = rounded(panel2, Color.rgb(60, 95, 120), 20f)
        }
        content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val voice = primaryButton("MIC / VOICE") { startVoice() }
        val send = primaryButton("SEND") { sendCommand() }
        actions.addView(voice, LinearLayout.LayoutParams(0, 52, 1f).apply { rightMargin = 5 })
        actions.addView(send, LinearLayout.LayoutParams(0, 52, 1f).apply { leftMargin = 5 })
        content.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row(grid, quickCard("WEB", "Search / browser") { webPrompt() }, quickCard("FILES", "Storage / downloads") { showTools() })
        row(grid, quickCard("MEMORY", "Recall / remember") { showMemory() }, quickCard("TERMINAL", "Safe command center") { terminalPrompt() })
        row(grid, quickCard("VISION", "On-demand vision") { visionPanel() }, quickCard("SECURITY", "Owner / permissions") { securityPanel() })
        content.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })

        val mission = primaryButton("MISSION / SERIOUS MODE") {
            orb.state = if (orb.state == JarvisReactiveOrbView.State.MISSION) JarvisReactiveOrbView.State.IDLE else JarvisReactiveOrbView.State.MISSION
            stateText.text = if (orb.state == JarvisReactiveOrbView.State.MISSION) "MISSION MODE • ACTIVE" else "READY"
            title.setTextColor(if (orb.state == JarvisReactiveOrbView.State.MISSION) Color.rgb(255, 85, 70) else gold)
        }
        content.addView(mission, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 12 })
        workspace.addView(content)
    }

    private fun row(parent: LinearLayout, a: View, b: View) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(a, LinearLayout.LayoutParams(0, 105, 1f).apply { rightMargin = 5; bottomMargin = 10 })
        r.addView(b, LinearLayout.LayoutParams(0, 105, 1f).apply { leftMargin = 5; bottomMargin = 10 })
        parent.addView(r)
    }

    private fun quickCard(t: String, s: String, click: () -> Unit): View = card(t, s).apply { setOnClickListener { click() } }

    private fun primaryButton(label: String, click: () -> Unit): TextView = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; setTextColor(text); background = rounded(panel2, Color.rgb(82, 130, 160), 18f); setOnClickListener { click() }
    }

    private fun showChat() {
        clearWorkspace()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(card("CONVERSATION", "Real session context • Hindi / English / Hinglish"))
        val history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        JarvisCentralMemory.conversations(this).takeLast(20).forEach { c ->
            val bubble = TextView(this).apply {
                text = "${c.role.uppercase()}\n${c.content}"; textSize = 13f; setTextColor(text); setPadding(14, 12, 14, 12); background = rounded(if (c.role.equals("user", true)) panel2 else panel, Color.rgb(45, 75, 95), 18f)
            }
            history.addView(bubble, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
        val scroll = ScrollView(this); scroll.addView(history); content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 10 })
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val e = EditText(this).apply { hint = "Message JARVIS…"; setHintTextColor(muted); setTextColor(text); setSingleLine(true); setPadding(14, 10, 14, 10); background = rounded(panel2, Color.rgb(55, 90, 110), 18f) }
        bar.addView(e, LinearLayout.LayoutParams(0, 52, 1f).apply { rightMargin = 6 })
        bar.addView(primaryButton("SEND") { if (e.text.isNotBlank()) { input = e; executeJarvisCommand(e.text.toString().trim()); showChat() } }, LinearLayout.LayoutParams(90, 52))
        content.addView(bar, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        workspace.addView(content)
    }

    private fun showTools() {
        clearWorkspace()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(card("TOOLS & SKILLS", "Actual entry points into the existing JARVIS capability layer", gold))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row(grid, quickCard("WEB SEARCH", "Browser + search") { webPrompt() }, quickCard("DOWNLOADS", "Android DownloadManager") { downloadPrompt() })
        row(grid, quickCard("STORAGE", "Storage / cleanup analysis") { showInfo("Storage", JarvisStorageCleanup.summary(this)) }, quickCard("DUPLICATES", "SHA-256 duplicate scan") { showInfo("Duplicate Finder", "Use JARVIS command: find duplicate files") })
        row(grid, quickCard("PC BRIDGE", "Phone ↔ PC control") { showInfo("PC Bridge", JarvisPhonePcBridge.status()) }, quickCard("TERMINAL", "Command center") { terminalPrompt() })
        row(grid, quickCard("VISION", "On-demand webcam vision") { visionPanel() }, quickCard("SECURITY", "Owner / approval / STOP") { securityPanel() })
        row(grid, quickCard("RECOVERY", "Cancellation / recovery") { showInfo("Recovery", JarvisTaskRecovery.status(this)) }, quickCard("SANDBOX", "Simulation / state") { showInfo("Digital Sandbox", "Simulation and snapshot controls are available through JARVIS task routing.") })
        content.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        workspace.addView(content)
    }

    private fun showMemory() {
        clearWorkspace()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(card("JARVIS MEMORY", "Persistent owner/context memory — searchable and readable", gold))
        val search = EditText(this).apply { hint = "Search memory…"; setHintTextColor(muted); setTextColor(text); setSingleLine(true); background = rounded(panel2, Color.rgb(55, 90, 110), 18f); setPadding(14, 10, 14, 10) }
        content.addView(search, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun render(q: String = "") {
            list.removeAllViews()
            val memories = if (q.isBlank()) JarvisCentralMemory.allMemories(this) else JarvisCentralMemory.recall(this, q)
            if (memories.isEmpty()) list.addView(TextView(this).apply { text = "No matching memories."; setTextColor(muted); setPadding(8, 18, 8, 18) })
            memories.takeLast(60).reversed().forEach { m ->
                list.addView(TextView(this).apply { text = "${m.key}\n${m.value}\n${DateFormat.getDateTimeInstance().format(Date(m.timestamp))}"; textSize = 12f; setTextColor(text); setPadding(14, 12, 14, 12); background = rounded(panel, Color.rgb(42, 68, 88), 16f) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
            }
        }
        search.setOnEditorActionListener { _, _, _ -> render(search.text.toString().trim()); false }
        val add = primaryButton("REMEMBER THIS") { rememberPrompt { render() } }
        content.addView(add, LinearLayout.LayoutParams(-1, 48).apply { topMargin = 8 })
        val scroll = ScrollView(this); scroll.addView(list); content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 10 })
        render()
        workspace.addView(content)
    }

    private fun showHistory() {
        clearWorkspace()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(card("CONVERSATION HISTORY", "Persistent sessions and task context", gold))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        JarvisCentralMemory.conversations(this).reversed().take(100).forEach { c ->
            list.addView(TextView(this).apply { text = "${c.role.uppercase()}  •  ${DateFormat.getDateTimeInstance().format(Date(c.timestamp))}\n${c.content}"; textSize = 12f; setTextColor(text); setPadding(14, 12, 14, 12); background = rounded(panel, Color.rgb(42, 68, 88), 16f) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
        }
        if (list.childCount == 0) list.addView(TextView(this).apply { text = "No conversations recorded yet."; setTextColor(muted); setPadding(8, 18, 8, 18) })
        val scroll = ScrollView(this); scroll.addView(list); content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 10 })
        workspace.addView(content)
    }

    private fun showSettings() {
        clearWorkspace()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(card("JARVIS SETTINGS", "Real controls instead of a capability-name dialog", gold))
        val voice = card("VOICE", JarvisVoiceProfile.summary())
        voice.setOnClickListener { voiceSettings() }
        content.addView(voice, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        val appearance = card("APPEARANCE", "Theme, presentation state and reactive visual behavior")
        appearance.setOnClickListener { appearanceSettings() }
        content.addView(appearance, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        val security = card("SECURITY & PERMISSIONS", JarvisEmergencyStop.status(this))
        security.setOnClickListener { securityPanel() }
        content.addView(security, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        val device = card("DEVICE & CONNECTIONS", "Overlay • microphone • PC bridge • local AI")
        device.setOnClickListener { deviceSettings() }
        content.addView(device, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        val recovery = card("BACKUP / RECOVERY", "Safe recovery, cancellation and state continuity")
        recovery.setOnClickListener { showInfo("Recovery", JarvisTaskRecovery.status(this) + "\n\nRollback snapshots: " + JarvisRollback.all().size) }
        content.addView(recovery, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        workspace.addView(content)
    }

    private fun voiceSettings() {
        val labels = JarvisVoiceProfile.Voice.values().map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Voice Profile").setSingleChoiceItems(labels, JarvisVoiceProfile.getVoice().ordinal) { d, which -> JarvisVoiceProfile.setVoice(JarvisVoiceProfile.Voice.values()[which]); d.dismiss(); showSettings() }.setNegativeButton("Close", null).show()
    }

    private fun appearanceSettings() {
        AlertDialog.Builder(this).setTitle("Appearance").setItems(arrayOf("Normal JARVIS", "Mission / Serious Mode", "Light Mode")) { _, which ->
            when (which) {
                0 -> { title.setTextColor(gold); if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.IDLE }
                1 -> { title.setTextColor(Color.rgb(255, 80, 65)); if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.MISSION }
                2 -> showInfo("Light Mode", "Live theme controller is available through JarvisLiveTheme; the current command center remains dark-first for HUD readability.")
            }
        }.show()
    }

    private fun deviceSettings() {
        val overlay = Settings.canDrawOverlays(this)
        showInfo("Device & Connections", "Overlay permission: ${if (overlay) "GRANTED" else "NOT GRANTED"}\nMicrophone: ${if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "GRANTED" else "NOT GRANTED"}\n\nPC: ${JarvisPhonePcBridge.status()}")
    }

    private fun securityPanel() {
        val stopped = JarvisEmergencyStop.isStopped(this)
        val b = AlertDialog.Builder(this).setTitle("Security & Emergency Controls")
            .setMessage("Emergency STOP: ${if (stopped) "ACTIVE" else "READY"}\n\n${JarvisTaskRecovery.status(this)}")
        if (stopped) b.setPositiveButton("RESET STOP") { _, _ -> JarvisEmergencyStop.reset(this); showSettings() }
        else b.setPositiveButton("EMERGENCY STOP") { _, _ -> JarvisEmergencyStop.trigger(this); if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.ALERT; showSettings() }
        b.setNegativeButton("Close", null).show()
    }

    private fun showFloatingHudPreview() {
        val hud = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); background = rounded(Color.rgb(8, 18, 29), Color.rgb(70, 180, 220), 24f) }
        hud.addView(TextView(this).apply { text = "JARVIS FLOATING HUD"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(gold) })
        hud.addView(TextView(this).apply { text = "VOICE     WEB     MEMORY     FILES     VISION     PC     MORE"; textSize = 11f; setTextColor(cyan); setPadding(0, 8, 0, 12) })
        hud.addView(TextView(this).apply { text = "Tap a capability to continue. The floating Orb service remains the external/background identity."; textSize = 12f; setTextColor(text) })
        AlertDialog.Builder(this).setView(hud).setPositiveButton("OPEN COMMAND CENTER") { _, _ -> showTools() }.setNegativeButton("CLOSE", null).show()
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudioPermissionIfNeeded(); return }
        if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.LISTENING
        stateText.text = "LISTENING…"
        JarvisSpeechInput.start(this,
            onState = { s -> runOnUiThread { stateText.text = s.name; if (::orb.isInitialized) orb.state = when (s) { JarvisSpeechInput.State.LISTENING -> JarvisReactiveOrbView.State.LISTENING; JarvisSpeechInput.State.THINKING -> JarvisReactiveOrbView.State.THINKING; JarvisSpeechInput.State.ERROR -> JarvisReactiveOrbView.State.ALERT; else -> JarvisReactiveOrbView.State.IDLE } } },
            onResult = { c -> runOnUiThread { input.setText(c); executeJarvisCommand(c) } },
            onError = { m -> runOnUiThread { stateText.text = "VOICE ERROR"; Toast.makeText(this, m, Toast.LENGTH_SHORT).show() } },
            onRms = { if (::orb.isInitialized) orb.audioLevel = it }
        )
    }

    private fun sendCommand() { val c = input.text.toString().trim(); if (c.isNotBlank()) executeJarvisCommand(c) }

    private fun executeJarvisCommand(command: String) {
        if (command.isBlank()) return
        JarvisCentralMemory.addConversation(this, "user", command)
        if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.THINKING
        if (::stateText.isInitialized) stateText.text = "THINKING • ROUTING"
        val decision = JarvisUnifiedDecisionEngine.decide(this, command, approved = false)
        if (decision.decision != JarvisUnifiedDecisionEngine.Decision.EXECUTE) {
            if (decision.decision == JarvisUnifiedDecisionEngine.Decision.CONFIRM) {
                AlertDialog.Builder(this).setTitle("JARVIS Confirmation Required").setMessage("This action requires owner approval before execution.").setNegativeButton("Cancel") { _, _ -> setIdle() }.setPositiveButton("Allow") { _, _ -> executeApproved(command) }.show()
            } else { showInfo("Action Blocked", "JARVIS security policy blocked this action."); setIdle() }
            return
        }
        routeCommand(command)
    }

    private fun executeApproved(command: String) {
        val route = JarvisUnifiedActionRouter.route(command).route
        val protected = route in setOf(
            JarvisUnifiedActionRouter.Route.PC,
            JarvisUnifiedActionRouter.Route.SYSTEM,
            JarvisUnifiedActionRouter.Route.SECURITY,
            JarvisUnifiedActionRouter.Route.REPAIR,
            JarvisUnifiedActionRouter.Route.TERMINAL,
            JarvisUnifiedActionRouter.Route.DEVICE,
            JarvisUnifiedActionRouter.Route.RECOVERY,
            JarvisUnifiedActionRouter.Route.OSINT,
            JarvisUnifiedActionRouter.Route.AIR_VISUAL
        )
        if (protected) {
            JarvisAndroidOwnerAuthentication.authenticate(
                this,
                title = "JARVIS Owner Verification",
                subtitle = "Verify before executing this protected action"
            ) { verified ->
                runOnUiThread {
                    if (!verified) {
                        showInfo("Authorization Failed", "Owner verification failed or was cancelled.")
                        setIdle()
                        return@runOnUiThread
                    }
                    val d = JarvisUnifiedDecisionEngine.decide(this, command, approved = true)
                    if (d.decision == JarvisUnifiedDecisionEngine.Decision.EXECUTE) routeCommand(command)
                    else { showInfo("Action Blocked", "The action remains blocked by security policy."); setIdle() }
                }
            }
        } else {
            val d = JarvisUnifiedDecisionEngine.decide(this, command, approved = true)
            if (d.decision == JarvisUnifiedDecisionEngine.Decision.EXECUTE) routeCommand(command)
            else { showInfo("Action Blocked", "The action remains blocked by security policy."); setIdle() }
        }
    }

    private fun routeCommand(command: String) {
        val route = JarvisUnifiedActionRouter.route(command).route
        val handled = when (route) {
            JarvisUnifiedActionRouter.Route.BROWSER -> JarvisBrowserManager.handleCommand(this, command) || JarvisIntelligenceEngine.handleCommand(this, command)
            JarvisUnifiedActionRouter.Route.STORAGE, JarvisUnifiedActionRouter.Route.FILES -> JarvisDownloadManager.handleCommand(this, command) || JarvisIntelligenceEngine.handleCommand(this, command)
            JarvisUnifiedActionRouter.Route.PC -> JarvisPhonePcBridge.handleCommand(this, command)
            JarvisUnifiedActionRouter.Route.DEVICE -> handleDeviceCommand(command)
            JarvisUnifiedActionRouter.Route.MEDIA -> handleMediaCommand(command)
            JarvisUnifiedActionRouter.Route.CREATION -> handleCreationCommand(command)
            JarvisUnifiedActionRouter.Route.VISION -> handleVisionCommand(command)
            JarvisUnifiedActionRouter.Route.MEMORY -> handleMemoryCommand(command)
            JarvisUnifiedActionRouter.Route.PLANNING -> handlePlanningCommand(command)
            JarvisUnifiedActionRouter.Route.TERMINAL -> command.startsWith("terminal ", true) && JarvisTerminalCommandCenter.execute(this, command.substringAfter("terminal ").trim()).success
            JarvisUnifiedActionRouter.Route.SECURITY -> handleSecurityCommand(command)
            JarvisUnifiedActionRouter.Route.RECOVERY -> handleRecoveryCommand(command)
            JarvisUnifiedActionRouter.Route.SANDBOX -> handleSandboxCommand(command)
            JarvisUnifiedActionRouter.Route.PROACTIVE -> handleProactiveCommand(command)
            JarvisUnifiedActionRouter.Route.DATA -> handleDataCommand(command)
            else -> JarvisIntelligenceEngine.handleCommand(this, command)
        }
        if (handled) {
            JarvisCentralMemory.addConversation(this, "assistant", "Command executed: $command")
            if (::stateText.isInitialized) stateText.text = "COMMAND EXECUTED"
            if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.SPEAKING
            JarvisVoiceProfile.speak(this, JarvisEventVoice.phrase(JarvisEventVoice.Event.DONE))
            if (::orb.isInitialized) orb.postDelayed({ setIdle() }, 900)
        } else {
            Thread {
                val result = JarvisLocalAiClient.ask(this, command)
                runOnUiThread {
                    if (result.success) {
                        JarvisCentralMemory.addConversation(this, "assistant", result.text)
                        if (::stateText.isInitialized) stateText.text = result.text
                        if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.SPEAKING
                        JarvisVoiceProfile.speak(this, result.text)
                        if (::orb.isInitialized) orb.postDelayed({ setIdle() }, 1100)
                    } else {
                        if (::stateText.isInitialized) stateText.text = "LOCAL AI UNAVAILABLE"
                        if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.ALERT
                    }
                }
            }.start()
        }
    }

    private fun handleDeviceCommand(command: String): Boolean {
        val lower = command.lowercase()
        return try {
            when {
                lower.startsWith("call ") || lower.startsWith("dial ") -> {
                    val number = command.substringAfter(' ').trim()
                    JarvisAndroidActions.openDialer(this, number).success
                }
                lower.startsWith("sms ") || lower.contains("text message") -> {
                    val parts = command.substringAfter(' ').trim().split(" ", limit = 2)
                    if (parts.isEmpty()) false else JarvisAndroidActions.openSmsComposer(this, parts[0], parts.getOrElse(1) { "" }).success
                }
                lower.contains("calendar") -> JarvisAndroidActions.openCalendarEvent(this, command).success
                lower.contains("wifi") || lower.contains("wi-fi") -> JarvisAndroidActions.openWifiSettings(this).success
                lower.contains("bluetooth") -> JarvisAndroidActions.openBluetoothSettings(this).success
                lower.contains("location settings") -> JarvisAndroidActions.openLocationSettings(this).success
                lower.contains("sound settings") -> JarvisAndroidActions.openSoundSettings(this).success
                lower.contains("display settings") -> JarvisAndroidActions.openDisplaySettings(this).success
                else -> false
            }
        } catch (_: Throwable) { false }
    }

    private fun handleMediaCommand(command: String): Boolean {
        val lower = command.lowercase()
        if (lower.contains("movie") && (lower.contains("explain") || lower.contains("explainer"))) {
            val title = command.substringAfterLast("movie", command).trim().ifBlank { "Untitled Movie" }
            val plan = JarvisMovieExplainer.createPlan(this, title)
            showInfo("Movie Explainer Plan", plan.toString(2))
            return true
        }
        if (lower.contains("media status") || lower.contains("video status")) {
            showInfo("Media Engine", JarvisMediaEngine.status(this).toString(2))
            return true
        }
        return if (lower.contains("youtube")) JarvisYouTubeControl.handleCommand(this, command)
        else JarvisIntelligenceEngine.handleCommand(this, command)
    }

    private fun handleCreationCommand(command: String): Boolean {
        val lower = command.lowercase()
        return when {
            lower.contains("document") -> {
                val title = command.substringAfter("document", "JARVIS Document").trim().ifBlank { "JARVIS Document" }
                val result = JarvisProfessionalCreation.createDocument(this, title, "Created by JARVIS from the requested command.")
                showInfo("Document", result); true
            }
            lower.contains("spreadsheet") -> {
                val title = command.substringAfter("spreadsheet", "JARVIS Spreadsheet").trim().ifBlank { "JARVIS Spreadsheet" }
                val result = JarvisProfessionalCreation.createSpreadsheet(this, title, listOf("Item", "Value"), listOf(listOf("JARVIS", "Generated")))
                showInfo("Spreadsheet", result); true
            }
            lower.contains("presentation") -> {
                val title = command.substringAfter("presentation", "JARVIS Presentation").trim().ifBlank { "JARVIS Presentation" }
                val result = JarvisProfessionalCreation.createPresentation(this, title, listOf("JARVIS", "Generated presentation"))
                showInfo("Presentation", result); true
            }
            lower.contains("website") -> {
                val title = command.substringAfter("website", "JARVIS Website").trim().ifBlank { "JARVIS Website" }
                val result = JarvisProfessionalCreation.createWebsite(this, title, "Generated by JARVIS", emptyList())
                showInfo("Website Package", result); true
            }
            else -> false
        }
    }

    private fun handleVisionCommand(command: String): Boolean {
        val lower = command.lowercase()
        return when {
            lower.contains("vision off") || lower.contains("camera off") -> { JarvisWebcamVision.deactivate(); showInfo("Vision", "On-demand vision OFF."); true }
            lower.contains("vision") || lower.contains("camera") || lower.contains("webcam") -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), 43); showInfo("Vision", "Camera permission is required before activation.")
                } else {
                    JarvisWebcamVision.activate(); showInfo("Vision", "On-demand vision ACTIVE. Analysis requires a connected vision engine; no fake recognition is reported.")
                }
                true
            }
            else -> false
        }
    }

    private fun handleMemoryCommand(command: String): Boolean {
        val lower = command.lowercase()
        return when {
            lower.startsWith("remember ") -> {
                val body = command.substringAfter("remember ").trim()
                val parts = body.split("=", limit = 2)
                if (parts.size == 2) JarvisCentralMemory.remember(this, parts[0].trim(), parts[1].trim()) != null
                else { showInfo("Memory", "Use: remember key=value"); true }
            }
            lower.startsWith("recall ") -> {
                val q = command.substringAfter("recall ").trim()
                showInfo("Memory", JarvisCentralMemory.recall(this, q).joinToString("\n") { "${it.key}: ${it.value}" }.ifBlank { "No matching memory." }); true
            }
            else -> false
        }
    }

    private fun handlePlanningCommand(command: String): Boolean {
        val plan = JarvisIntelligenceEngine.createPlan(command)
        showInfo("JARVIS Plan", plan.joinToString("\n") { "${it.number}. ${it.action}" }.ifBlank { "No plan generated." })
        return plan.isNotEmpty()
    }

    private fun handleSecurityCommand(command: String): Boolean {
        showInfo("Security", JarvisSecurityIntegration.healthCheck(this).toString(2))
        return true
    }

    private fun handleRecoveryCommand(command: String): Boolean {
        showInfo("Recovery", JarvisTaskRecovery.status(this) + "\n\nRollback snapshots: " + JarvisRollback.all().size)
        return true
    }

    private fun handleSandboxCommand(command: String): Boolean {
        showInfo("Digital Sandbox", "Simulation boundary available. Execution is isolated only where the underlying task explicitly supports simulation; no fake execution result is reported.")
        return true
    }

    private fun handleProactiveCommand(command: String): Boolean {
        showInfo("Proactive", JarvisProactiveMonitor.recent(this).joinToString("\n") { "${it.source}: ${it.message}" }.ifBlank { "No proactive alerts." })
        return true
    }

    private fun handleDataCommand(command: String): Boolean {
        showInfo("Data Analysis", "Data-analysis adapter is available. Provide a supported file/table source for actual analysis.")
        return true
    }

    private fun setIdle() { if (::orb.isInitialized) orb.state = JarvisReactiveOrbView.State.IDLE; if (::stateText.isInitialized) stateText.text = "READY • SAY OR TYPE A COMMAND" }

    private fun webPrompt() { prompt("Web Search", "Search query") { JarvisBrowserManager.searchWeb(this, it); showInfo("Web", "Search request sent to the browser.") } }
    private fun downloadPrompt() { prompt("Download", "URL") { JarvisDownloadManager.download(this, it); showInfo("Download", "Download queued in Android DownloadManager.") } }
    private fun terminalPrompt() { prompt("JARVIS Terminal", "Safe command") { val r = JarvisTerminalCommandCenter.execute(this, it); showInfo("Terminal Result", r.output.ifBlank { r.error }) } }
    private fun rememberPrompt(done: () -> Unit) { prompt("Remember", "key=value") { val p = it.split("=", limit = 2); if (p.size == 2) JarvisCentralMemory.remember(this, p[0].trim(), p[1].trim()); done() } }
    private fun visionPanel() { if (JarvisWebcamVision.isActive()) JarvisWebcamVision.deactivate() else JarvisWebcamVision.activate(); showInfo("Vision", if (JarvisWebcamVision.isActive()) "On-demand vision mode ACTIVE. It will remain off until explicitly activated again." else "Vision mode OFF.") }
    private fun prompt(titleText: String, hint: String, action: (String) -> Unit) { val e = EditText(this).apply { setHint(hint); setHintTextColor(muted); setTextColor(text); setSingleLine(true) }; AlertDialog.Builder(this).setTitle(titleText).setView(e).setNegativeButton("Cancel", null).setPositiveButton("Run") { _, _ -> action(e.text.toString().trim()) }.show() }
    private fun showInfo(t: String, m: String) { AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK", null).show() }
}
