package com.jarvis.allinone

object JarvisMultiAgent {
    data class Agent(val id:String,val role:String)
    private val agents=mutableMapOf<String,Agent>()

    fun register(id:String,role:String){agents[id]=Agent(id,role)}
    fun agents()=agents.values.toList()

    fun delegate(task:String,agentId:String):String=
        if(agents.containsKey(agentId)) "Task delegated to $agentId: $task"
        else "Agent unavailable"
}
