package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Local-first OpenAI-compatible client for the existing Termux llama-server. */
object JarvisLocalAiClient {
    private const val ENDPOINT = "http://127.0.0.1:8080/v1/chat/completions"
    private const val CONNECT_TIMEOUT = 2500
    private const val READ_TIMEOUT = 15000
    private const val MAX_CONTEXT_ITEMS = 12
    private const val MAX_MEMORY_ITEMS = 12

    data class Result(val success: Boolean, val text: String = "", val error: String = "")

    fun ask(context: Context, prompt: String): Result {
        if (prompt.isBlank()) return Result(false, error = "Empty prompt")
        if (JarvisEmergencyStop.isStopped(context)) return Result(false, error = "Emergency STOP active")
        if (JarvisTaskRecovery.isCancellationRequested(context)) return Result(false, error = "Task cancellation requested")

        return try {
            JarvisCentralMemory.initialize(context)
            val memories = JarvisCentralMemory.allMemories(context).takeLast(MAX_MEMORY_ITEMS)
            val conversations = JarvisCentralMemory.conversations(context).takeLast(MAX_CONTEXT_ITEMS)
            val contextBlock = buildString {
                append("JARVIS CONTEXT (use only when relevant):\n")
                if (memories.isEmpty()) append("No long-term memory available.\n")
                else memories.forEach { append("MEMORY ${it.key}: ${it.value.take(1500)}\n") }
                conversations.forEach { append("${it.role.uppercase()}: ${it.content.take(2000)}\n") }
            }

            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", "You are JARVIS, a local-first personal assistant. Use the supplied context as supporting context, do not invent memories, and never claim an action was executed unless the action router returned success.\n\n$contextBlock"))
                .put(JSONObject().put("role", "user").put("content", prompt))

            val body = JSONObject().put("model", "local").put("stream", false).put("messages", messages).toString()
            val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT
                readTimeout = READ_TIMEOUT
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            connection.disconnect()
            if (code !in 200..299) return Result(false, error = "Local AI HTTP $code: ${response.take(300)}")
            val json = JSONObject(response)
            val text = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content", "")?.trim().orEmpty()
            if (text.isBlank()) Result(false, error = "Local AI returned an empty response") else Result(true, text = text)
        } catch (e: Exception) { Result(false, error = e.message ?: "Local AI connection failed") }
    }

    fun endpoint(): String = ENDPOINT
}
