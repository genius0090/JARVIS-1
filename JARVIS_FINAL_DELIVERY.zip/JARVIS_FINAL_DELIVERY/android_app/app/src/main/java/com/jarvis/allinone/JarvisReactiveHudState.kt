package com.jarvis.allinone

object JarvisReactiveHudState {
    enum class State {
        IDLE, LISTENING, THINKING, SPEAKING, WORKING, MISSION, ALERT
    }

    @Volatile private var state = State.IDLE

    fun setState(newState: State) {
        state = newState
    }

    fun getState(): State = state

    fun isOperational(): Boolean =
        state != State.ALERT

    fun status(): String = "HUD state: ${state.name}"
}
