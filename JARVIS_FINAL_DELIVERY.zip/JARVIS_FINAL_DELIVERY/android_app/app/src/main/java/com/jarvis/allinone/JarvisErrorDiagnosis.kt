package com.jarvis.allinone

object JarvisErrorDiagnosis {
    data class Diagnosis(
        val error:String,
        val cause:String,
        val recovery:String,
        val confidence:Float
    )

    private var latest:Diagnosis?=null

    fun diagnose(error:String,cause:String,recovery:String,confidence:Float=0.5f)=
        Diagnosis(error,cause,recovery,confidence.coerceIn(0f,1f)).also{latest=it}

    fun latest()=latest
}
