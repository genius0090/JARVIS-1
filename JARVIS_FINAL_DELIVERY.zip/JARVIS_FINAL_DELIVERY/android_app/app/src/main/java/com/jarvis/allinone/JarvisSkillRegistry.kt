package com.jarvis.allinone

object JarvisSkillRegistry {
    data class Skill(
        val id: String,
        val name: String,
        val description: String,
        val enabled: Boolean = true
    )

    private val skills = linkedMapOf<String, Skill>()

    fun register(id: String, name: String, description: String) {
        skills[id] = Skill(id, name, description)
    }

    fun get(id: String): Skill? = skills[id]

    fun all(): List<Skill> = skills.values.toList()

    fun explain(id: String): String =
        skills[id]?.let { "${it.name}: ${it.description}" }
            ?: "Skill not available"

    fun status(): String = "${skills.size} skills registered"
}
