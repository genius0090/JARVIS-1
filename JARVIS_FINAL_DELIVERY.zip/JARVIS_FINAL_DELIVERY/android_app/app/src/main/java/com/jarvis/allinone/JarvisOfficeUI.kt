package com.jarvis.allinone

import android.content.Context

object JarvisOfficeUI {
    fun documents(context: Context) = state("documents", "Documents", "READY", "Professional document generation/export available", true)
    fun spreadsheets(context: Context) = state("spreadsheets", "Spreadsheets", "READY", "Spreadsheet generation/export available", true)
    fun presentations(context: Context) = state("presentations", "Presentations", "READY", "Presentation generation/export available", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
