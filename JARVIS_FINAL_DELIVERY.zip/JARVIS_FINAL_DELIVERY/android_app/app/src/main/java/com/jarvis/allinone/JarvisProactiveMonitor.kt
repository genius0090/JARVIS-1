package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent proactive-alert queue. Monitoring is opt-in and does not silently execute actions. */
object JarvisProactiveMonitor {
    data class Alert(val source: String, val message: String, val priority: Int, val timestamp: Long)
    private const val PREFS = "jarvis_proactive_monitor"
    private const val KEY_ALERTS = "alerts"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun report(context: Context, source: String, message: String, priority: Int = 1) {
        if (source.isBlank() || message.isBlank()) return
        val array = JSONArray(prefs(context).getString(KEY_ALERTS, "[]") ?: "[]")
        array.put(JSONObject().put("source", source.take(120)).put("message", message.take(5000))
            .put("priority", priority.coerceIn(0, 10)).put("timestamp", System.currentTimeMillis()))
        while (array.length() > 100) array.remove(0)
        prefs(context).edit().putString(KEY_ALERTS, array.toString()).apply()
    }

    fun recent(context: Context, limit: Int = 20): List<Alert> {
        val array = JSONArray(prefs(context).getString(KEY_ALERTS, "[]") ?: "[]")
        val start = (array.length() - limit.coerceAtLeast(0)).coerceAtLeast(0)
        return buildList {
            for (i in start until array.length()) {
                val o = array.getJSONObject(i)
                add(Alert(o.optString("source"), o.optString("message"), o.optInt("priority"), o.optLong("timestamp")))
            }
        }
    }

    fun clear(context: Context) = prefs(context).edit().remove(KEY_ALERTS).apply()
}
