package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisIntegratedIntelligence {

    private const val PREFS = "jarvis_integrated_intelligence"
    private const val EVENTS = "events"
    private const val STATE = "state"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun state(context: Context): JSONObject =
        JSONObject(prefs(context).getString(STATE, "{}") ?: "{}")

    private fun saveState(context: Context, value: JSONObject) {
        prefs(context).edit().putString(STATE, value.toString()).apply()
    }

    private fun event(
        context: Context,
        type: String,
        data: JSONObject = JSONObject()
    ): String {
        val item = JSONObject(data.toString())
            .put("type", type)
            .put("timestamp", System.currentTimeMillis())

        val events = JSONArray(
            prefs(context).getString(EVENTS, "[]") ?: "[]"
        )
        events.put(item)

        while (events.length() > 200) {
            events.remove(0)
        }

        prefs(context).edit()
            .putString(EVENTS, events.toString())
            .apply()

        return item.toString()
    }

    fun explainWhy(
        context: Context,
        action: String,
        reason: String
    ) = event(
        context,
        "why_explanation",
        JSONObject()
            .put("action", action)
            .put("reason", reason)
    )

    fun setConfidence(
        context: Context,
        confidence: Float,
        basis: String
    ) = event(
        context,
        "confidence",
        JSONObject()
            .put("confidence", confidence.coerceIn(0f, 1f))
            .put("basis", basis)
    )

    fun separateFactAndAssumption(
        context: Context,
        fact: String,
        assumption: String
    ) = event(
        context,
        "fact_assumption",
        JSONObject()
            .put("fact", fact)
            .put("assumption", assumption)
    )

    fun rememberPreference(
        context: Context,
        key: String,
        value: String
    ) {
        val data = state(context)
            .put("preference_$key", value)
        saveState(context, data)
    }

    fun setTaskDependency(
        context: Context,
        task: String,
        dependsOn: List<String>
    ) = event(
        context,
        "task_dependency",
        JSONObject()
            .put("task", task)
            .put("dependsOn", JSONArray(dependsOn))
    )

    fun setVisualMemory(
        context: Context,
        name: String,
        description: String
    ) = event(
        context,
        "visual_memory",
        JSONObject()
            .put("name", name)
            .put("description", description)
    )

    fun futureImpactPreview(
        context: Context,
        action: String,
        impacts: List<String>
    ) = event(
        context,
        "future_impact",
        JSONObject()
            .put("action", action)
            .put("impacts", JSONArray(impacts))
    )

    fun setVoiceContextLock(
        context: Context,
        enabled: Boolean
    ) {
        saveState(
            context,
            state(context).put("voiceContextLock", enabled)
        )
    }

    fun rememberVoiceConfirmation(
        context: Context,
        command: String,
        confirmed: Boolean
    ) = event(
        context,
        "voice_confirmation",
        JSONObject()
            .put("command", command)
            .put("confirmed", confirmed)
    )

    fun rememberDevice(
        context: Context,
        device: String,
        status: String
    ) = event(
        context,
        "device",
        JSONObject()
            .put("device", device)
            .put("status", status)
    )

    fun rememberPermissionUsage(
        context: Context,
        permission: String,
        purpose: String
    ) = event(
        context,
        "permission_usage",
        JSONObject()
            .put("permission", permission)
            .put("purpose", purpose)
    )

    fun setSessionSecurityMode(
        context: Context,
        mode: String
    ) {
        saveState(
            context,
            state(context).put("securityMode", mode)
        )
    }

    fun setSensitiveBoundary(
        context: Context,
        enabled: Boolean
    ) {
        saveState(
            context,
            state(context).put("sensitiveDataBoundary", enabled)
        )
    }

    fun hudCommand(
        context: Context,
        command: String
    ) = event(
        context,
        "hud_command",
        JSONObject().put("command", command)
    )

    fun systemMap(
        context: Context,
        component: String,
        status: String
    ) = event(
        context,
        "system_map",
        JSONObject()
            .put("component", component)
            .put("status", status)
    )

    fun missionState(
        context: Context,
        mission: String,
        status: String
    ) = event(
        context,
        "mission",
        JSONObject()
            .put("mission", mission)
            .put("status", status)
    )

    fun contextualHud(
        context: Context,
        contextName: String
    ) {
        saveState(
            context,
            state(context).put("hudContext", contextName)
        )
    }

    fun setBatteryAwarePlan(
        context: Context,
        task: String,
        batteryLevel: Int
    ) = event(
        context,
        "battery_aware_plan",
        JSONObject()
            .put("task", task)
            .put("batteryLevel", batteryLevel)
    )

    fun setConnectivityState(
        context: Context,
        device: String,
        connected: Boolean
    ) = event(
        context,
        "connectivity",
        JSONObject()
            .put("device", device)
            .put("connected", connected)
    )

    fun setPeripheral(
        context: Context,
        peripheral: String,
        connected: Boolean
    ) = event(
        context,
        "peripheral",
        JSONObject()
            .put("peripheral", peripheral)
            .put("connected", connected)
    )

    fun setActionRisk(
        context: Context,
        action: String,
        risk: String
    ) = event(
        context,
        "action_risk",
        JSONObject()
            .put("action", action)
            .put("risk", risk)
    )

    fun setOrbPersonality(
        context: Context,
        stateName: String
    ) {
        saveState(
            context,
            state(context).put("orbPersonality", stateName)
        )
    }

    fun setMissionDashboard(
        context: Context,
        enabled: Boolean
    ) {
        saveState(
            context,
            state(context).put("missionDashboard", enabled)
        )
    }

    fun setWorkflowGraph(
        context: Context,
        workflow: String,
        nodes: List<String>
    ) = event(
        context,
        "workflow_graph",
        JSONObject()
            .put("workflow", workflow)
            .put("nodes", JSONArray(nodes))
    )

    fun setSimulationState(
        context: Context,
        simulation: String,
        stateName: String
    ) = event(
        context,
        "simulation",
        JSONObject()
            .put("simulation", simulation)
            .put("state", stateName)
    )

    fun events(context: Context): JSONArray =
        JSONArray(
            prefs(context).getString(EVENTS, "[]") ?: "[]"
        )

    fun status(context: Context): String =
        JSONObject()
            .put("integratedIntelligence", "ready")
            .put("state", state(context))
            .put("events", events(context).length())
            .put(
                "emergencyStop",
                JarvisEmergencyStop.isStopped(context)
            )
            .toString()

    fun clear(context: Context) {
        prefs(context).edit()
            .remove(EVENTS)
            .remove(STATE)
            .apply()
    }
}
