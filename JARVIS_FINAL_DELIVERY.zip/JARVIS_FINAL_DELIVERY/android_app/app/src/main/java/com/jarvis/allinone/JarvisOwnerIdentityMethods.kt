package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * #201 MULTIPLE OWNER IDENTITY METHODS
 *
 * Central registry for legitimate owner-verification methods.
 *
 * This layer stores method metadata only.
 * It never stores biometric templates, passwords, passkeys,
 * recovery secrets or authentication codes.
 *
 * Actual platform verification is connected by #203.
 */
object JarvisOwnerIdentityMethods {

    private const val PREFS = "jarvis_owner_identity_methods"
    private const val KEY_METHODS = "methods"

    enum class MethodType {
        BIOMETRIC,
        DEVICE_CREDENTIAL,
        PASSKEY,
        AUTHENTICATOR,
        RECOVERY_CODE,
        RECOVERY_KEY,
        TRUSTED_DEVICE,
        SECURITY_KEY,
        EXISTING_SESSION,
        EMERGENCY_RECOVERY
    }

    enum class Role {
        PRIMARY,
        BACKUP,
        EMERGENCY
    }

    enum class SecurityLevel {
        STANDARD,
        STRONG,
        HIGH
    }

    data class IdentityMethod(
        val id: String,
        val type: MethodType,
        val label: String,
        val role: Role,
        val securityLevel: SecurityLevel,
        val enabled: Boolean,
        val verified: Boolean,
        val lastVerified: Long
    ) {
        fun toJson(): JSONObject =
            JSONObject()
                .put("id", id)
                .put("type", type.name)
                .put("label", label)
                .put("role", role.name)
                .put("securityLevel", securityLevel.name)
                .put("enabled", enabled)
                .put("verified", verified)
                .put("lastVerified", lastVerified)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context) {
        if (!prefs(context).contains(KEY_METHODS)) {
            prefs(context)
                .edit()
                .putString(KEY_METHODS, JSONArray().toString())
                .apply()
        }
    }

    @Synchronized
    fun addMethod(
        context: Context,
        type: MethodType,
        label: String,
        role: Role,
        securityLevel: SecurityLevel
    ): String? {
        initialize(context)

        val clean = label.trim()

        if (clean.isBlank() || clean.length > 80) {
            return null
        }

        val methods = getMethods(context).toMutableList()

        if (methods.any {
                it.type == type &&
                it.label.equals(clean, ignoreCase = true)
            }) {
            return null
        }

        val id = "IDENTITY-" + UUID.randomUUID().toString()

        methods.add(
            IdentityMethod(
                id = id,
                type = type,
                label = clean,
                role = role,
                securityLevel = securityLevel,
                enabled = true,
                verified = false,
                lastVerified = 0L
            )
        )

        saveMethods(context, methods)

        JarvisAuditTrail.record(
            "IDENTITY_METHOD_ADDED",
            type.name
        )

        return id
    }

    @Synchronized
    fun removeMethod(
        context: Context,
        methodId: String
    ): Boolean {
        val methods = getMethods(context).toMutableList()
        val removed = methods.removeAll { it.id == methodId }

        if (!removed) return false

        saveMethods(context, methods)

        JarvisAuditTrail.record(
            "IDENTITY_METHOD_REMOVED",
            "SUCCESS"
        )

        return true
    }

    @Synchronized
    fun setEnabled(
        context: Context,
        methodId: String,
        enabled: Boolean
    ): Boolean {
        val methods = getMethods(context).toMutableList()
        val index = methods.indexOfFirst { it.id == methodId }

        if (index < 0) return false

        methods[index] = methods[index].copy(
            enabled = enabled
        )

        saveMethods(context, methods)

        JarvisAuditTrail.record(
            "IDENTITY_METHOD_STATE",
            if (enabled) "ENABLED" else "DISABLED"
        )

        return true
    }

    /**
     * Marks a method as verified only after a legitimate
     * verification layer reports success.
     */
    @Synchronized
    fun markVerified(
        context: Context,
        methodId: String
    ): Boolean {
        val methods = getMethods(context).toMutableList()
        val index = methods.indexOfFirst { it.id == methodId }

        if (index < 0) return false

        methods[index] = methods[index].copy(
            verified = true,
            lastVerified = System.currentTimeMillis()
        )

        saveMethods(context, methods)

        JarvisAuditTrail.record(
            "IDENTITY_METHOD_VERIFIED",
            "SUCCESS"
        )

        return true
    }

    fun getMethods(context: Context): List<IdentityMethod> {
        initialize(context)

        val raw = prefs(context)
            .getString(KEY_METHODS, "[]") ?: "[]"

        return runCatching {
            val array = JSONArray(raw)

            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)

                    val type = runCatching {
                        MethodType.valueOf(
                            item.optString(
                                "type",
                                MethodType.EXISTING_SESSION.name
                            )
                        )
                    }.getOrDefault(MethodType.EXISTING_SESSION)

                    val role = runCatching {
                        Role.valueOf(
                            item.optString(
                                "role",
                                Role.BACKUP.name
                            )
                        )
                    }.getOrDefault(Role.BACKUP)

                    val level = runCatching {
                        SecurityLevel.valueOf(
                            item.optString(
                                "securityLevel",
                                SecurityLevel.STANDARD.name
                            )
                        )
                    }.getOrDefault(SecurityLevel.STANDARD)

                    add(
                        IdentityMethod(
                            id = item.optString("id"),
                            type = type,
                            label = item.optString("label"),
                            role = role,
                            securityLevel = level,
                            enabled = item.optBoolean("enabled"),
                            verified = item.optBoolean("verified"),
                            lastVerified = item.optLong("lastVerified", 0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun availableMethods(context: Context): List<IdentityMethod> =
        getMethods(context).filter { it.enabled }

    fun verifiedMethods(context: Context): List<IdentityMethod> =
        getMethods(context).filter {
            it.enabled && it.verified
        }

    fun hasPrimaryMethod(context: Context): Boolean =
        getMethods(context).any {
            it.enabled && it.role == Role.PRIMARY
        }

    fun hasBackupMethod(context: Context): Boolean =
        getMethods(context).any {
            it.enabled && it.role == Role.BACKUP
        }

    fun hasEmergencyMethod(context: Context): Boolean =
        getMethods(context).any {
            it.enabled && it.role == Role.EMERGENCY
        }

    fun statusJson(context: Context): String {
        val methods = getMethods(context)

        val array = JSONArray()
        methods.forEach {
            array.put(it.toJson())
        }

        return JSONObject()
            .put(
                "ownerAccount",
                JarvisPermanentOwnerAccount.isInitialized(context)
            )
            .put("totalMethods", methods.size)
            .put("enabledMethods", availableMethods(context).size)
            .put("verifiedMethods", verifiedMethods(context).size)
            .put("hasPrimary", hasPrimaryMethod(context))
            .put("hasBackup", hasBackupMethod(context))
            .put("hasEmergency", hasEmergencyMethod(context))
            .put("methods", array)
            .toString()
    }

    fun healthCheck(context: Context): Boolean {
        initialize(context)

        return JarvisPermanentOwnerAccount.isInitialized(context) &&
                getMethods(context).none {
                    it.id.isBlank() ||
                    it.label.isBlank()
                }
    }

    private fun saveMethods(
        context: Context,
        methods: List<IdentityMethod>
    ) {
        val array = JSONArray()

        methods.forEach {
            array.put(it.toJson())
        }

        prefs(context)
            .edit()
            .putString(KEY_METHODS, array.toString())
            .apply()
    }
}
