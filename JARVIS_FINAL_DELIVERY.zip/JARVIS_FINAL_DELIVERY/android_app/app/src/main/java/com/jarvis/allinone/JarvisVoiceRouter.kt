package com.jarvis.allinone

import android.content.Context

/** Single voice-selection boundary; delegates actual TTS settings to VoiceProfile. */
object JarvisVoiceRouter {
    enum class Voice { DEFAULT, ORIGINAL_JARVIS, CC_EXTERNAL, CUSTOM }

    fun setVoice(context: Context, voice: Voice) {
        val mapped = when (voice) {
            Voice.DEFAULT -> JarvisVoiceProfile.Voice.DEFAULT
            Voice.ORIGINAL_JARVIS -> JarvisVoiceProfile.Voice.ORIGINAL_JARVIS
            Voice.CC_EXTERNAL -> JarvisVoiceProfile.Voice.CC_EXTERNAL
            Voice.CUSTOM -> JarvisVoiceProfile.Voice.CUSTOM
        }
        JarvisVoiceProfile.setVoice(mapped)
        context.getSharedPreferences("jarvis_voice_router", Context.MODE_PRIVATE)
            .edit().putString("voice", voice.name).apply()
    }

    fun getVoice(context: Context): Voice = runCatching {
        Voice.valueOf(context.getSharedPreferences("jarvis_voice_router", Context.MODE_PRIVATE)
            .getString("voice", Voice.DEFAULT.name) ?: Voice.DEFAULT.name)
    }.getOrDefault(Voice.DEFAULT)

    fun status(context: Context) = "Voice: ${getVoice(context).name}"
}
