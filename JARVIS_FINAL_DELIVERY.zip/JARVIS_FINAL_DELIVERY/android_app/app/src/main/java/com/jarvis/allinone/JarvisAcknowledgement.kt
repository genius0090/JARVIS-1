package com.jarvis.allinone

object JarvisAcknowledgement {
    enum class Type { RECEIVED, WORKING, DONE, FAILED }

    fun message(type: Type): String = when (type) {
        Type.RECEIVED -> "Understood."
        Type.WORKING -> "Working on it."
        Type.DONE -> "Done."
        Type.FAILED -> "I couldn't complete that task."
    }

    fun acknowledgement(type: Type): Pair<String, Type> =
        message(type) to type
}
