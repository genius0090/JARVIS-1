package com.jarvis.allinone

object JarvisFarFieldVoice {
    private var enabled=false
    private var sensitivity=0.7f

    fun enable(){enabled=true}
    fun disable(){enabled=false}
    fun isEnabled()=enabled

    fun setSensitivity(value:Float){
        sensitivity=value.coerceIn(0f,1f)
    }

    fun sensitivity()=sensitivity
}
