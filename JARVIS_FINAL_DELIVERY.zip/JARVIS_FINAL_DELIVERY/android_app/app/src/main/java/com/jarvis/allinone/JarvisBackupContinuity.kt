package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

object JarvisBackupContinuity {

    private const val PREFS = "jarvis_backup_continuity"
    private const val KEY_LAST_BACKUP = "last_backup"
    private const val KEY_BACKUP_VERSION = "backup_version"
    private const val KEY_BACKUP_COUNT = "backup_count"

    private const val BACKUP_DIR = "jarvis_backups"
    private const val BACKUP_FILE = "jarvis_central_memory_backup.json"

    fun initialize(context: Context): JSONObject {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        if (!prefs.contains(KEY_BACKUP_VERSION)) {
            prefs.edit()
                .putString(KEY_BACKUP_VERSION, "1")
                .putLong(KEY_BACKUP_COUNT, 0L)
                .apply()
        }

        return statusJson(context)
    }

    fun createBackup(context: Context): JSONObject {
        val centralMemory = context.getSharedPreferences(
            "jarvis_central_memory",
            Context.MODE_PRIVATE
        )

        val data = JSONObject()

        data.put("backup_version", "1")
        data.put("created_at", System.currentTimeMillis())
        data.put("source", "JARVIS Central Memory")

        val memories = try {
            JSONArray(centralMemory.getString("memories", "[]") ?: "[]")
        } catch (_: Throwable) { JSONArray() }

        val conversations = try {
            JSONArray(centralMemory.getString("conversations", "[]") ?: "[]")
        } catch (_: Throwable) { JSONArray() }

        data.put("memories", memories)
        data.put("conversations", conversations)

        data.put(
            "preferences",
            JSONObject(
                centralMemory.getString("preferences", "{}") ?: "{}"
            )
        )

        data.put(
            "settings",
            JSONObject(
                centralMemory.getString("settings", "{}") ?: "{}"
            )
        )

        data.put(
            "state",
            JSONObject(
                centralMemory.getString("state", "{}") ?: "{}"
            )
        )

        data.put(
            "device_state",
            JSONObject(
                centralMemory.getString("device_state", "{}") ?: "{}"
            )
        )

        val checksum = sha256(data.toString())
        data.put("checksum", checksum)

        val directory = File(context.filesDir, BACKUP_DIR)
        if (!directory.exists()) {
            directory.mkdirs()
        }

        val backupFile = File(directory, BACKUP_FILE)
        backupFile.writeText(data.toString(2))

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val count = prefs.getLong(KEY_BACKUP_COUNT, 0L) + 1L

        prefs.edit()
            .putLong(KEY_LAST_BACKUP, System.currentTimeMillis())
            .putLong(KEY_BACKUP_COUNT, count)
            .apply()

        return JSONObject()
            .put("success", true)
            .put("file", backupFile.absolutePath)
            .put("checksum", checksum)
            .put("backup_count", count)
    }

    fun verifyBackup(context: Context): JSONObject {
        val file = File(context.filesDir, "$BACKUP_DIR/$BACKUP_FILE")

        if (!file.exists()) {
            return JSONObject()
                .put("valid", false)
                .put("reason", "backup_missing")
        }

        return try {
            val data = JSONObject(file.readText())
            val storedChecksum = data.optString("checksum", "")

            data.remove("checksum")
            val calculatedChecksum = sha256(data.toString())

            JSONObject()
                .put("valid", storedChecksum.isNotEmpty() &&
                        storedChecksum == calculatedChecksum)
                .put("stored_checksum", storedChecksum)
                .put("calculated_checksum", calculatedChecksum)
        } catch (e: Exception) {
            JSONObject()
                .put("valid", false)
                .put("reason", "backup_corrupt")
        }
    }

    fun restoreBackup(context: Context): JSONObject {
        val file = File(context.filesDir, "$BACKUP_DIR/$BACKUP_FILE")

        if (!file.exists()) {
            return JSONObject()
                .put("success", false)
                .put("reason", "backup_missing")
        }

        val verification = verifyBackup(context)

        if (!verification.optBoolean("valid", false)) {
            return JSONObject()
                .put("success", false)
                .put("reason", "backup_integrity_failed")
        }

        return try {
            val data = JSONObject(file.readText())
            val memoryPrefs = context.getSharedPreferences(
                "jarvis_central_memory",
                Context.MODE_PRIVATE
            )

            memoryPrefs.edit()
                .putString(
                    "memories",
                    data.optJSONArray("memories")?.toString() ?: "[]"
                )
                .putString(
                    "conversations",
                    data.optJSONArray("conversations")?.toString() ?: "[]"
                )
                .putString(
                    "preferences",
                    data.optJSONObject("preferences")?.toString() ?: "{}"
                )
                .putString(
                    "settings",
                    data.optJSONObject("settings")?.toString() ?: "{}"
                )
                .putString(
                    "state",
                    data.optJSONObject("state")?.toString() ?: "{}"
                )
                .putString(
                    "device_state",
                    data.optJSONObject("device_state")?.toString() ?: "{}"
                )
                .apply()

            JSONObject()
                .put("success", true)
                .put("restored", true)
                .put("verified", true)
        } catch (e: Exception) {
            JSONObject()
                .put("success", false)
                .put("reason", "restore_failed")
        }
    }

    fun maybeAutomaticBackup(context: Context, maxAgeMs: Long = 6L * 60L * 60L * 1000L): JSONObject? {
        initialize(context)
        val last = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_BACKUP, 0L)
        return if (last == 0L || System.currentTimeMillis() - last >= maxAgeMs) createBackup(context) else null
    }

    fun statusJson(context: Context): JSONObject {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val verification = verifyBackup(context)

        return JSONObject()
            .put("backup_enabled", true)
            .put("automatic_backup_boundary", true)
            .put("last_backup", prefs.getLong(KEY_LAST_BACKUP, 0L))
            .put("backup_count", prefs.getLong(KEY_BACKUP_COUNT, 0L))
            .put("backup_present", verification.optBoolean("valid", false))
            .put("integrity_check", verification.optBoolean("valid", false))
            .put("restore_available", verification.optBoolean("valid", false))
            .put("safe_recovery", true)
            .put("plaintext_auth_secrets", false)
    }

    fun healthCheck(context: Context): Boolean {
        return try {
            initialize(context)
            val status = statusJson(context)
            status.optBoolean("backup_enabled", false) &&
                    status.optBoolean("safe_recovery", false)
        } catch (_: Exception) {
            false
        }
    }

    private fun sha256(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
