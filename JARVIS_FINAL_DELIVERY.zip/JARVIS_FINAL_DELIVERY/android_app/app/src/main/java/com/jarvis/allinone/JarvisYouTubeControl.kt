package com.jarvis.allinone

import android.content.Context
import android.view.KeyEvent
import android.media.AudioManager
import org.json.JSONObject
import java.net.URLEncoder

object JarvisYouTubeControl {
    enum class Command { PLAY, PAUSE, NEXT, PREVIOUS, STOP }
    private var lastCommand: Command? = null

    fun issue(command: Command): Command {
        lastCommand = command
        return command
    }

    fun lastCommand(): Command? = lastCommand

    fun handleCommand(context: Context, text: String): Boolean {
        val lower = text.lowercase()
        val command = when {
            lower.contains("pause") -> Command.PAUSE
            lower.contains("next") -> Command.NEXT
            lower.contains("previous") || lower.contains("back") -> Command.PREVIOUS
            lower.contains("stop") -> Command.STOP
            lower.contains("play") -> Command.PLAY
            else -> null
        }

        if (command != null) {
            issue(command)
            val keyCode = when (command) {
                Command.PLAY, Command.PAUSE -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                Command.NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
                Command.PREVIOUS -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                Command.STOP -> KeyEvent.KEYCODE_MEDIA_STOP
            }
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val now = System.currentTimeMillis()
            try {
                audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
                audio.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
            } catch (_: Throwable) {
                return false
            }
            return true
        }

        val query = text.substringAfter("youtube", "").trim()
        if (query.isNotBlank()) {
            val encoded = URLEncoder.encode(query, Charsets.UTF_8.name())
            JarvisBrowserManager.openUrl(context, "https://www.youtube.com/results?search_query=$encoded")
            return true
        }
        JarvisBrowserManager.openUrl(context, "https://www.youtube.com")
        return true
    }

    fun status(): String = lastCommand?.let { "Last media command: ${it.name}" } ?: "No media command"

    fun statusJson(): JSONObject = JSONObject()
        .put("youtube_control", "AVAILABLE")
        .put("last_command", lastCommand?.name ?: JSONObject.NULL)
        .put("browser_search_fallback", true)
}
