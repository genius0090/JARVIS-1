package com.jarvis.allinone

import android.content.Context
import java.net.InetSocketAddress
import java.net.Socket

object JarvisPhonePcBridge {

    data class Device(
        val host: String,
        val port: Int,
        val reachable: Boolean
    )

    private var connectedDevice: Device? = null

    fun connect(host: String, port: Int = 8765): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 1500)
            }
            connectedDevice = Device(host, port, true)
            true
        } catch (_: Exception) {
            connectedDevice = Device(host, port, false)
            false
        }
    }

    fun disconnect() {
        connectedDevice = null
    }

    fun isConnected(): Boolean {
        return connectedDevice?.reachable == true
    }

    fun status(): String {
        val device = connectedDevice

        return if (device == null) {
            "PHONE ↔ PC BRIDGE\n\nNo PC connected."
        } else {
            buildString {
                append("PHONE ↔ PC BRIDGE\n\n")
                append("Host: ${device.host}\n")
                append("Port: ${device.port}\n")
                append(
                    if (device.reachable)
                        "Status: CONNECTED"
                    else
                        "Status: UNREACHABLE"
                )
            }
        }
    }

    fun handleCommand(context: Context, command: String): Boolean {
        val text = command.trim()

        return when {
            text.equals("pc status", true) ||
            text.equals("computer status", true) ||
            text.equals("check pc", true) -> {
                status()
                true
            }

            text.startsWith("connect pc ", true) -> {
                val host = text.substringAfter("connect pc ").trim()
                connect(host)
                true
            }

            text.equals("disconnect pc", true) -> {
                disconnect()
                true
            }

            else -> false
        }
    }
}
