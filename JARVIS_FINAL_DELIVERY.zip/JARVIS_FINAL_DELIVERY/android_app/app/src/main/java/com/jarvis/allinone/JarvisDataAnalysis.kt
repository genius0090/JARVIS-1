package com.jarvis.allinone

object JarvisDataAnalysis {
    data class Result(
        val rows: Int,
        val columns: Int,
        val summary: String,
        val warnings: List<String> = emptyList()
    )

    private var latest: Result? = null

    fun analyze(
        rows: Int,
        columns: Int,
        summary: String,
        warnings: List<String> = emptyList()
    ): Result {
        return Result(rows, columns, summary, warnings).also {
            latest = it
        }
    }

    fun latest(): Result? = latest
    fun clear() { latest = null }
}
