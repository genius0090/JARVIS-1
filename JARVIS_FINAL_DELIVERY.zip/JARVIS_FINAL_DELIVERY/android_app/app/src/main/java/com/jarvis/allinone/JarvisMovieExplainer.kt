package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Structured movie-explainer workflow; generation/editing is routed through the media engine. */
object JarvisMovieExplainer {
    private const val PREFS = "jarvis_movie_explainer"
    private const val KEY_PROJECTS = "projects"

    fun createPlan(context: Context, title: String, language: String = "Hinglish"): JSONObject {
        val id = UUID.randomUUID().toString()
        val plan = JSONObject()
            .put("id", id)
            .put("title", title)
            .put("language", language)
            .put("stages", JSONArray(listOf("source", "story_structure", "voice_script", "visual_plan", "timeline", "review", "export")))
            .put("copyright_safe_workflow", true)
            .put("originality_required", true)
            .put("status", "PLANNED")
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_PROJECTS, "[]") ?: "[]")
        arr.put(plan)
        prefs.edit().putString(KEY_PROJECTS, arr.toString()).apply()
        return plan
    }

    fun plans(context: Context): JSONArray = JSONArray(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PROJECTS, "[]") ?: "[]"
    )
}
