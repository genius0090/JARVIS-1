package com.jarvis.allinone

object JarvisSecureAIEnvironment {
    data class Session(
        val id:String,
        val startedAt:Long=System.currentTimeMillis()
    )

    private var active:Session?=null

    fun start(id:String):Session{
        return Session(id).also{active=it}
    }

    fun active():Session?=active

    fun canExecute(
        sensitive:Boolean,
        approved:Boolean
    ):Boolean{
        if(active==null)return false
        return !sensitive || approved
    }

    fun close(){active=null}
}
