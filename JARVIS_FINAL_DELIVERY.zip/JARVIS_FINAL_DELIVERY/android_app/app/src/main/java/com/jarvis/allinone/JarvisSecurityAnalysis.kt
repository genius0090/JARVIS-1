package com.jarvis.allinone

import android.content.Context

object JarvisSecurityAnalysis {

    data class Result(
        val allowed: Boolean,
        val reason: String
    )

    fun analyze(
        context: Context,
        action: String,
        requiresAuthorization: Boolean = true
    ): Result {

        if (JarvisEmergencyStop.isStopped(context)) {
            return Result(false, "Emergency STOP is active")
        }

        if (JarvisTaskRecovery.isCancellationRequested(context)) {
            return Result(false, "Task cancellation is active")
        }

        if (requiresAuthorization &&
            !JarvisSecurityLab.isAuthorizedScope(context)) {
            return Result(false, "Authorized security-lab scope required")
        }

        if (action.isBlank()) {
            return Result(false, "Empty security action")
        }

        return Result(
            true,
            "Security action allowed for analysis: $action"
        )
    }

    fun status(context: Context): String {
        return when {
            JarvisEmergencyStop.isStopped(context) ->
                "BLOCKED: EMERGENCY STOP"

            JarvisTaskRecovery.isCancellationRequested(context) ->
                "BLOCKED: TASK CANCELLATION"

            !JarvisSecurityLab.isAuthorizedScope(context) ->
                "BLOCKED: AUTHORIZATION REQUIRED"

            else ->
                "SECURITY ANALYSIS READY"
        }
    }
}
