package com.jarvis.allinone

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class JarvisQuickTileService : TileService() {
    override fun onClick() {
        super.onClick()
        qsTile?.apply {
            state = if (state == Tile.STATE_ACTIVE) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
            label = "JARVIS"
            updateTile()
        }
    }

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            label = "JARVIS"
            state = Tile.STATE_INACTIVE
            updateTile()
        }
    }
}
