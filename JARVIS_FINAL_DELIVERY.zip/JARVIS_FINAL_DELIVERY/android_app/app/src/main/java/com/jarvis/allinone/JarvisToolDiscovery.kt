package com.jarvis.allinone

object JarvisToolDiscovery {
    data class Tool(
        val id: String,
        val name: String,
        val description: String,
        val enabled: Boolean = true
    )

    private val tools = linkedMapOf<String, Tool>()

    fun register(id: String, name: String, description: String) {
        tools[id] = Tool(id, name, description)
    }

    fun find(query: String): List<Tool> {
        val q = query.lowercase()
        return tools.values.filter {
            it.name.lowercase().contains(q) ||
            it.description.lowercase().contains(q)
        }
    }

    fun all(): List<Tool> = tools.values.toList()
    fun clear() = tools.clear()
}
