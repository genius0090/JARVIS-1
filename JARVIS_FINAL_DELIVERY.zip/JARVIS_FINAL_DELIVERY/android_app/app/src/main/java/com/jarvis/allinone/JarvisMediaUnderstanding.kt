package com.jarvis.allinone

object JarvisMediaUnderstanding {
    enum class MediaType { IMAGE, VIDEO, AUDIO, UNKNOWN }

    data class Analysis(
        val type: MediaType,
        val summary: String,
        val confidence: Float
    )

    private var latest: Analysis? = null

    fun analyze(
        type: MediaType,
        summary: String,
        confidence: Float = 0f
    ): Analysis {
        return Analysis(type, summary, confidence.coerceIn(0f, 1f))
            .also { latest = it }
    }

    fun latest(): Analysis? = latest
    fun clear() { latest = null }
}
