package com.jarvis.allinone

object JarvisSessionContinuity {
    data class Session(
        val id: String,
        val title: String,
        val context: MutableMap<String, String> = mutableMapOf(),
        val startedAt: Long = System.currentTimeMillis()
    )

    private var active: Session? = null

    fun start(id: String, title: String): Session {
        return Session(id, title).also { active = it }
    }

    fun current(): Session? = active

    fun put(key: String, value: String) {
        active?.context?.set(key, value)
    }

    fun get(key: String): String? =
        active?.context?.get(key)

    fun end() {
        active = null
    }
}
