package com.jarvis.allinone

object JarvisProactiveBriefing {
    data class Briefing(val title: String, val items: List<String>)

    private var latest = Briefing("JARVIS Briefing", emptyList())

    fun update(items: List<String>) {
        latest = Briefing("JARVIS Briefing", items)
    }

    fun current(): Briefing = latest
}
