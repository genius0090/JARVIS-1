package com.jarvis.allinone

import android.content.Context
import android.media.MediaPlayer

/** Optional external CC audio-pack adapter. The actual licensed audio asset is supplied separately. */
object JarvisCcVoice {
    private var player: MediaPlayer? = null

    fun isConfigured(context: Context): Boolean =
        runCatching { context.resources.getIdentifier("jarvis_cc_voice", "raw", context.packageName) != 0 }.getOrDefault(false)

    fun play(context: Context): Boolean {
        val id = context.resources.getIdentifier("jarvis_cc_voice", "raw", context.packageName)
        if (id == 0) return false
        return try {
            player?.release()
            player = MediaPlayer.create(context.applicationContext, id)
            player?.setOnCompletionListener { it.release(); player = null }
            player?.start()
            true
        } catch (_: Throwable) {
            player?.release(); player = null
            false
        }
    }

    fun stop() { player?.stop(); player?.release(); player = null }
}
