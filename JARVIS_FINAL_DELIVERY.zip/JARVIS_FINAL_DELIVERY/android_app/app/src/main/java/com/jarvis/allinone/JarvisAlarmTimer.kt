package com.jarvis.allinone

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object JarvisAlarmTimer {

    fun schedule(context: Context, triggerAtMillis: Long, requestCode: Int) {
        val intent = Intent(context, JarvisAlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm?.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAtMillis,
            pending
        )
    }

    fun cancel(context: Context, requestCode: Int) {
        val intent = Intent(context, JarvisAlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java)?.cancel(pending)
    }
}
