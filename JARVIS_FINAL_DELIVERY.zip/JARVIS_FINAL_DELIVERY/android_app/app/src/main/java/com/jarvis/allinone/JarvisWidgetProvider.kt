package com.jarvis.allinone

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class JarvisWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        manager: AppWidgetManager,
        ids: IntArray
    ) {
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.jarvis_widget)
            views.setTextViewText(R.id.jarvis_widget_title, "JARVIS")
            views.setTextViewText(R.id.jarvis_widget_status, "● ONLINE")
            manager.updateAppWidget(id, views)
        }
    }
}
