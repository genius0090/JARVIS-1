package com.jarvis.allinone

import android.content.Context
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object JarvisIntelligenceEngine {

    enum class Mode {
        AUTO,
        FAST,
        DEEP
    }

    data class PlanStep(
        val number: Int,
        val action: String,
        val status: String = "PENDING"
    )

    data class SearchResult(
        val text: String,
        val score: Int
    )

    private var mode = Mode.AUTO

    private val conversationHistory =
        ConcurrentHashMap<Long, String>()

    fun setMode(newMode: Mode) {
        mode = newMode
    }

    fun getMode(): Mode = mode

    fun recordConversation(text: String) {
        if (text.isBlank()) return
        conversationHistory[System.currentTimeMillis()] = text.trim()
    }

    fun clearConversationHistory() {
        conversationHistory.clear()
    }

    fun searchConversation(query: String): List<SearchResult> {
        if (query.isBlank()) return emptyList()

        val terms = query
            .lowercase()
            .split(Regex("\\s+"))
            .filter { it.length > 1 }

        return conversationHistory.values
            .map { text ->
                val lower = text.lowercase()
                val score = terms.count { lower.contains(it) }
                SearchResult(text, score)
            }
            .filter { it.score > 0 }
            .sortedByDescending { it.score }
            .take(20)
    }

    fun createPlan(command: String): List<PlanStep> {
        val text = command.trim().lowercase()

        if (text.isBlank()) return emptyList()

        val actions = mutableListOf<String>()

        when {
            text.contains("download") -> {
                actions += "Understand requested file"
                actions += "Open/resolve download source"
                actions += "Download file"
                actions += "Verify downloaded file"
            }

            text.contains("clean") ||
            text.contains("storage") -> {
                actions += "Scan storage"
                actions += "Identify cleanup candidates"
                actions += "Show affected items"
                actions += "Request confirmation before deletion"
            }

            text.contains("pc") ||
            text.contains("computer") -> {
                actions += "Check PC connection"
                actions += "Identify requested PC action"
                actions += "Prepare remote command"
                actions += "Execute only after required confirmation"
                actions += "Return result"
            }

            text.contains("search") -> {
                actions += "Understand search request"
                actions += "Select search source"
                actions += "Perform search"
                actions += "Summarize results"
            }

            text.contains("file") -> {
                actions += "Identify target file"
                actions += "Inspect file state"
                actions += "Perform requested operation"
                actions += "Verify result"
            }

            else -> {
                actions += "Understand request"
                actions += "Determine required tools"
                actions += "Execute required steps"
                actions += "Verify result"
            }
        }

        return actions.mapIndexed { index, action ->
            PlanStep(index + 1, action)
        }
    }

    fun shouldThinkDeeply(command: String): Boolean {
        if (mode == Mode.DEEP) return true
        if (mode == Mode.FAST) return false

        val text = command.lowercase()

        val complexTerms = listOf(
            "plan",
            "workflow",
            "multiple",
            "step",
            "analyze",
            "compare",
            "organize",
            "automate",
            "research",
            "complex"
        )

        return complexTerms.any { text.contains(it) } ||
                command.length > 180
    }

    fun analyze(command: String): String {
        recordConversation(command)

        val deep = shouldThinkDeeply(command)
        val plan = createPlan(command)

        return buildString {
            append("JARVIS INTELLIGENCE\n\n")
            append("MODE: ${if (deep) "DEEP THINKING" else "AUTO"}\n")
            append("PLANNING: ${if (plan.isNotEmpty()) "READY" else "NONE"}\n\n")

            if (plan.isNotEmpty()) {
                append("PLAN\n")
                plan.forEach {
                    append("${it.number}. ${it.action}\n")
                }
            }
        }
    }

    fun summary(): String {
        return """
            JARVIS INTELLIGENCE

            Auto Thinking: ENABLED
            Current Mode: $mode
            Task Planning: READY
            Conversation Search: READY
            History Items: ${conversationHistory.size}
        """.trimIndent()
    }

    fun handleCommand(context: Context, command: String): Boolean {
        val text = command.trim()

        when {
            text.equals("thinking mode", true) ||
            text.equals("auto thinking", true) -> {
                setMode(Mode.AUTO)
                return true
            }

            text.equals("deep thinking", true) -> {
                setMode(Mode.DEEP)
                return true
            }

            text.equals("fast mode", true) -> {
                setMode(Mode.FAST)
                return true
            }

            text.equals("thinking status", true) ||
            text.equals("intelligence status", true) -> {
                return true
            }

            text.startsWith("plan ", true) -> {
                createPlan(text.substringAfter("plan "))
                return true
            }

            text.startsWith("search conversation ", true) -> {
                searchConversation(text.substringAfter("search conversation "))
                return true
            }

            text.startsWith("search chat ", true) -> {
                searchConversation(text.substringAfter("search chat "))
                return true
            }

            else -> return false
        }
    }
}
