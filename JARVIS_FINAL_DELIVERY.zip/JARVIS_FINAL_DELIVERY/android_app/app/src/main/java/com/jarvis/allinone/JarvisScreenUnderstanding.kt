package com.jarvis.allinone

import android.content.Context
import android.graphics.Bitmap
import android.media.projection.MediaProjection

object JarvisScreenUnderstanding {
    var mediaProjection: MediaProjection? = null
    private var lastScreenshot: Bitmap? = null

    fun captureReady(): Boolean = mediaProjection != null
    fun screenState(context: Context): String = if (captureReady()) "SCREEN_CAPTURE_READY" else "SCREEN_CAPTURE_PERMISSION_REQUIRED"
    fun visibleScreenUnderstanding(context: Context) = JarvisUiState("screen_understanding", "Screen Understanding", screenState(context), "On-demand screen capture/analysis", captureReady())
    fun ocrFoundation(context: Context) = JarvisUiState("ocr", "OCR", if (captureReady()) "READY" else "PERMISSION_REQUIRED", "OCR requires a captured screen/image", captureReady())
    fun screenshot(bitmap: Bitmap?) { lastScreenshot?.recycle(); lastScreenshot = bitmap }
    fun lastScreenshot(): Bitmap? = lastScreenshot
    fun screenRecordingReady(): Boolean = mediaProjection != null
}
