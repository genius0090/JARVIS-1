package com.jarvis.allinone

import android.content.Context

object JarvisOwnerAuthority {
    private const val PREFS = "jarvis_owner_authority"
    private const val KEY_OWNER_APPROVAL = "owner_approval"

    fun setOwnerApproval(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_OWNER_APPROVAL, enabled)
            .apply()
    }

    fun hasOwnerApproval(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_OWNER_APPROVAL, false)

    fun canOverrideInternalConfirmation(context: Context): Boolean =
        hasOwnerApproval(context)

    fun canBypassPlatformSecurity(): Boolean = false
    fun canBypassAndroidPermissions(): Boolean = false

    fun status(context: Context): String =
        if (hasOwnerApproval(context))
            "Owner authority enabled — platform safeguards remain active"
        else
            "Owner authority disabled"
}
