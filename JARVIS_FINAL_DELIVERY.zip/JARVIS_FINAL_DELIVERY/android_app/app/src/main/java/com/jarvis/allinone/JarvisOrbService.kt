package com.jarvis.allinone

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

/** Floating JARVIS Orb + compact HUD service. */
class JarvisOrbService : Service() {

    private lateinit var windowManager: WindowManager
    private var orb: JarvisReactiveOrbView? = null
    private var hud: View? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(98, notification())
        if (Settings.canDrawOverlays(this)) createOrb()
    }

    private fun createOrb() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = JarvisReactiveOrbView(this).apply {
            state = JarvisReactiveOrbView.State.IDLE
            contentDescription = "JARVIS floating Orb"
        }

        val params = WindowManager.LayoutParams(
            118,
            118,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 260
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(v, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - downX) + kotlin.math.abs(event.rawY - downY)
                    if (moved < 18f) showHud()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        orb = view
    }

    private fun showHud() {
        hud?.let { return }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 22)
            background = GradientDrawable().apply {
                cornerRadius = 32f
                setColor(Color.rgb(7, 14, 24))
                setStroke(2, Color.rgb(150, 112, 48))
            }
            elevation = 28f
        }

        val title = TextView(this).apply {
            text = "JARVIS  •  COMMAND HUD"
            textSize = 19f
            setTextColor(Color.rgb(255, 205, 90))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(4, 4, 4, 8)
        }
        panel.addView(title)

        val hudOrb = JarvisReactiveOrbView(this).apply {
            state = JarvisReactiveOrbView.State.IDLE
            contentDescription = "JARVIS reactive HUD core"
        }
        panel.addView(hudOrb, LinearLayout.LayoutParams(-1, 210).apply { bottomMargin = 4 })

        val state = TextView(this).apply {
            text = "● READY"
            textSize = 12f
            setTextColor(Color.rgb(185, 205, 220))
            gravity = Gravity.CENTER
            setPadding(4, 4, 4, 14)
        }
        panel.addView(state)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun chip(label: String, action: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(14, 13, 14, 13)
            background = GradientDrawable().apply {
                cornerRadius = 18f
                setColor(Color.rgb(13, 27, 42))
                setStroke(1, Color.rgb(75, 100, 120))
            }
            setOnClickListener { action() }
        }

        row.addView(chip("WAKE ON") {
            JarvisBackgroundWake.enable()
            val wakeIntent = Intent(this, JarvisWakeService::class.java).setAction(JarvisWakeService.ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(wakeIntent) else startService(wakeIntent)
            orb?.state = JarvisReactiveOrbView.State.LISTENING
            hudOrb.state = JarvisReactiveOrbView.State.LISTENING
            state.text = "● WAKE LISTENER ACTIVE"
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 5 })
        row.addView(chip("MISSION") {
            orb?.state = JarvisReactiveOrbView.State.MISSION
            hudOrb.state = JarvisReactiveOrbView.State.MISSION
            state.text = "● MISSION"
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 5 })
        panel.addView(row)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        row2.addView(chip("WAKE OFF") {
            JarvisBackgroundWake.disable()
            val wakeIntent = Intent(this, JarvisWakeService::class.java).setAction(JarvisWakeService.ACTION_STOP)
            startService(wakeIntent)
            orb?.state = JarvisReactiveOrbView.State.IDLE
            hudOrb.state = JarvisReactiveOrbView.State.IDLE
            state.text = "● WAKE LISTENER OFF"
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 5 })
        row2.addView(chip("MEMORY") { state.text = "● MEMORY READY" }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 5 })
        panel.addView(row2)

        val close = TextView(this).apply {
            text = "CLOSE  •  RETURN TO ORB"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(215, 225, 235))
            setPadding(8, 20, 8, 4)
            setOnClickListener { closeHud() }
        }
        panel.addView(close)

        val params = WindowManager.LayoutParams(
            760,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        panel.alpha = 0f
        panel.scaleX = 0.78f
        panel.scaleY = 0.78f
        windowManager.addView(panel, params)
        hud = panel
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private fun closeHud() {
        val current = hud ?: return
        current.animate()
            .alpha(0f)
            .scaleX(0.78f)
            .scaleY(0.78f)
            .setDuration(180)
            .withEndAction {
                try { windowManager.removeView(current) } catch (_: Exception) {}
                hud = null
                orb?.state = JarvisReactiveOrbView.State.IDLE
            }
            .start()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("jarvis_orb", "JARVIS Floating Orb", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "jarvis_orb")
                .setContentTitle("JARVIS")
                .setContentText("Floating Orb active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("JARVIS")
                .setContentText("Floating Orb active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .build()
        }

    override fun onDestroy() {
        hud?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        orb?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        hud = null
        orb = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
