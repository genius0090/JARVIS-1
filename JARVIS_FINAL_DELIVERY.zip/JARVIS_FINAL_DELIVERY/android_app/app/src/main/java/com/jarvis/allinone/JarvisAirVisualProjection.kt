package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisAirVisualProjection {

    private const val PREFS = "jarvis_air_visual_projection"
    private const val OBJECTS = "objects"
    private const val SETTINGS = "settings"

    data class VisualObject(
        val id: String,
        val name: String,
        val x: Float,
        val y: Float,
        val z: Float,
        val scale: Float,
        val rotation: Float,
        val visible: Boolean
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun objects(context: Context): JSONArray =
        JSONArray(prefs(context).getString(OBJECTS, "[]") ?: "[]")

    private fun saveObjects(context: Context, data: JSONArray) {
        prefs(context).edit()
            .putString(OBJECTS, data.toString())
            .apply()
    }

    private fun settings(context: Context): JSONObject =
        JSONObject(
            prefs(context).getString(SETTINGS, "{}") ?: "{}"
        )

    private fun saveSettings(context: Context, data: JSONObject) {
        prefs(context).edit()
            .putString(SETTINGS, data.toString())
            .apply()
    }

    fun addObject(
        context: Context,
        name: String
    ): String {
        val id = "air_${System.currentTimeMillis()}"

        val item = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("x", 0f)
            .put("y", 0f)
            .put("z", 0f)
            .put("scale", 1f)
            .put("rotation", 0f)
            .put("visible", true)

        val data = objects(context)
        data.put(item)
        saveObjects(context, data)

        return id
    }

    fun removeObject(context: Context, id: String) {
        val old = objects(context)
        val updated = JSONArray()

        for (i in 0 until old.length()) {
            val item = old.getJSONObject(i)
            if (item.optString("id") != id) {
                updated.put(item)
            }
        }

        saveObjects(context, updated)
    }

    private fun update(
        context: Context,
        id: String,
        transform: (JSONObject) -> Unit
    ) {
        val data = objects(context)

        for (i in 0 until data.length()) {
            val item = data.getJSONObject(i)

            if (item.optString("id") == id) {
                transform(item)
                break
            }
        }

        saveObjects(context, data)
    }

    fun move(
        context: Context,
        id: String,
        x: Float,
        y: Float,
        z: Float
    ) = update(context, id) {
        it.put("x", x)
        it.put("y", y)
        it.put("z", z)
    }

    fun rotate(
        context: Context,
        id: String,
        degrees: Float
    ) = update(context, id) {
        it.put("rotation", degrees)
    }

    fun zoom(
        context: Context,
        id: String,
        scale: Float
    ) = update(context, id) {
        it.put("scale", scale.coerceAtLeast(0.1f))
    }

    fun setVisible(
        context: Context,
        id: String,
        visible: Boolean
    ) = update(context, id) {
        it.put("visible", visible)
    }

    fun setExplodedView(
        context: Context,
        id: String,
        enabled: Boolean
    ) = update(context, id) {
        it.put("exploded", enabled)
    }

    fun setLabels(
        context: Context,
        enabled: Boolean
    ) {
        val data = settings(context)
            .put("labels", enabled)
        saveSettings(context, data)
    }

    fun setBrightness(
        context: Context,
        brightness: Float
    ) {
        val data = settings(context)
            .put("brightness", brightness.coerceIn(0f, 1f))
        saveSettings(context, data)
    }

    fun setDisplayMode(
        context: Context,
        mode: String
    ) {
        val data = settings(context)
            .put("displayMode", mode)
        saveSettings(context, data)
    }

    fun transferToDisplay(
        context: Context,
        id: String
    ) {
        val data = settings(context)
            .put("transferredObject", id)
            .put("transferDirection", "AIR_TO_DISPLAY")
        saveSettings(context, data)
    }

    fun transferToAir(
        context: Context,
        id: String
    ) {
        val data = settings(context)
            .put("transferredObject", id)
            .put("transferDirection", "DISPLAY_TO_AIR")
        saveSettings(context, data)
    }

    fun autoHide(
        context: Context,
        enabled: Boolean
    ) {
        val data = settings(context)
            .put("autoHide", enabled)
        saveSettings(context, data)
    }

    fun rememberSize(
        context: Context,
        size: Float
    ) {
        val data = settings(context)
            .put("rememberedSize", size)
        saveSettings(context, data)
    }

    fun showObject(
        context: Context,
        id: String
    ) = setVisible(context, id, true)

    fun hideObject(
        context: Context,
        id: String
    ) = setVisible(context, id, false)

    fun clear(context: Context) {
        prefs(context).edit()
            .remove(OBJECTS)
            .remove(SETTINGS)
            .apply()
    }

    fun status(context: Context): String =
        JSONObject()
            .put("projectionMode", "software_ready")
            .put("hardwareRequiredForPhysicalProjection", true)
            .put("objects", objects(context))
            .put("settings", settings(context))
            .toString()
}
