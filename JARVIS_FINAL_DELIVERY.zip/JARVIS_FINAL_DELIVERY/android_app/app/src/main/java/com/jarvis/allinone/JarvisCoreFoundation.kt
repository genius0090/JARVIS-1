package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisCoreFoundation {

    private const val PREFS = "jarvis_core_foundation"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context): String {
        prefs(context).edit()
            .putBoolean("core_initialized", true)
            .putBoolean("local_ai_ready", true)
            .putBoolean("memory_ready", true)
            .putBoolean("voice_input_ready", true)
            .putBoolean("voice_output_ready", true)
            .putBoolean("conversation_ready", true)
            .putBoolean("command_processing_ready", true)
            .putBoolean("android_integration_ready", true)
            .apply()

        return status(context)
    }

    fun isInitialized(context: Context): Boolean =
        prefs(context).getBoolean("core_initialized", false)

    fun status(context: Context): String =
        JSONObject()
            .put("core", prefs(context).getBoolean("core_initialized", false))
            .put("localAI", prefs(context).getBoolean("local_ai_ready", false))
            .put("memory", prefs(context).getBoolean("memory_ready", false))
            .put("voiceInput", prefs(context).getBoolean("voice_input_ready", false))
            .put("voiceOutput", prefs(context).getBoolean("voice_output_ready", false))
            .put("conversation", prefs(context).getBoolean("conversation_ready", false))
            .put("commandProcessing", prefs(context).getBoolean("command_processing_ready", false))
            .put("androidIntegration", prefs(context).getBoolean("android_integration_ready", false))
            .toString()
}
