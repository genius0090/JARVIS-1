package com.jarvis.allinone

import android.content.Context

object JarvisEmergencyStop {

    @Volatile
    private var stopped = false

    fun trigger(context: Context) {
        stopped = true

        try { JarvisVoiceProfile.shutdown() } catch (_: Exception) {}
        try { JarvisSpeechInput.stop() } catch (_: Exception) {}
        try { JarvisBackgroundWake.disable() } catch (_: Exception) {}
        try { JarvisTaskRecovery.requestCancel(context) } catch (_: Exception) {}
        try { context.stopService(android.content.Intent(context, JarvisWakeService::class.java)) } catch (_: Exception) {}

        val prefs = context.getSharedPreferences(
            "jarvis_emergency",
            Context.MODE_PRIVATE
        )

        prefs.edit()
            .putBoolean("emergency_stopped", true)
            .apply()
    }

    fun reset(context: Context) {
        stopped = false
        try { JarvisTaskRecovery.clearCancellation(context) } catch (_: Exception) {}

        context.getSharedPreferences(
            "jarvis_emergency",
            Context.MODE_PRIVATE
        )
            .edit()
            .putBoolean("emergency_stopped", false)
            .apply()
    }

    fun isStopped(context: Context): Boolean {
        return stopped ||
            context.getSharedPreferences(
                "jarvis_emergency",
                Context.MODE_PRIVATE
            )
                .getBoolean("emergency_stopped", false)
    }

    fun check(context: Context): Boolean {
        return !isStopped(context)
    }

    fun status(context: Context): String {
        return if (isStopped(context))
            "JARVIS EMERGENCY STOP ACTIVE"
        else
            "JARVIS SYSTEM READY"
    }
}
