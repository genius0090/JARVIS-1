package com.jarvis.allinone

import android.content.Context

/**
 * Owner verification state. Verification is explicitly scoped to an app session
 * and can optionally expire; it is never a hard-coded permanent true value.
 */
object JarvisOwnerVerification {
    private const val PREFS = "jarvis_owner_verification"
    private const val KEY_VERIFIED_UNTIL = "verified_until"
    private const val SESSION_MS = 10 * 60 * 1000L

    fun verify(context: Context, durationMs: Long = SESSION_MS) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_VERIFIED_UNTIL, System.currentTimeMillis() + durationMs.coerceAtLeast(1_000L))
            .apply()
    }

    fun revoke(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_VERIFIED_UNTIL)
            .apply()
    }

    fun isVerified(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_VERIFIED_UNTIL, 0L) > System.currentTimeMillis()

    fun requireOwner(context: Context): Boolean = isVerified(context)

    fun status(context: Context): String {
        val until = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_VERIFIED_UNTIL, 0L)
        return if (until > System.currentTimeMillis()) "VERIFIED_UNTIL=$until" else "NOT_VERIFIED"
    }
}
