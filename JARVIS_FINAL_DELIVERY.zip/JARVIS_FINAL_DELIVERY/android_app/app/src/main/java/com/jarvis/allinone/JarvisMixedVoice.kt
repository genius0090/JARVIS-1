package com.jarvis.allinone

object JarvisMixedVoice {
    enum class Language { AUTO,HINDI,ENGLISH,MIXED }

    private var language=Language.AUTO

    fun setLanguage(value:Language){language=value}
    fun getLanguage()=language

    fun detect(text:String):Language {
        val hasHindi=text.any{it in 'ऀ'..'ॿ'}
        val hasLatin=text.any{it in 'A'..'Z' || it in 'a'..'z'}
        return when {
            hasHindi && hasLatin -> Language.MIXED
            hasHindi -> Language.HINDI
            hasLatin -> Language.ENGLISH
            else -> Language.AUTO
        }
    }
}
