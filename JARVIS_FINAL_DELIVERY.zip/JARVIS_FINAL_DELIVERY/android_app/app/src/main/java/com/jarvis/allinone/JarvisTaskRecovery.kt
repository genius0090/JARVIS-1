package com.jarvis.allinone

import android.content.Context

object JarvisTaskRecovery {

    @Volatile
    private var cancellationRequested = false

    @Volatile
    private var recoveryInProgress = false

    fun requestCancel(context: Context) {
        cancellationRequested = true

        context.getSharedPreferences(
            "jarvis_task_recovery",
            Context.MODE_PRIVATE
        )
            .edit()
            .putBoolean("cancellation_requested", true)
            .apply()
    }

    fun clearCancellation(context: Context) {
        cancellationRequested = false

        context.getSharedPreferences(
            "jarvis_task_recovery",
            Context.MODE_PRIVATE
        )
            .edit()
            .putBoolean("cancellation_requested", false)
            .apply()
    }

    fun isCancellationRequested(context: Context): Boolean {
        return cancellationRequested ||
            context.getSharedPreferences(
                "jarvis_task_recovery",
                Context.MODE_PRIVATE
            )
                .getBoolean("cancellation_requested", false)
    }

    fun beginRecovery(context: Context) {
        recoveryInProgress = true

        context.getSharedPreferences(
            "jarvis_task_recovery",
            Context.MODE_PRIVATE
        )
            .edit()
            .putBoolean("recovery_in_progress", true)
            .apply()
    }

    fun finishRecovery(context: Context) {
        recoveryInProgress = false
        cancellationRequested = false

        context.getSharedPreferences(
            "jarvis_task_recovery",
            Context.MODE_PRIVATE
        )
            .edit()
            .putBoolean("recovery_in_progress", false)
            .putBoolean("cancellation_requested", false)
            .apply()
    }

    fun isRecoveryInProgress(context: Context): Boolean {
        return recoveryInProgress ||
            context.getSharedPreferences(
                "jarvis_task_recovery",
                Context.MODE_PRIVATE
            )
                .getBoolean("recovery_in_progress", false)
    }

    fun shouldStop(context: Context): Boolean {
        return JarvisEmergencyStop.isStopped(context) ||
            isCancellationRequested(context)
    }

    fun status(context: Context): String {
        return when {
            JarvisEmergencyStop.isStopped(context) ->
                "EMERGENCY STOP ACTIVE"
            isRecoveryInProgress(context) ->
                "RECOVERY IN PROGRESS"
            isCancellationRequested(context) ->
                "TASK CANCELLATION REQUESTED"
            else ->
                "TASKS READY"
        }
    }
}
