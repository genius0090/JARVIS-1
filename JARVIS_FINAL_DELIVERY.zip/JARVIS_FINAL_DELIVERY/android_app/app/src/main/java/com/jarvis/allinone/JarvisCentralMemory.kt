package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * #204 CENTRALIZED JARVIS MEMORY
 *
 * Persistent memory boundary for device-independent JARVIS state.
 *
 * Stores:
 * - conversations
 * - long-term memories
 * - preferences
 * - settings
 * - state/configuration metadata
 * - device/permission state metadata
 *
 * This is the local persistent foundation.
 * Central synchronization is intentionally handled by later
 * #205/#207/#218/#224/#225 stages.
 *
 * No passwords, biometric templates or authentication secrets
 * are stored here.
 */
object JarvisCentralMemory {

    private const val PREFS = "jarvis_central_memory"

    private const val KEY_MEMORY_ID = "memory_id"
    private const val KEY_CREATED = "created"
    private const val KEY_UPDATED = "updated"

    private const val KEY_MEMORIES = "memories"
    private const val KEY_CONVERSATIONS = "conversations"
    private const val KEY_PREFERENCES = "preferences"
    private const val KEY_SETTINGS = "settings"
    private const val KEY_STATE = "state"
    private const val KEY_DEVICE_STATE = "device_state"

    data class Memory(
        val id: String,
        val key: String,
        val value: String,
        val timestamp: Long
    ) {
        fun toJson(): JSONObject =
            JSONObject()
                .put("id", id)
                .put("key", key)
                .put("value", value)
                .put("timestamp", timestamp)
    }

    data class Conversation(
        val id: String,
        val role: String,
        val content: String,
        val timestamp: Long
    ) {
        fun toJson(): JSONObject =
            JSONObject()
                .put("id", id)
                .put("role", role)
                .put("content", content)
                .put("timestamp", timestamp)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun initialize(context: Context) {
        val p = prefs(context)

        if (!p.contains(KEY_MEMORY_ID)) {
            val now = System.currentTimeMillis()

            p.edit()
                .putString(
                    KEY_MEMORY_ID,
                    "MEMORY-" + UUID.randomUUID().toString()
                )
                .putLong(KEY_CREATED, now)
                .putLong(KEY_UPDATED, now)
                .putString(KEY_MEMORIES, JSONArray().toString())
                .putString(KEY_CONVERSATIONS, JSONArray().toString())
                .putString(KEY_PREFERENCES, JSONObject().toString())
                .putString(KEY_SETTINGS, JSONObject().toString())
                .putString(KEY_STATE, JSONObject().toString())
                .putString(KEY_DEVICE_STATE, JSONObject().toString())
                .apply()

            JarvisAuditTrail.record(
                "CENTRAL_MEMORY_INITIALIZED",
                "SUCCESS"
            )
        }
    }

    fun memoryId(context: Context): String {
        initialize(context)

        return prefs(context)
            .getString(KEY_MEMORY_ID, "") ?: ""
    }

    @Synchronized
    fun remember(
        context: Context,
        key: String,
        value: String
    ): String? {
        initialize(context)

        val cleanKey = key.trim()
        val cleanValue = value.trim()

        if (
            cleanKey.isBlank() ||
            cleanValue.isBlank() ||
            cleanKey.length > 200 ||
            cleanValue.length > 10000
        ) {
            return null
        }

        val id = "MEM-" + UUID.randomUUID().toString()

        val array = memoriesJson(context)

        array.put(
            Memory(
                id = id,
                key = cleanKey,
                value = cleanValue,
                timestamp = System.currentTimeMillis()
            ).toJson()
        )

        saveArray(context, KEY_MEMORIES, array)

        touch(context)

        return id
    }

    fun recall(
        context: Context,
        query: String
    ): List<Memory> {
        initialize(context)

        val q = query.trim().lowercase()

        if (q.isBlank()) return emptyList()

        val array = memoriesJson(context)

        return buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)

                val key = item.optString("key")
                val value = item.optString("value")

                if (
                    key.lowercase().contains(q) ||
                    value.lowercase().contains(q)
                ) {
                    add(
                        Memory(
                            id = item.optString("id"),
                            key = key,
                            value = value,
                            timestamp =
                                item.optLong("timestamp", 0L)
                        )
                    )
                }
            }
        }
    }

    fun allMemories(context: Context): List<Memory> {
        initialize(context)

        val array = memoriesJson(context)

        return buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)

                add(
                    Memory(
                        id = item.optString("id"),
                        key = item.optString("key"),
                        value = item.optString("value"),
                        timestamp =
                            item.optLong("timestamp", 0L)
                    )
                )
            }
        }
    }

    @Synchronized
    fun forget(
        context: Context,
        memoryId: String
    ): Boolean {
        val array = memoriesJson(context)
        val output = JSONArray()
        var removed = false

        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)

            if (item.optString("id") == memoryId) {
                removed = true
            } else {
                output.put(item)
            }
        }

        if (!removed) return false

        saveArray(context, KEY_MEMORIES, output)
        touch(context)

        JarvisAuditTrail.record(
            "MEMORY_FORGOTTEN",
            "SUCCESS"
        )

        return true
    }

    @Synchronized
    fun addConversation(
        context: Context,
        role: String,
        content: String
    ): String? {
        initialize(context)

        val cleanRole = role.trim()
        val cleanContent = content.trim()

        if (
            cleanRole.isBlank() ||
            cleanContent.isBlank() ||
            cleanRole.length > 50 ||
            cleanContent.length > 50000
        ) {
            return null
        }

        val id = "CONV-" + UUID.randomUUID().toString()

        val array = conversationsJson(context)

        array.put(
            Conversation(
                id = id,
                role = cleanRole,
                content = cleanContent,
                timestamp = System.currentTimeMillis()
            ).toJson()
        )

        saveArray(context, KEY_CONVERSATIONS, array)
        touch(context)

        return id
    }

    fun conversations(context: Context): List<Conversation> {
        initialize(context)

        val array = conversationsJson(context)

        return buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)

                add(
                    Conversation(
                        id = item.optString("id"),
                        role = item.optString("role"),
                        content = item.optString("content"),
                        timestamp =
                            item.optLong("timestamp", 0L)
                    )
                )
            }
        }
    }

    @Synchronized
    fun setPreference(
        context: Context,
        key: String,
        value: String
    ): Boolean =
        setObjectValue(
            context,
            KEY_PREFERENCES,
            key,
            value
        )

    fun getPreference(
        context: Context,
        key: String
    ): String? =
        getObjectValue(
            context,
            KEY_PREFERENCES,
            key
        )

    @Synchronized
    fun setSetting(
        context: Context,
        key: String,
        value: String
    ): Boolean =
        setObjectValue(
            context,
            KEY_SETTINGS,
            key,
            value
        )

    fun getSetting(
        context: Context,
        key: String
    ): String? =
        getObjectValue(
            context,
            KEY_SETTINGS,
            key
        )

    @Synchronized
    fun setState(
        context: Context,
        key: String,
        value: String
    ): Boolean =
        setObjectValue(
            context,
            KEY_STATE,
            key,
            value
        )

    fun getState(
        context: Context,
        key: String
    ): String? =
        getObjectValue(
            context,
            KEY_STATE,
            key
        )

    @Synchronized
    fun setDeviceState(
        context: Context,
        key: String,
        value: String
    ): Boolean =
        setObjectValue(
            context,
            KEY_DEVICE_STATE,
            key,
            value
        )

    fun getDeviceState(
        context: Context,
        key: String
    ): String? =
        getObjectValue(
            context,
            KEY_DEVICE_STATE,
            key
        )

    fun exportMetadata(context: Context): String {
        initialize(context)

        val p = prefs(context)

        return JSONObject()
            .put(
                "memoryId",
                p.getString(KEY_MEMORY_ID, "")
            )
            .put(
                "created",
                p.getLong(KEY_CREATED, 0L)
            )
            .put(
                "updated",
                p.getLong(KEY_UPDATED, 0L)
            )
            .put(
                "memoryCount",
                memoriesJson(context).length()
            )
            .put(
                "conversationCount",
                conversationsJson(context).length()
            )
            .toString()
    }

    fun statusJson(context: Context): String {
        initialize(context)

        return JSONObject()
            .put("memoryId", memoryId(context))
            .put("memories", allMemories(context).size)
            .put("conversations", conversations(context).size)
            .put(
                "persistentPreferences",
                true
            )
            .put(
                "persistentSettings",
                true
            )
            .put(
                "persistentState",
                true
            )
            .put(
                "deviceState",
                true
            )
            .put(
                "centralSync",
                "LATER_STAGE"
            )
            .toString()
    }

    fun healthCheck(context: Context): Boolean {
        initialize(context)

        val p = prefs(context)

        return !memoryId(context).isBlank() &&
                p.contains(KEY_MEMORIES) &&
                p.contains(KEY_CONVERSATIONS) &&
                p.contains(KEY_PREFERENCES) &&
                p.contains(KEY_SETTINGS) &&
                p.contains(KEY_STATE) &&
                p.contains(KEY_DEVICE_STATE)
    }

    private fun memoriesJson(context: Context): JSONArray =
        runCatching {
            JSONArray(
                prefs(context)
                    .getString(KEY_MEMORIES, "[]") ?: "[]"
            )
        }.getOrDefault(JSONArray())

    private fun conversationsJson(context: Context): JSONArray =
        runCatching {
            JSONArray(
                prefs(context)
                    .getString(KEY_CONVERSATIONS, "[]") ?: "[]"
            )
        }.getOrDefault(JSONArray())

    private fun saveArray(
        context: Context,
        key: String,
        value: JSONArray
    ) {
        prefs(context)
            .edit()
            .putString(key, value.toString())
            .apply()
    }

    private fun setObjectValue(
        context: Context,
        objectKey: String,
        key: String,
        value: String
    ): Boolean {
        initialize(context)

        val cleanKey = key.trim()
        val cleanValue = value.trim()

        if (
            cleanKey.isBlank() ||
            cleanKey.length > 200 ||
            cleanValue.length > 10000
        ) {
            return false
        }

        val obj = runCatching {
            JSONObject(
                prefs(context)
                    .getString(objectKey, "{}") ?: "{}"
            )
        }.getOrDefault(JSONObject())

        obj.put(cleanKey, cleanValue)

        prefs(context)
            .edit()
            .putString(objectKey, obj.toString())
            .apply()

        touch(context)

        return true
    }

    private fun getObjectValue(
        context: Context,
        objectKey: String,
        key: String
    ): String? {
        initialize(context)

        val obj = runCatching {
            JSONObject(
                prefs(context)
                    .getString(objectKey, "{}") ?: "{}"
            )
        }.getOrDefault(JSONObject())

        return if (obj.has(key)) {
            obj.optString(key)
        } else {
            null
        }
    }

    private fun touch(context: Context) {
        prefs(context)
            .edit()
            .putLong(
                KEY_UPDATED,
                System.currentTimeMillis()
            )
            .apply()
    }
}
