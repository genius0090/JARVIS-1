package com.jarvis.allinone

import android.content.Context

object JarvisCreatorToolsUI {
    fun writing(context: Context) = state("writing", "Writing Tools", "READY", "Structured writing and document creation", true)
    fun thumbnail(context: Context) = state("thumbnail", "Thumbnail Tools", "READY", "Creator planning and visual asset workflow", true)
    fun audio(context: Context) = state("audio", "Audio Tools", "READY", "Audio understanding and creator workflow", true)
    fun video(context: Context) = state("video", "Video Creator Tools", "READY", "Movie/video planning and media workflow", true)
    fun export(context: Context) = state("creator_export", "Creator Export", "READY", "Export generated creator artifacts", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
