package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject
import java.util.UUID

/**
 * #198 PERMANENT JARVIS CORE
 *
 * Device-independent architecture boundary.
 * The Android app is a client of this core layer.
 *
 * Current implementation:
 * - persistent local core identity/state
 * - online/offline/reconnecting state
 * - safe local fallback
 * - session continuity
 * - health reporting
 * - recovery initialization
 *
 * A future remote backend can attach behind this boundary without
 * replacing the Android-facing API.
 */
object JarvisPermanentCore {

    private const val PREFS = "jarvis_permanent_core"
    private const val KEY_CORE_ID = "core_id"
    private const val KEY_STATE = "state"
    private const val KEY_INITIALIZED = "initialized"
    private const val KEY_LAST_HEALTH = "last_health"
    private const val KEY_LAST_SYNC = "last_sync"
    private const val KEY_BOOT_COUNT = "boot_count"

    enum class State {
        OFFLINE,
        ONLINE,
        RECONNECTING,
        RECOVERING,
        DEGRADED
    }

    data class Status(
        val coreId: String,
        val state: State,
        val initialized: Boolean,
        val localFallback: Boolean,
        val bootCount: Long,
        val lastHealth: Long,
        val lastSync: Long
    ) {
        fun toJson(): String =
            JSONObject()
                .put("coreId", coreId)
                .put("state", state.name)
                .put("initialized", initialized)
                .put("localFallback", localFallback)
                .put("bootCount", bootCount)
                .put("lastHealth", lastHealth)
                .put("lastSync", lastSync)
                .toString()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun initialize(context: Context): Status {
        val p = prefs(context)

        var coreId = p.getString(KEY_CORE_ID, null)

        if (coreId.isNullOrBlank()) {
            coreId = "JARVIS-" + UUID.randomUUID().toString()
        }

        val bootCount = p.getLong(KEY_BOOT_COUNT, 0L) + 1L
        val now = System.currentTimeMillis()

        p.edit()
            .putString(KEY_CORE_ID, coreId)
            .putString(KEY_STATE, State.OFFLINE.name)
            .putBoolean(KEY_INITIALIZED, true)
            .putLong(KEY_LAST_HEALTH, now)
            .putLong(KEY_BOOT_COUNT, bootCount)
            .apply()

        initializeExistingFoundations(context)
        JarvisAuditTrail.record("CORE_INITIALIZE", "SUCCESS")

        return status(context)
    }

    private fun initializeExistingFoundations(context: Context) {
        runCatching { JarvisCoreFoundation.initialize(context) }
        runCatching { JarvisCoreServicesFoundation.initialize(context) }
        runCatching { JarvisFoundationControl.initialize(context) }
        runCatching { JarvisAndroidFoundation.initialize(context) }
    }

    fun coreId(context: Context): String =
        prefs(context).getString(KEY_CORE_ID, "") ?: ""

    fun isInitialized(context: Context): Boolean =
        prefs(context).getBoolean(KEY_INITIALIZED, false)

    @Synchronized
    fun setOnline(context: Context) {
        setState(context, State.ONLINE)
    }

    @Synchronized
    fun setOffline(context: Context) {
        setState(context, State.OFFLINE)
    }

    @Synchronized
    fun setReconnecting(context: Context) {
        setState(context, State.RECONNECTING)
    }

    @Synchronized
    fun setRecovering(context: Context) {
        setState(context, State.RECOVERING)
    }

    @Synchronized
    fun setDegraded(context: Context) {
        setState(context, State.DEGRADED)
    }

    @Synchronized
    private fun setState(context: Context, state: State) {
        prefs(context)
            .edit()
            .putString(KEY_STATE, state.name)
            .putLong(KEY_LAST_HEALTH, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record("CORE_STATE", state.name)
    }

    fun markSync(context: Context) {
        prefs(context)
            .edit()
            .putLong(KEY_LAST_SYNC, System.currentTimeMillis())
            .putLong(KEY_LAST_HEALTH, System.currentTimeMillis())
            .apply()
    }

    fun useLocalFallback(context: Context): Boolean {
        val state = currentState(context)
        return state != State.ONLINE
    }

    fun currentState(context: Context): State {
        val value = prefs(context).getString(KEY_STATE, State.OFFLINE.name)
            ?: State.OFFLINE.name

        return runCatching { State.valueOf(value) }
            .getOrDefault(State.OFFLINE)
    }

    fun healthCheck(context: Context): Boolean {
        val p = prefs(context)

        val initialized = p.getBoolean(KEY_INITIALIZED, false)
        val idValid = !p.getString(KEY_CORE_ID, null).isNullOrBlank()

        if (initialized && idValid) {
            p.edit()
                .putLong(KEY_LAST_HEALTH, System.currentTimeMillis())
                .apply()
            return true
        }

        return false
    }

    @Synchronized
    fun recover(context: Context): Status {
        val p = prefs(context)

        p.edit()
            .putString(KEY_STATE, State.RECOVERING.name)
            .putLong(KEY_LAST_HEALTH, System.currentTimeMillis())
            .apply()

        initializeExistingFoundations(context)

        val id = p.getString(KEY_CORE_ID, null)
        if (id.isNullOrBlank()) {
            p.edit()
                .putString(KEY_CORE_ID, "JARVIS-" + UUID.randomUUID().toString())
                .apply()
        }

        p.edit()
            .putBoolean(KEY_INITIALIZED, true)
            .putString(KEY_STATE, State.OFFLINE.name)
            .putLong(KEY_LAST_HEALTH, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record("CORE_RECOVERY", "SUCCESS")

        return status(context)
    }

    fun status(context: Context): Status {
        val p = prefs(context)

        return Status(
            coreId = p.getString(KEY_CORE_ID, "") ?: "",
            state = currentState(context),
            initialized = p.getBoolean(KEY_INITIALIZED, false),
            localFallback = useLocalFallback(context),
            bootCount = p.getLong(KEY_BOOT_COUNT, 0L),
            lastHealth = p.getLong(KEY_LAST_HEALTH, 0L),
            lastSync = p.getLong(KEY_LAST_SYNC, 0L)
        )
    }

    fun statusJson(context: Context): String =
        status(context).toJson()
}
