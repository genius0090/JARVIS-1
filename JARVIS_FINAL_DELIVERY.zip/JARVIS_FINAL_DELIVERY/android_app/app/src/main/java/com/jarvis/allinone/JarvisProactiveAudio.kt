package com.jarvis.allinone

object JarvisProactiveAudio {
    private var enabled=false
    private var lastEvent:String?=null

    fun enable(){enabled=true}
    fun disable(){enabled=false}
    fun isEnabled()=enabled

    fun notify(event:String):String?{
        if(!enabled)return null
        lastEvent=event
        return event
    }

    fun lastEvent()=lastEvent
}
