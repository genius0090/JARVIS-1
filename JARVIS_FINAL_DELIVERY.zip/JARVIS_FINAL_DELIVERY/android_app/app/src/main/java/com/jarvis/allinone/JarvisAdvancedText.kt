package com.jarvis.allinone

object JarvisAdvancedText {
    fun normalize(text:String)=text.trim().replace("\\s+".toRegex()," ")
    fun summarize(text:String,maxLength:Int=500)=
        normalize(text).let{if(it.length<=maxLength) it else it.take(maxLength)+"..."}
    fun keywords(text:String)=
        normalize(text).lowercase().split(" ").filter{it.length>3}.distinct()
}
