package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisKnowledgeEvolution {

    private const val PREFS = "jarvis_knowledge_evolution"
    private const val IMPORTS = "knowledge_imports"
    private const val EXPIRY = "knowledge_expiry"
    private const val INTERRUPTS = "interruptions"
    private const val HANDOFFS = "task_handoffs"
    private const val CONFLICTS = "knowledge_conflicts"
    private const val IMPROVEMENTS = "improvements"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun append(context: Context, key: String, value: String) {
        val old = prefs(context).getString(key, "[]") ?: "[]"
        val array = JSONArray(old)
        array.put(value)
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun importKnowledge(
        context: Context,
        source: String,
        content: String
    ): String {
        val item = JSONObject()
            .put("source", source)
            .put("content", content)
            .put("timestamp", System.currentTimeMillis())

        append(context, IMPORTS, item.toString())
        return item.toString()
    }

    fun setKnowledgeExpiry(
        context: Context,
        topic: String,
        expiresAt: Long
    ): String {
        val item = JSONObject()
            .put("topic", topic)
            .put("expiresAt", expiresAt)
            .put("createdAt", System.currentTimeMillis())

        append(context, EXPIRY, item.toString())
        return item.toString()
    }

    fun isExpired(expiresAt: Long): Boolean =
        expiresAt > 0L && System.currentTimeMillis() >= expiresAt

    fun recordInterruption(
        context: Context,
        currentTask: String,
        interruption: String
    ): String {
        val item = JSONObject()
            .put("currentTask", currentTask)
            .put("interruption", interruption)
            .put("timestamp", System.currentTimeMillis())

        append(context, INTERRUPTS, item.toString())
        return item.toString()
    }

    fun createTaskHandoff(
        context: Context,
        task: String,
        state: String,
        nextAction: String
    ): String {
        val item = JSONObject()
            .put("task", task)
            .put("state", state)
            .put("nextAction", nextAction)
            .put("timestamp", System.currentTimeMillis())

        append(context, HANDOFFS, item.toString())
        return item.toString()
    }

    fun recordKnowledgeConflict(
        context: Context,
        topic: String,
        first: String,
        second: String
    ): String {
        val item = JSONObject()
            .put("topic", topic)
            .put("first", first)
            .put("second", second)
            .put("timestamp", System.currentTimeMillis())

        append(context, CONFLICTS, item.toString())
        return item.toString()
    }

    fun suggestImprovement(
        context: Context,
        area: String,
        suggestion: String,
        reason: String
    ): String {
        val item = JSONObject()
            .put("area", area)
            .put("suggestion", suggestion)
            .put("reason", reason)
            .put("timestamp", System.currentTimeMillis())
            .put("status", "suggested")

        append(context, IMPROVEMENTS, item.toString())
        return item.toString()
    }

    fun status(context: Context): String {
        return JSONObject()
            .put("knowledgeImports",
                JSONArray(prefs(context).getString(IMPORTS, "[]")))
            .put("knowledgeExpiry",
                JSONArray(prefs(context).getString(EXPIRY, "[]")))
            .put("interruptions",
                JSONArray(prefs(context).getString(INTERRUPTS, "[]")))
            .put("taskHandoffs",
                JSONArray(prefs(context).getString(HANDOFFS, "[]")))
            .put("knowledgeConflicts",
                JSONArray(prefs(context).getString(CONFLICTS, "[]")))
            .put("improvements",
                JSONArray(prefs(context).getString(IMPROVEMENTS, "[]")))
            .toString()
    }
}
