package com.jarvis.allinone

object JarvisBackgroundWake {
    private val triggers=setOf("hey jarvis","jarvis","wake","jarvis utho","jarvis suno")
    @Volatile private var enabled=false

    fun enable(){enabled=true}
    fun disable(){enabled=false}
    fun isEnabled()=enabled

    fun matches(text:String):Boolean {
        if(!enabled) return false
        val t=text.trim().lowercase()
        return triggers.any{t==it || t.startsWith("$it ")}
    }

    fun status()="Background wake: ${if(enabled)"enabled" else "disabled"}"
}
