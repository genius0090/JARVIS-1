package com.jarvis.allinone

import android.content.Context

object JarvisUnifiedDecisionEngine {

    enum class Decision {
        EXECUTE, CONFIRM, BLOCK
    }

    data class Result(
        val decision: Decision,
        val route: JarvisUnifiedActionRouter.Route,
        val reason: String
    )

    fun decide(
        context: Context,
        intent: String,
        sensitive: Boolean = false,
        highImpact: Boolean = false,
        approved: Boolean = false
    ): Result {

        if (JarvisEmergencyStop.isStopped(context)) {
            return Result(
                Decision.BLOCK,
                JarvisUnifiedActionRouter.Route.SECURITY,
                "Emergency STOP active"
            )
        }

        if (JarvisTaskRecovery.isCancellationRequested(context)) {
            return Result(
                Decision.BLOCK,
                JarvisUnifiedActionRouter.Route.SECURITY,
                "Task cancellation requested"
            )
        }

        val route = JarvisUnifiedActionRouter.route(
            intent,
            sensitive || highImpact
        )

        val protectedRoute = route.route in setOf(
            JarvisUnifiedActionRouter.Route.PC,
            JarvisUnifiedActionRouter.Route.SYSTEM,
            JarvisUnifiedActionRouter.Route.SECURITY,
            JarvisUnifiedActionRouter.Route.REPAIR,
            JarvisUnifiedActionRouter.Route.TERMINAL,
            JarvisUnifiedActionRouter.Route.DEVICE,
            JarvisUnifiedActionRouter.Route.RECOVERY,
            JarvisUnifiedActionRouter.Route.OSINT,
            JarvisUnifiedActionRouter.Route.AIR_VISUAL
        )

        val requiresAuthorization = sensitive || highImpact || protectedRoute

        val securityRoute = route.route == JarvisUnifiedActionRouter.Route.SECURITY ||
            route.route == JarvisUnifiedActionRouter.Route.OSINT

        if (securityRoute) {
            val analysis = JarvisSecurityAnalysis.analyze(
                context,
                intent,
                requiresAuthorization = !approved
            )
            if (!analysis.allowed) {
                return Result(
                    Decision.BLOCK,
                    JarvisUnifiedActionRouter.Route.SECURITY,
                    analysis.reason
                )
            }
        }

        if (requiresAuthorization && approved && !JarvisOwnerVerification.isVerified(context)) {
            return Result(
                Decision.BLOCK,
                route.route,
                "Fresh owner authentication is required before protected execution"
            )
        }

        val decision = when {
            requiresAuthorization && !approved -> Decision.CONFIRM
            else -> Decision.EXECUTE
        }

        return Result(
            decision,
            route.route,
            route.reason
        )
    }
}
