package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * #202 FLEXIBLE VERIFICATION SELECTION
 *
 * Selects legitimate available owner-verification methods.
 * It never bypasses authentication or Android security.
 */
object JarvisFlexibleVerification {

    enum class Requirement {
        STANDARD,
        STRONG,
        HIGH
    }

    data class Selection(
        val selectedMethodId: String?,
        val alternatives: List<String>,
        val requirement: Requirement,
        val available: Boolean,
        val reason: String
    ) {
        fun toJson(): String =
            JSONObject()
                .put("selectedMethodId", selectedMethodId ?: "")
                .put("alternatives", JSONArray(alternatives))
                .put("requirement", requirement.name)
                .put("available", available)
                .put("reason", reason)
                .toString()
    }

    fun select(
        context: Context,
        requirement: Requirement = Requirement.STANDARD
    ): Selection {
        val methods = JarvisOwnerIdentityMethods
            .availableMethods(context)

        val eligible = methods.filter {
            securityRank(it.securityLevel) >= securityRank(requirement)
        }

        if (eligible.isEmpty()) {
            return Selection(
                selectedMethodId = null,
                alternatives = emptyList(),
                requirement = requirement,
                available = false,
                reason = "NO_ELIGIBLE_VERIFICATION_METHOD"
            )
        }

        val primary = eligible.firstOrNull {
            it.role == JarvisOwnerIdentityMethods.Role.PRIMARY
        } ?: eligible.firstOrNull {
            it.role == JarvisOwnerIdentityMethods.Role.BACKUP
        } ?: eligible.first()

        val alternatives = eligible
            .filter { it.id != primary.id }
            .map { it.id }

        JarvisAuditTrail.record(
            "VERIFICATION_METHOD_SELECTED",
            primary.type.name
        )

        return Selection(
            selectedMethodId = primary.id,
            alternatives = alternatives,
            requirement = requirement,
            available = true,
            reason = "ELIGIBLE_METHOD_AVAILABLE"
        )
    }

    fun choose(
        context: Context,
        methodId: String,
        requirement: Requirement = Requirement.STANDARD
    ): Selection {
        val methods = JarvisOwnerIdentityMethods
            .availableMethods(context)

        val selected = methods.firstOrNull {
            it.id == methodId &&
                    securityRank(it.securityLevel) >= securityRank(requirement)
        }

        if (selected == null) {
            JarvisAuditTrail.record(
                "VERIFICATION_METHOD_REJECTED",
                "NOT_ELIGIBLE"
            )

            return Selection(
                selectedMethodId = null,
                alternatives = methods.map { it.id },
                requirement = requirement,
                available = false,
                reason = "METHOD_NOT_ELIGIBLE"
            )
        }

        val alternatives = methods
            .filter { it.id != selected.id }
            .map { it.id }

        JarvisAuditTrail.record(
            "VERIFICATION_METHOD_CHOSEN",
            selected.type.name
        )

        return Selection(
            selectedMethodId = selected.id,
            alternatives = alternatives,
            requirement = requirement,
            available = true,
            reason = "METHOD_ACCEPTED"
        )
    }

    fun canVerify(
        context: Context,
        requirement: Requirement = Requirement.STANDARD
    ): Boolean =
        select(context, requirement).available

    fun requireStrong(context: Context): Selection =
        select(context, Requirement.STRONG)

    fun requireHigh(context: Context): Selection =
        select(context, Requirement.HIGH)

    fun statusJson(context: Context): String {
        val standard = select(context, Requirement.STANDARD)
        val strong = select(context, Requirement.STRONG)
        val high = select(context, Requirement.HIGH)

        return JSONObject()
            .put("standardAvailable", standard.available)
            .put("strongAvailable", strong.available)
            .put("highAvailable", high.available)
            .put("standard", standard.toJson())
            .put("strong", strong.toJson())
            .put("high", high.toJson())
            .toString()
    }

    private fun securityRank(
        level: JarvisOwnerIdentityMethods.SecurityLevel
    ): Int =
        when (level) {
            JarvisOwnerIdentityMethods.SecurityLevel.STANDARD -> 1
            JarvisOwnerIdentityMethods.SecurityLevel.STRONG -> 2
            JarvisOwnerIdentityMethods.SecurityLevel.HIGH -> 3
        }

    private fun securityRank(requirement: Requirement): Int =
        when (requirement) {
            Requirement.STANDARD -> 1
            Requirement.STRONG -> 2
            Requirement.HIGH -> 3
        }
}
