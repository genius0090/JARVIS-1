package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisFoundationControl {

    private const val PREFS = "jarvis_foundation_control"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context): String {
        prefs(context).edit()
            .putBoolean("universal_permission_ready", true)
            .putBoolean("owner_authority_ready", true)
            .putBoolean("intelligence_ready", true)
            .putBoolean("creator_ready", true)
            .putBoolean("documents_ready", true)
            .putBoolean("spreadsheets_ready", true)
            .putBoolean("presentations_ready", true)
            .putBoolean("tools_skills_ready", true)
            .apply()

        return status(context)
    }

    fun status(context: Context): String =
        JSONObject()
            .put("universalPermission", prefs(context).getBoolean("universal_permission_ready", false))
            .put("ownerAuthority", prefs(context).getBoolean("owner_authority_ready", false))
            .put("intelligence", prefs(context).getBoolean("intelligence_ready", false))
            .put("creator", prefs(context).getBoolean("creator_ready", false))
            .put("documents", prefs(context).getBoolean("documents_ready", false))
            .put("spreadsheets", prefs(context).getBoolean("spreadsheets_ready", false))
            .put("presentations", prefs(context).getBoolean("presentations_ready", false))
            .put("toolsSkills", prefs(context).getBoolean("tools_skills_ready", false))
            .toString()
}
