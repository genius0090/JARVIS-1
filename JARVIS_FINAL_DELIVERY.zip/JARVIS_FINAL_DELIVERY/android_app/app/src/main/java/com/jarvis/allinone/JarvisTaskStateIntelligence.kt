package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisTaskStateIntelligence {

    private const val PREFS = "jarvis_task_state_intelligence"
    private const val DATA = "data"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun read(context: Context): JSONArray =
        JSONArray(prefs(context).getString(DATA, "[]") ?: "[]")

    private fun write(context: Context, array: JSONArray) {
        prefs(context).edit().putString(DATA, array.toString()).apply()
    }

    private fun add(context: Context, type: String, payload: JSONObject): String {
        val item = JSONObject(payload.toString())
            .put("type", type)
            .put("timestamp", System.currentTimeMillis())

        val array = read(context)
        array.put(item)
        write(context, array)
        return item.toString()
    }

    fun screenshotAction(
        context: Context,
        description: String,
        action: String
    ) = add(
        context,
        "screenshot_action",
        JSONObject()
            .put("description", description)
            .put("action", action)
    )

    fun estimateTaskCost(
        context: Context,
        task: String,
        estimatedSeconds: Long,
        estimatedMemoryMb: Int = 0
    ) = add(
        context,
        "task_cost",
        JSONObject()
            .put("task", task)
            .put("estimatedSeconds", estimatedSeconds)
            .put("estimatedMemoryMb", estimatedMemoryMb)
    )

    fun setPermissionExpiry(
        context: Context,
        permission: String,
        expiresAt: Long
    ) = add(
        context,
        "permission_expiry",
        JSONObject()
            .put("permission", permission)
            .put("expiresAt", expiresAt)
    )

    fun rememberAppState(
        context: Context,
        packageName: String,
        state: String
    ) = add(
        context,
        "app_state",
        JSONObject()
            .put("packageName", packageName)
            .put("state", state)
    )

    fun resumeInterruptedTask(
        context: Context,
        task: String,
        state: String,
        nextAction: String
    ) = add(
        context,
        "interrupted_task",
        JSONObject()
            .put("task", task)
            .put("state", state)
            .put("nextAction", nextAction)
    )

    fun environmentInterface(
        context: Context,
        environment: String,
        interfaceMode: String
    ) = add(
        context,
        "environment_interface",
        JSONObject()
            .put("environment", environment)
            .put("interfaceMode", interfaceMode)
    )

    fun simulationPreview(
        context: Context,
        task: String,
        steps: List<String>
    ) = add(
        context,
        "simulation_preview",
        JSONObject()
            .put("task", task)
            .put("steps", JSONArray(steps))
    )

    fun createTemporaryWorkspace(
        context: Context,
        name: String,
        purpose: String
    ) = add(
        context,
        "temporary_workspace",
        JSONObject()
            .put("name", name)
            .put("purpose", purpose)
    )

    fun safeTestMode(
        context: Context,
        enabled: Boolean,
        reason: String = ""
    ) = add(
        context,
        "safe_test_mode",
        JSONObject()
            .put("enabled", enabled)
            .put("reason", reason)
    )

    fun snapshotState(
        context: Context,
        name: String,
        state: String
    ) = add(
        context,
        "state_snapshot",
        JSONObject()
            .put("name", name)
            .put("state", state)
    )

    fun packageContext(
        context: Context,
        task: String,
        contextData: Map<String, String>
    ): String {
        val data = JSONObject()
        contextData.forEach { (key, value) ->
            data.put(key, value)
        }

        return add(
            context,
            "context_package",
            JSONObject()
                .put("task", task)
                .put("data", data)
        )
    }

    fun setAdaptiveLayout(
        context: Context,
        layout: String,
        reason: String
    ) = add(
        context,
        "adaptive_layout",
        JSONObject()
            .put("layout", layout)
            .put("reason", reason)
    )

    fun watchTask(
        context: Context,
        task: String,
        status: String
    ) = add(
        context,
        "task_watcher",
        JSONObject()
            .put("task", task)
            .put("status", status)
    )

    fun setDeadline(
        context: Context,
        task: String,
        deadline: Long
    ) = add(
        context,
        "deadline",
        JSONObject()
            .put("task", task)
            .put("deadline", deadline)
    )

    fun recordRetry(
        context: Context,
        task: String,
        attempt: Int,
        strategy: String
    ) = add(
        context,
        "smart_retry",
        JSONObject()
            .put("task", task)
            .put("attempt", attempt)
            .put("strategy", strategy)
    )

    fun createSandbox(
        context: Context,
        name: String,
        initialState: String
    ) = add(
        context,
        "digital_sandbox",
        JSONObject()
            .put("name", name)
            .put("initialState", initialState)
    )

    fun status(context: Context): String =
        JSONObject()
            .put("items", read(context))
            .put("count", read(context).length())
            .toString()
}
