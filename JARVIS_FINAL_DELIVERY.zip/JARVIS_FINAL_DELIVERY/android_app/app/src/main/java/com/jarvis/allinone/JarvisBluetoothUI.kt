package com.jarvis.allinone

import android.bluetooth.BluetoothAdapter
import android.content.Context

object JarvisBluetoothUI {
    fun status(): Boolean = BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    fun state(context: Context) = JarvisUiState(
        id = "bluetooth",
        title = "Bluetooth",
        status = if (status()) "ON" else "OFF",
        detail = "Android Bluetooth state; changes requiring OS permission/settings remain OS-controlled",
        actionable = false
    )
    fun showStatus(context: Context) = state(context)
}
