package com.jarvis.allinone

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONObject

/**
 * #203 ANDROID OWNER AUTHENTICATION
 *
 * Connects Android platform authentication to the JARVIS
 * owner-authentication layer.
 *
 * Android owns the biometric/device credential verification.
 * JARVIS receives only success/failure.
 *
 * No biometric templates or PIN/password values are stored.
 */
object JarvisAndroidOwnerAuthentication {

    enum class Availability {
        AVAILABLE,
        BIOMETRIC_UNAVAILABLE,
        DEVICE_CREDENTIAL_ONLY,
        NO_SECURE_AUTHENTICATOR
    }

    data class Capability(
        val biometric: Boolean,
        val deviceCredential: Boolean,
        val status: Availability
    ) {
        fun toJson(): String =
            JSONObject()
                .put("biometric", biometric)
                .put("deviceCredential", deviceCredential)
                .put("status", status.name)
                .toString()
    }

    fun capability(context: Context): Capability {
        val manager = BiometricManager.from(context)

        val biometricStatus = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        )

        val credentialStatus = manager.canAuthenticate(
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )

        val biometricAvailable =
            biometricStatus == BiometricManager.BIOMETRIC_SUCCESS

        val credentialAvailable =
            credentialStatus == BiometricManager.BIOMETRIC_SUCCESS

        val status = when {
            biometricAvailable ->
                Availability.AVAILABLE

            credentialAvailable ->
                Availability.DEVICE_CREDENTIAL_ONLY

            else ->
                Availability.NO_SECURE_AUTHENTICATOR
        }

        return Capability(
            biometric = biometricAvailable,
            deviceCredential = credentialAvailable,
            status = status
        )
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String = "JARVIS Owner Verification",
        subtitle: String = "Verify your identity to continue",
        onResult: (Boolean) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)

        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {

                override fun onAuthenticationSucceeded(
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    super.onAuthenticationSucceeded(result)

                    JarvisOwnerAuthentication
                        .authenticationSucceeded(activity)
                    JarvisOwnerVerification.verify(activity)

                    JarvisAuditTrail.record(
                        "ANDROID_OWNER_AUTH",
                        "SUCCESS"
                    )

                    onResult(true)
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()

                    JarvisOwnerAuthentication
                        .authenticationFailed(activity)
                    JarvisOwnerVerification.revoke(activity)

                    JarvisAuditTrail.record(
                        "ANDROID_OWNER_AUTH",
                        "FAILED"
                    )

                    onResult(false)
                }

                override fun onAuthenticationError(
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    super.onAuthenticationError(
                        errorCode,
                        errString
                    )

                    JarvisOwnerVerification.revoke(activity)
                    JarvisAuditTrail.record(
                        "ANDROID_OWNER_AUTH",
                        "ERROR_$errorCode"
                    )

                    onResult(false)
                }
            }
        )

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(info)
    }

    fun statusJson(context: Context): String =
        capability(context).toJson()

    fun healthCheck(context: Context): Boolean {
        val capability = capability(context)

        return capability.biometric ||
                capability.deviceCredential
    }
}
