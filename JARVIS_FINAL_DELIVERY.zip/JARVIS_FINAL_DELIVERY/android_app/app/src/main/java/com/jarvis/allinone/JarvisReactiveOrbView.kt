package com.jarvis.allinone

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/**
 * JARVIS identity orb: golden/orange energy core, layered orbital geometry,
 * particles and state-driven motion. Runtime audio level can be supplied by
 * the voice layer through [audioLevel].
 */
class JarvisReactiveOrbView(context: Context) : View(context) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING, MISSION, ALERT }

    var state: State = State.IDLE
        set(value) {
            field = value
            invalidate()
        }

    var audioLevel: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particles = ArrayList<Particle>()
    private var angle = 0f
    private var pulse = 0f

    data class Particle(
        var phase: Float,
        var speed: Float,
        var size: Float,
        var orbit: Float,
        var vertical: Float
    )

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        repeat(110) {
            particles += Particle(
                phase = Random.nextFloat() * 360f,
                speed = 0.35f + Random.nextFloat() * 1.5f,
                size = 1f + Random.nextFloat() * 2.8f,
                orbit = 55f + Random.nextFloat() * 135f,
                vertical = 0.45f + Random.nextFloat() * 0.45f
            )
        }
    }

    private fun intensity(): Float {
        val stateBoost = when (state) {
            State.IDLE -> 0.72f
            State.LISTENING -> 1.12f
            State.THINKING -> 1.42f
            State.SPEAKING -> 1.22f
            State.MISSION -> 1.65f
            State.ALERT -> 1.9f
        }
        return (stateBoost + audioLevel * 0.8f).coerceAtMost(2.25f)
    }

    private fun palette(): IntArray = when (state) {
        State.ALERT -> intArrayOf(
            Color.WHITE, Color.rgb(255, 150, 100), Color.rgb(230, 45, 35), Color.argb(0, 150, 0, 0)
        )
        State.MISSION -> intArrayOf(
            Color.WHITE, Color.rgb(255, 205, 80), Color.rgb(210, 58, 38), Color.argb(0, 90, 0, 0)
        )
        else -> intArrayOf(
            Color.WHITE, Color.rgb(255, 238, 135), Color.rgb(255, 165, 20), Color.argb(0, 255, 90, 0)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) * 0.18f
        val intensity = intensity()

        pulse += 0.055f * intensity
        angle += when (state) {
            State.IDLE -> 0.42f
            State.LISTENING -> 0.9f
            State.THINKING -> 1.45f
            State.SPEAKING -> 1.05f
            State.MISSION -> 1.75f
            State.ALERT -> 2.15f
        }

        // Atmospheric energy field.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, base * 3.4f,
            palette(),
            floatArrayOf(0f, 0.24f, 0.58f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base * 3.4f, paint)
        paint.shader = null

        // Multiple elliptical energy rings/orbits.
        for (i in 0 until 9) {
            val r = base * (0.72f + i * 0.19f)
            val rect = RectF(cx - r, cy - r * (0.58f + i * 0.018f), cx + r, cy + r * (0.58f + i * 0.018f))
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (i % 3 == 0) 2.2f else 0.85f
            paint.color = when (state) {
                State.ALERT -> Color.argb(105 + i * 10, 255, 80, 55)
                State.MISSION -> Color.argb(135 + i * 10, 255, 105 + (i * 4).coerceAtMost(35), 38)
                else -> Color.argb(115 + i * 12, 255, 170 + (i * 7).coerceAtMost(65), 30)
            }
            paint.setShadowLayer(10f + intensity * 4f, 0f, 0f, paint.color)
            canvas.save()
            canvas.rotate(angle * (if (i % 2 == 0) 1f else -0.63f), cx, cy)
            canvas.drawOval(rect, paint)
            canvas.restore()
        }
        paint.clearShadowLayer()

        // Thin geometric cross-orbits.
        for (i in 0 until 5) {
            val r = base * (1.05f + i * 0.24f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 0.7f
            paint.color = if (state == State.ALERT) Color.argb(145, 255, 105, 85) else Color.argb(145, 255, 205, 75)
            canvas.save()
            canvas.rotate(-angle * 1.25f + i * 31f, cx, cy)
            canvas.drawOval(RectF(cx - r, cy - r * 0.22f, cx + r, cy + r * 0.22f), paint)
            canvas.restore()
        }

        // Moving particles.
        paint.style = Paint.Style.FILL
        particles.forEach { p ->
            p.phase += p.speed * intensity
            val rad = Math.toRadians((p.phase + angle * 0.8f).toDouble())
            val px = cx + cos(rad).toFloat() * p.orbit
            val py = cy + sin(rad).toFloat() * p.orbit * p.vertical
            paint.color = when (state) {
                State.ALERT -> Color.argb(190, 255, 75, 55)
                State.MISSION -> Color.argb(180, 255, 120, 42)
                else -> Color.argb(135 + Random.nextInt(100), 255, 185, 45)
            }
            canvas.drawCircle(px, py, p.size * intensity, paint)
        }

        // Central layered energy core.
        val corePulse = 1f + sin(pulse * 2.2f).toFloat() * 0.085f * intensity
        val core = base * 0.46f * corePulse
        paint.shader = RadialGradient(
            cx, cy, core * 2.8f,
            palette(),
            floatArrayOf(0f, 0.18f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.FILL
        paint.setShadowLayer(28f + intensity * 9f, 0f, 0f, when (state) {
            State.ALERT -> Color.rgb(230, 35, 35)
            State.MISSION -> Color.rgb(190, 35, 42)
            else -> Color.rgb(255, 125, 0)
        })
        canvas.drawCircle(cx, cy, core * 2.15f, paint)
        paint.clearShadowLayer()
        paint.shader = null

        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, core * 0.48f, paint)

        postInvalidateDelayed(16)
    }
}
