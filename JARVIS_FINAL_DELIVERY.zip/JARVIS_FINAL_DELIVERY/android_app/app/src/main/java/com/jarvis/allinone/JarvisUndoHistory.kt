package com.jarvis.allinone

object JarvisUndoHistory {
    data class Action(
        val id: Long,
        val description: String,
        val reversible: Boolean = true
    )

    private val history = ArrayDeque<Action>()
    private var nextId = 1L

    fun record(description: String, reversible: Boolean = true): Long {
        val id = nextId++
        history.addLast(Action(id, description, reversible))
        return id
    }

    fun latest(): Action? = history.lastOrNull()

    fun undoLatest(): Action? {
        val item = history.lastOrNull() ?: return null
        if (!item.reversible) return null
        history.removeLast()
        return item
    }

    fun all(): List<Action> = history.toList()
    fun clear() = history.clear()
}
