package com.jarvis.allinone

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.util.Calendar

/** Legitimate Android action adapters. Protected actions open OS-controlled UI. */
object JarvisAndroidActions {
    data class Result(val success: Boolean, val message: String)

    fun openDialer(context: Context, number: String): Result {
        val clean = number.trim()
        if (clean.isBlank()) return Result(false, "Phone number required")
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(clean)}")))
        return Result(true, "Dialer opened")
    }

    fun openSmsComposer(context: Context, number: String, message: String = ""): Result {
        val clean = number.trim()
        if (clean.isBlank()) return Result(false, "Phone number required")
        context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(clean)}")).apply { putExtra("sms_body", message) })
        return Result(true, "SMS composer opened")
    }

    fun openCalendarEvent(context: Context, title: String, startMillis: Long = System.currentTimeMillis(), durationMinutes: Int = 60): Result {
        context.startActivity(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).apply {
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startMillis + durationMinutes.coerceAtLeast(1) * 60_000L)
        })
        return Result(true, "Calendar event composer opened")
    }

    fun searchContacts(context: Context, query: String): List<String> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val result = ArrayList<String>()
        val projection = arrayOf(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts._ID)
        context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            projection,
            "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} LIKE ?",
            arrayOf("%${query.replace("%", "\\%").replace("_", "\\_")}%"),
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " COLLATE NOCASE LIMIT 20"
        )?.use { c -> while (c.moveToNext()) result += c.getString(0).orEmpty() }
        return result
    }

    fun openLocationSettings(context: Context): Result {
        context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        return Result(true, "Location settings opened")
    }

    fun openWifiSettings(context: Context): Result {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        return Result(true, "Wi-Fi settings opened")
    }

    fun openBluetoothSettings(context: Context): Result {
        context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        return Result(true, "Bluetooth settings opened")
    }

    fun openSoundSettings(context: Context): Result {
        context.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        return Result(true, "Sound settings opened")
    }

    fun openDisplaySettings(context: Context): Result {
        context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        return Result(true, "Display settings opened")
    }

    fun requestPermissions(activity: Activity, permissions: Array<String>, requestCode: Int) {
        val missing = permissions.filter { ContextCompat.checkSelfPermission(activity, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) activity.requestPermissions(missing.toTypedArray(), requestCode)
    }
}
