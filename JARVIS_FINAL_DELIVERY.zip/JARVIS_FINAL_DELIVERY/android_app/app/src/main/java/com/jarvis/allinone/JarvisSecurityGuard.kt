package com.jarvis.allinone

import android.content.Context

object JarvisSecurityGuard {

    enum class Decision {
        ALLOW,
        CONFIRM_REQUIRED,
        BLOCK
    }

    data class Result(
        val decision: Decision,
        val reason: String,
        val impact: String
    )

    fun check(
        context: Context,
        action: String,
        sensitive: Boolean = false,
        requiresPermission: Boolean = false,
        authorized: Boolean = true
    ): Result {

        if (action.isBlank()) {
            return Result(
                Decision.BLOCK,
                "Invalid or empty action.",
                "Nothing will be executed."
            )
        }

        if (JarvisEmergencyStop.isStopped(context)) {
            return Result(
                Decision.BLOCK,
                "Emergency STOP is active.",
                "All protected actions remain stopped."
            )
        }

        if (JarvisTaskRecovery.isCancellationRequested(context)) {
            return Result(
                Decision.BLOCK,
                "Task cancellation is active.",
                "The current action will not execute."
            )
        }

        if (!authorized) {
            return Result(
                Decision.BLOCK,
                "Authorization is required.",
                "JARVIS will not access or modify the protected resource."
            )
        }

        if (sensitive || requiresPermission) {
            return Result(
                Decision.CONFIRM_REQUIRED,
                "User permission is required before this action.",
                "JARVIS will wait for Allow or Not Allow."
            )
        }

        return Result(
            Decision.ALLOW,
            "Action passed the security guard.",
            "The action can proceed."
        )
    }

    fun status(context: Context): String {
        return when {
            JarvisEmergencyStop.isStopped(context) ->
                "BLOCKED: EMERGENCY STOP"

            JarvisTaskRecovery.isCancellationRequested(context) ->
                "BLOCKED: TASK CANCELLATION"

            !JarvisSecurityLab.isAuthorizedScope(context) ->
                "PROTECTED: AUTHORIZATION REQUIRED"

            else ->
                "SECURITY GUARD ACTIVE"
        }
    }
}
