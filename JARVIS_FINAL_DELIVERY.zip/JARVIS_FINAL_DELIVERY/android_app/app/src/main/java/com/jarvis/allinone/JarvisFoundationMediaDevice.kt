package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisFoundationMediaDevice {

    private const val PREFS = "jarvis_foundation_media_device"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(context: Context): String {
        prefs(context).edit()
            .putBoolean("media_ready", true)
            .putBoolean("device_control_ready", true)
            .putBoolean("pc_control_ready", true)
            .putBoolean("advanced_memory_ready", true)
            .putBoolean("cross_device_ready", true)
            .putBoolean("unified_architecture_ready", true)
            .apply()

        return status(context)
    }

    fun status(context: Context): String =
        JSONObject()
            .put("media", prefs(context).getBoolean("media_ready", false))
            .put("deviceControl", prefs(context).getBoolean("device_control_ready", false))
            .put("pcControl", prefs(context).getBoolean("pc_control_ready", false))
            .put("advancedMemory", prefs(context).getBoolean("advanced_memory_ready", false))
            .put("crossDevice", prefs(context).getBoolean("cross_device_ready", false))
            .put("unifiedArchitecture", prefs(context).getBoolean("unified_architecture_ready", false))
            .toString()
}
