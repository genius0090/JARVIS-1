package com.jarvis.allinone

object JarvisEventVoice {
    enum class Event { STARTUP,ACKNOWLEDGED,WORKING,DONE,FAILED,CONNECTED,DISCONNECTED,ALERT }

    private var enabled=true

    fun enable(){enabled=true}
    fun disable(){enabled=false}
    fun isEnabled()=enabled

    fun phrase(event:Event):String=when(event){
        Event.STARTUP->"JARVIS online."
        Event.ACKNOWLEDGED->"Understood."
        Event.WORKING->"Working on it."
        Event.DONE->"Task completed."
        Event.FAILED->"Task could not be completed."
        Event.CONNECTED->"Connection established."
        Event.DISCONNECTED->"Connection lost."
        Event.ALERT->"Attention required."
    }
}
