package com.jarvis.allinone

import android.content.Context

object JarvisActionConfirmation {

    data class Request(
        val action: String,
        val reason: String,
        val impact: String
    )

    fun request(
        context: Context,
        action: String,
        reason: String,
        impact: String,
        sensitive: Boolean = true,
        requiresPermission: Boolean = true,
        authorized: Boolean = true
    ): JarvisSecurityGuard.Result {

        return JarvisSecurityGuard.check(
            context = context,
            action = action,
            sensitive = sensitive,
            requiresPermission = requiresPermission,
            authorized = authorized
        )
    }

    fun allow(result: JarvisSecurityGuard.Result): Boolean {
        return result.decision ==
            JarvisSecurityGuard.Decision.CONFIRM_REQUIRED ||
            result.decision ==
            JarvisSecurityGuard.Decision.ALLOW
    }

    fun deny(): Boolean = false

    fun explanation(result: JarvisSecurityGuard.Result): String {
        return """
            DECISION: ${result.decision}
            REASON: ${result.reason}
            IMPACT: ${result.impact}
        """.trimIndent()
    }
}
