package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Self-repair registry. A repair is only reported successful when a registered
 * repair action actually executes successfully; approval alone never means fixed.
 */
object JarvisSelfRepair {
    data class Check(val id: String, val description: String, val repairable: Boolean = false)
    data class Result(val success: Boolean, val message: String, val repaired: Boolean = false, val verified: Boolean = false)

    private val checks = linkedMapOf<String, Check>()
    private val repairs = linkedMapOf<String, (Context) -> Boolean>()
    private val history = JSONArray()

    @Synchronized
    fun registerCheck(id: String, description: String, repairable: Boolean = false) {
        checks[id] = Check(id, description, repairable)
    }

    @Synchronized
    fun registerRepair(id: String, description: String, action: (Context) -> Boolean) {
        checks[id] = Check(id, description, true)
        repairs[id] = action
    }

    fun diagnose(): List<Check> = synchronized(this) { checks.values.toList() }

    @Synchronized
    fun repair(context: Context, id: String, approved: Boolean): Result {
        val check = checks[id] ?: return Result(false, "Unknown repair task")
        if (!approved) return Result(false, "Repair approval required")
        val action = repairs[id] ?: return Result(false, "No automatic repair action is registered; manual recovery required")

        val repaired = try { action(context) } catch (t: Throwable) { false }
        val item = JSONObject().put("id", id).put("time", System.currentTimeMillis())
            .put("status", if (repaired) "repair_executed" else "repair_failed")
        history.put(item)

        return if (repaired) {
            Result(true, "Repair executed for: ${check.description}", repaired = true, verified = true)
        } else {
            Result(false, "Repair action failed for: ${check.description}", repaired = false, verified = false)
        }
    }

    fun history(): String = synchronized(this) { history.toString() }
    fun status(): String = synchronized(this) { "Self-Repair: ${checks.size} checks, ${repairs.size} automatic repair actions" }
}
