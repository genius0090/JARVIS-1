package com.jarvis.allinone

import android.content.Context

object JarvisTaskProgressUI {
    fun progress(context: Context) = state("progress", "Task Progress", "TRACKING", "Live task progress and dependency state", true)
    fun running(context: Context) = state("running", "Task Running", "RUNNING", "Task execution is active", true)
    fun complete(context: Context) = state("complete", "Task Complete", "COMPLETE", "Task completion requires verified execution", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
