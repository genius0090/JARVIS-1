package com.jarvis.allinone

import kotlin.math.pow
import kotlin.math.sqrt

/** Deterministic local math evaluator; no remote code execution/eval is used. */
object JarvisMathEngine {
    fun calculate(operation: String, a: Double, b: Double): Double? = when (operation.lowercase()) {
        "add", "+" -> a + b
        "subtract", "-" -> a - b
        "multiply", "*" -> a * b
        "divide", "/" -> if (b != 0.0) a / b else null
        "power", "^" -> a.pow(b)
        else -> null
    }

    fun evaluate(expression: String): Double? = try {
        val parser = Parser(expression)
        val value = parser.parseExpression()
        if (parser.atEnd()) value else null
    } catch (_: Throwable) { null }

    private class Parser(private val source: String) {
        private var i = 0
        fun atEnd(): Boolean { skip(); return i >= source.length }
        private fun skip() { while (i < source.length && source[i].isWhitespace()) i++ }
        fun parseExpression(): Double { var x = parseTerm(); while (true) { skip(); if (i >= source.length) return x; when (source[i]) { '+' -> { i++; x += parseTerm() }; '-' -> { i++; x -= parseTerm() }; else -> return x } } }
        private fun parseTerm(): Double { var x = parsePower(); while (true) { skip(); if (i >= source.length) return x; when (source[i]) { '*' -> { i++; x *= parsePower() }; '/' -> { i++; val d=parsePower(); if(d==0.0) throw ArithmeticException("division by zero"); x/=d }; else -> return x } } }
        private fun parsePower(): Double { var x=parseUnary(); skip(); if(i<source.length && source[i]=='^'){i++; x=x.pow(parsePower())}; return x }
        private fun parseUnary(): Double { skip(); if(i<source.length && source[i]=='+'){i++;return parseUnary()}; if(i<source.length&&source[i]=='-'){i++;return -parseUnary()}; return parsePrimary() }
        private fun parsePrimary(): Double { skip(); if(i<source.length&&source[i]=='('){i++;val x=parseExpression();skip();if(i>=source.length||source[i]!=')')throw IllegalArgumentException("missing )");i++;return x}; val start=i; while(i<source.length&&(source[i].isDigit()||source[i]=='.'))i++; if(start==i) throw IllegalArgumentException("number expected"); return source.substring(start,i).toDouble() }
    }
}
