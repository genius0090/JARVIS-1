package com.jarvis.allinone

object JarvisScreenshotAction {
    data class Target(
        val description: String,
        val action: String,
        val confidence: Float
    )

    private var latest: Target? = null

    fun analyze(description: String, action: String, confidence: Float = 0.0f): Target {
        return Target(description, action, confidence.coerceIn(0f, 1f)).also {
            latest = it
        }
    }

    fun latest(): Target? = latest
    fun clear() { latest = null }
}
