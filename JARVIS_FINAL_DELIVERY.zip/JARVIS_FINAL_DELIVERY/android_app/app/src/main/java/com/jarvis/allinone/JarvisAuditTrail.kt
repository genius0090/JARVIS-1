package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisAuditTrail {
    data class Entry(val action: String, val result: String, val timestamp: Long = System.currentTimeMillis())

    private const val PREFS = "jarvis_audit_trail"
    private const val KEY_ENTRIES = "entries"
    private const val MAX_ENTRIES = 500
    private var appContext: Context? = null
    private val entries = ArrayDeque<Entry>()

    @Synchronized
    fun initialize(context: Context) {
        appContext = context.applicationContext
        if (entries.isNotEmpty()) return
        val raw = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.getString(KEY_ENTRIES, "[]") ?: "[]"
        runCatching {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                entries.addLast(Entry(o.optString("action"), o.optString("result"), o.optLong("timestamp")))
            }
        }
    }

    @Synchronized
    fun record(action: String, result: String) {
        val cleanAction = action.take(120)
        val cleanResult = result.take(500)
        if (entries.size >= MAX_ENTRIES) entries.removeFirst()
        entries.addLast(Entry(cleanAction, cleanResult))
        persist()
    }

    @Synchronized
    fun recent(limit: Int = 50): List<Entry> = entries.toList().takeLast(limit.coerceAtLeast(0))

    @Synchronized
    fun exportJson(): String = JSONArray(recent(MAX_ENTRIES).map {
        JSONObject().put("action", it.action).put("result", it.result).put("timestamp", it.timestamp)
    }).toString()

    @Synchronized
    fun clear() {
        entries.clear()
        appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.edit()?.remove(KEY_ENTRIES)?.apply()
    }

    private fun persist() {
        val context = appContext ?: return
        val array = JSONArray()
        entries.forEach { array.put(JSONObject().put("action", it.action).put("result", it.result).put("timestamp", it.timestamp)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ENTRIES, array.toString()).apply()
    }
}
