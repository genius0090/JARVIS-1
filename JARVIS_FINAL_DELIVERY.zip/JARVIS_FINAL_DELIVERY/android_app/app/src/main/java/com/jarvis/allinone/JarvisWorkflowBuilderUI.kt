package com.jarvis.allinone

import android.content.Context

object JarvisWorkflowBuilderUI {
    fun builder(context: Context) = state("workflow", "Workflow Builder", "READY", "Build multi-step task plans through the unified task router", true)
    fun steps(context: Context) = state("workflow_steps", "Workflow Steps", "READY", "Inspect dependencies, order and execution state", true)
    fun save(context: Context) = state("workflow_save", "Workflow Save", "READY", "Persist a workflow definition to JARVIS state", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
