package com.jarvis.allinone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class JarvisLockScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val launch = context.packageManager
            .getLaunchIntentForPackage(context.packageName)
        launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (launch != null) context.startActivity(launch)
    }
}
