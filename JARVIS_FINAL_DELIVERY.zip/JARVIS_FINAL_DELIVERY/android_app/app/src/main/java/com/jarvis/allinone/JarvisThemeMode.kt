package com.jarvis.allinone

import android.content.Context

object JarvisThemeMode {

    private const val PREFS = "jarvis_theme"
    private const val KEY_LIGHT = "light_mode"

    fun isLight(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_LIGHT, false)

    fun setLight(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_LIGHT, enabled)
            .apply()
    }

    fun toggle(context: Context): Boolean {
        val next = !isLight(context)
        setLight(context, next)
        return next
    }
}
