package com.jarvis.allinone

import android.content.Context

object JarvisLiveTheme {
    enum class Theme { JARVIS_DARK, JARVIS_LIGHT, MISSION }
    private const val PREFS = "jarvis_live_theme"
    private const val KEY_THEME = "theme"

    fun set(context: Context, themeValue: Theme) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_THEME, themeValue.name).apply()
    }

    fun current(context: Context): Theme = runCatching {
        Theme.valueOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_THEME, Theme.JARVIS_DARK.name) ?: Theme.JARVIS_DARK.name)
    }.getOrDefault(Theme.JARVIS_DARK)
}
