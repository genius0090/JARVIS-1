package com.jarvis.allinone

object JarvisDynamicSkillExpansion {
    data class Skill(val id:String,val name:String,val description:String)

    private val skills=mutableMapOf<String,Skill>()

    fun add(id:String,name:String,description:String){
        skills[id]=Skill(id,name,description)
    }

    fun remove(id:String){skills.remove(id)}
    fun find(id:String)=skills[id]
    fun all()=skills.values.toList()
}
