package com.jarvis.allinone

import android.content.Context

object JarvisDashboardUI {
    fun dashboard(context: Context) = state("dashboard", "JARVIS Dashboard", "LIVE", "Unified AI, task, device and capability status", true)
    fun deviceStatus(context: Context) = state("device", "Device Status", "LIVE", "Android device and service state", true)
    fun resourceStatus(context: Context) = state("resources", "Resource Status", "LIVE", "Storage, battery and runtime resources", true)
    fun taskStatus(context: Context) = state("tasks", "Task Status", "LIVE", "Current task/recovery/cancellation state", true)
    fun aiStatus(context: Context) = state("ai", "AI Status", "LIVE", "Local AI and central-core availability", true)
    private fun state(id: String, title: String, status: String, detail: String, actionable: Boolean) = JarvisUiState(id, title, status, detail, actionable)
}
