package com.jarvis.allinone

object JarvisPrivateAIModels {
    enum class Mode { LOCAL,ONLINE,AUTO }

    private var mode=Mode.AUTO

    fun setMode(value:Mode){mode=value}
    fun mode()=mode

    fun shouldUseLocal(sensitive:Boolean=false):Boolean=
        sensitive || mode==Mode.LOCAL
}
