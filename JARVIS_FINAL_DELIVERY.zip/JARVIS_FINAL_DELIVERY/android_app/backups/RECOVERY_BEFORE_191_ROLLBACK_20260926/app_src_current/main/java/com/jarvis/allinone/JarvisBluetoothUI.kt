package com.jarvis.allinone

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.widget.Toast

object JarvisBluetoothUI {
    fun status(): Boolean =
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true

    fun showStatus(context: Context) {
        Toast.makeText(
            context,
            if (status()) "Bluetooth: ON" else "Bluetooth: OFF",
            Toast.LENGTH_SHORT
        ).show()
    }
}
