package com.jarvis.allinone

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Typeface

class JarvisOrbService : Service() {

    private lateinit var windowManager: WindowManager
    private var orb: View? = null

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        startForeground(98, notification())

        if (Settings.canDrawOverlays(this)) {
            createOrb()
        }
    }

    private fun createOrb() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val view = TextView(this).apply {
            text = "✦"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(18, 35, 55))
                setStroke(3, Color.rgb(70, 190, 255))
            }
            elevation = 20f
        }

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val params = WindowManager.LayoutParams(
            72,
            72,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 300
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(v, params)
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (
                        kotlin.math.abs(event.rawX - downX) < 15 &&
                        kotlin.math.abs(event.rawY - downY) < 15
                    ) {
                        showHud()
                        v.animate()
                            .scaleX(1.15f)
                            .scaleY(1.15f)
                            .setDuration(100)
                            .withEndAction {
                                v.animate()
                                    .scaleX(1f)
                                    .scaleY(1f)
                                    .setDuration(100)
                                    .start()
                            }
                            .start()
                    }
                    true
                }

                else -> false
            }
        }

        windowManager.addView(view, params)
        orb = view
    }


    private fun showHud() {
        val hud = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 22, 28, 22)
            background = GradientDrawable().apply {
                cornerRadius = 28f
                setColor(Color.rgb(10, 18, 30))
                setStroke(2, Color.rgb(70, 190, 255))
            }
            elevation = 25f
        }

        val core = TextView(this).apply {
            text = "✦  JARVIS AI CORE  ✦"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(10, 10, 10, 18)
        }

        val status = TextView(this).apply {
            text = "READY • LISTENING"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(10, 6, 10, 18)
        }

        val tools = TextView(this).apply {
            text = "VOICE     WEB     MEMORY\n\nFILES     CAMERA     PC\n\nMORE"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(10, 10, 10, 10)
        }

        val close = TextView(this).apply {
            text = "CLOSE HUD"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(10, 18, 10, 6)
            setOnClickListener {
                hud.animate()
                    .alpha(0f)
                    .scaleX(0.7f)
                    .scaleY(0.7f)
                    .setDuration(180)
                    .withEndAction {
                        try {
                            windowManager.removeView(hud)
                        } catch (_: Exception) {}
                    }
                    .start()
            }
        }

        hud.addView(core)
        hud.addView(status)
        hud.addView(tools)
        hud.addView(close)

        val params = WindowManager.LayoutParams(
            700,
            560,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        windowManager.addView(hud, params)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "jarvis_orb",
            "JARVIS Floating Orb",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    private fun notification(): Notification {
        return Notification.Builder(this, "jarvis_orb")
            .setContentTitle("JARVIS")
            .setContentText("Floating Orb active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        orb?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        orb = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
