package com.jarvis.allinone

object JarvisVoiceRouter {
    enum class Voice { DEFAULT,ORIGINAL_JARVIS,CC_EXTERNAL,CUSTOM }

    private var active=Voice.DEFAULT

    fun setVoice(voice:Voice){active=voice}
    fun getVoice()=active

    fun status()="Voice: ${active.name}"
}
