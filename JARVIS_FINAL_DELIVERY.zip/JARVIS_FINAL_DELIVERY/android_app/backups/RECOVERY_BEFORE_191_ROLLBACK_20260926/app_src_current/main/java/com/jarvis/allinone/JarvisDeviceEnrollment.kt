package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object JarvisDeviceEnrollment {

    private const val PREFS = "jarvis_device_enrollment"

    private const val KEY_DEVICE_ID = "device_id"
    private const val KEY_ENROLLED = "enrolled"
    private const val KEY_TRUSTED = "trusted"
    private const val KEY_ENROLLED_AT = "enrolled_at"
    private const val KEY_OWNER_VERIFIED = "owner_verified"

    fun initialize(context: Context): JSONObject {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        if (!prefs.contains(KEY_DEVICE_ID)) {
            prefs.edit()
                .putString(KEY_DEVICE_ID, UUID.randomUUID().toString())
                .putBoolean(KEY_ENROLLED, false)
                .putBoolean(KEY_TRUSTED, false)
                .putBoolean(KEY_OWNER_VERIFIED, false)
                .apply()
        }

        return statusJson(context)
    }

    fun beginEnrollment(context: Context): JSONObject {
        initialize(context)

        return JSONObject()
            .put("success", true)
            .put("device_id", deviceId(context))
            .put("requires_owner_verification", true)
            .put("requires_trusted_state", true)
            .put("enrollment_complete", false)
    }

    fun completeEnrollment(
        context: Context,
        ownerVerified: Boolean
    ): JSONObject {
        initialize(context)

        if (!ownerVerified) {
            return JSONObject()
                .put("success", false)
                .put("reason", "owner_verification_required")
                .put("enrolled", false)
        }

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        prefs.edit()
            .putBoolean(KEY_OWNER_VERIFIED, true)
            .putBoolean(KEY_ENROLLED, true)
            .putBoolean(KEY_TRUSTED, true)
            .putLong(KEY_ENROLLED_AT, System.currentTimeMillis())
            .apply()

        return JSONObject()
            .put("success", true)
            .put("device_id", deviceId(context))
            .put("owner_verified", true)
            .put("enrolled", true)
            .put("trusted", true)
            .put("secure_session_ready", true)
    }

    fun revokeDevice(context: Context): JSONObject {
        initialize(context)

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        prefs.edit()
            .putBoolean(KEY_ENROLLED, false)
            .putBoolean(KEY_TRUSTED, false)
            .putBoolean(KEY_OWNER_VERIFIED, false)
            .apply()

        return JSONObject()
            .put("success", true)
            .put("revoked", true)
            .put("device_id", deviceId(context))
    }

    fun isEnrolled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENROLLED, false)
    }

    fun isTrusted(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_TRUSTED, false)
    }

    fun deviceId(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DEVICE_ID, "") ?: ""
    }

    fun statusJson(context: Context): JSONObject {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        return JSONObject()
            .put("device_id", prefs.getString(KEY_DEVICE_ID, ""))
            .put("enrolled", prefs.getBoolean(KEY_ENROLLED, false))
            .put("trusted", prefs.getBoolean(KEY_TRUSTED, false))
            .put("owner_verified", prefs.getBoolean(KEY_OWNER_VERIFIED, false))
            .put("enrolled_at", prefs.getLong(KEY_ENROLLED_AT, 0L))
            .put("secure_session_ready",
                prefs.getBoolean(KEY_ENROLLED, false) &&
                prefs.getBoolean(KEY_TRUSTED, false) &&
                prefs.getBoolean(KEY_OWNER_VERIFIED, false))
            .put("central_identity_boundary", "RESERVED")
            .put("memory_continuity_boundary", "RESERVED")
    }

    fun healthCheck(context: Context): Boolean {
        return try {
            initialize(context)
            deviceId(context).isNotBlank()
        } catch (_: Exception) {
            false
        }
    }
}
