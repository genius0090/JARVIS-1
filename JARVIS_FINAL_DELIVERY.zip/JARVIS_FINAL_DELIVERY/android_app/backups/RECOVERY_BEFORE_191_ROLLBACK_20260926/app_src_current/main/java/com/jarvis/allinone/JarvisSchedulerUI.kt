package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisSchedulerUI {
    fun scheduler(context: Context) =
        show(context, "JARVIS Scheduler UI Ready")

    fun create(context: Context) =
        show(context, "JARVIS Schedule Creation UI Ready")

    fun recurring(context: Context) =
        show(context, "JARVIS Recurring Schedule UI Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
