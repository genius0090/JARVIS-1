package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisMediaEditorUI {

    fun imageEditor(context: Context) =
        show(context, "JARVIS Image Editor UI Ready")

    fun videoEditor(context: Context) =
        show(context, "JARVIS Video Editor UI Ready")

    fun timeline(context: Context) =
        show(context, "JARVIS Video Timeline Ready")

    fun export(context: Context) =
        show(context, "JARVIS Media Export Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
