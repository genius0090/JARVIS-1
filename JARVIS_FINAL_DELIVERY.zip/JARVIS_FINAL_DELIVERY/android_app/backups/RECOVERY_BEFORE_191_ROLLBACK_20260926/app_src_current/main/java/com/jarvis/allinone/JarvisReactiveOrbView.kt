package com.jarvis.allinone

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class JarvisReactiveOrbView(context: Context) : View(context) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state = State.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particles = ArrayList<Particle>()
    private var angle = 0f
    private var pulse = 0f

    data class Particle(
        var x: Float,
        var y: Float,
        var speed: Float,
        var size: Float,
        var orbit: Float
    )

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)

        repeat(90) {
            particles += Particle(
                Random.nextFloat() * 360f,
                Random.nextFloat() * 360f,
                0.4f + Random.nextFloat() * 1.3f,
                1f + Random.nextFloat() * 3f,
                45f + Random.nextFloat() * 110f
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) * 0.22f

        val intensity = when (state) {
            State.IDLE -> 0.75f
            State.LISTENING -> 1.15f
            State.THINKING -> 1.45f
            State.SPEAKING -> 1.25f
        }

        pulse += 0.055f * intensity
        angle += when (state) {
            State.IDLE -> 0.45f
            State.LISTENING -> 0.9f
            State.THINKING -> 1.5f
            State.SPEAKING -> 1.1f
        }

        // Outer atmospheric glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, base * 2.6f,
            intArrayOf(
                Color.argb((125 * intensity).coerceAtMost(220f).toInt(), 255, 165, 20),
                Color.argb(45, 255, 105, 0),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.42f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base * 2.6f, paint)
        paint.shader = null

        // Energy rings
        for (i in 0 until 7) {
            val r = base * (0.65f + i * 0.20f)
            val rect = RectF(cx - r, cy - r * 0.72f, cx + r, cy + r * 0.72f)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (i % 2 == 0) 2.2f else 1.1f
            paint.color = Color.argb(
                (125 + i * 14).coerceAtMost(230),
                255,
                145 + (i * 12).coerceAtMost(100),
                15
            )
            paint.setShadowLayer(12f, 0f, 0f, Color.rgb(255, 130, 0))

            canvas.save()
            canvas.rotate(angle * (if (i % 2 == 0) 1f else -0.65f), cx, cy)
            canvas.drawOval(rect, paint)
            canvas.restore()
        }

        paint.clearShadowLayer()

        // Thin geometric orbit lines
        for (i in 0 until 4) {
            val r = base * (0.9f + i * 0.22f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 0.8f
            paint.color = Color.argb(155, 255, 190, 55)

            canvas.save()
            canvas.rotate(-angle * 1.4f + i * 35f, cx, cy)
            canvas.drawOval(
                RectF(cx - r, cy - r * 0.28f, cx + r, cy + r * 0.28f),
                paint
            )
            canvas.restore()
        }

        // Particles
        paint.style = Paint.Style.FILL
        particles.forEach { p ->
            p.x += p.speed * intensity
            if (p.x > 360f) p.x -= 360f

            val rad = Math.toRadians((p.x + angle * 0.7f).toDouble())
            val px = cx + cos(rad).toFloat() * p.orbit
            val py = cy + sin(rad).toFloat() * p.orbit * 0.72f

            paint.color = Color.argb(
                (130 + Random.nextInt(100)).coerceAtMost(255),
                255, 180, 35
            )
            canvas.drawCircle(px, py, p.size * intensity, paint)
        }

        // Central energy core
        val corePulse = 1f + sin(pulse * 2.2f).toFloat() * 0.08f * intensity
        val core = base * 0.34f * corePulse

        paint.shader = RadialGradient(
            cx, cy, core * 2.4f,
            intArrayOf(
                Color.WHITE,
                Color.rgb(255, 235, 125),
                Color.rgb(255, 170, 20),
                Color.argb(0, 255, 90, 0)
            ),
            floatArrayOf(0f, 0.22f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.FILL
        paint.setShadowLayer(28f, 0f, 0f, Color.rgb(255, 125, 0))
        canvas.drawCircle(cx, cy, core * 2.1f, paint)
        paint.clearShadowLayer()
        paint.shader = null

        // Core white-hot center
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, core * 0.42f, paint)

        postInvalidateDelayed(16)
    }
}
