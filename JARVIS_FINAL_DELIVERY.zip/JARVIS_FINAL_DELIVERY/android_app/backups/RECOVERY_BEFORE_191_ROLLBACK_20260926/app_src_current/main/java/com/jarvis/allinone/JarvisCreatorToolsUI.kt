package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisCreatorToolsUI {

    fun writing(context: Context) =
        show(context, "JARVIS Writing Tools UI Ready")

    fun thumbnail(context: Context) =
        show(context, "JARVIS Thumbnail Tools UI Ready")

    fun audio(context: Context) =
        show(context, "JARVIS Audio Tools UI Ready")

    fun video(context: Context) =
        show(context, "JARVIS Video Creator Tools UI Ready")

    fun export(context: Context) =
        show(context, "JARVIS Creator Export UI Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
