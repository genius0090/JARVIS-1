package com.jarvis.allinone

object JarvisAuditTrail {
    data class Entry(
        val action:String,
        val result:String,
        val timestamp:Long=System.currentTimeMillis()
    )

    private val entries=ArrayDeque<Entry>()

    fun record(action:String,result:String){
        if(entries.size>=500) entries.removeFirst()
        entries.addLast(Entry(action,result))
    }

    fun recent(limit:Int=50)=entries.toList().takeLast(limit)
    fun clear()=entries.clear()
}
