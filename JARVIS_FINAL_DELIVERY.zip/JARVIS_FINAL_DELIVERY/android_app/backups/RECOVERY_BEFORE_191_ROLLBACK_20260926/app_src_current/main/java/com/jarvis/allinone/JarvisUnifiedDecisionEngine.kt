package com.jarvis.allinone

import android.content.Context

object JarvisUnifiedDecisionEngine {

    enum class Decision {
        EXECUTE, CONFIRM, BLOCK
    }

    data class Result(
        val decision: Decision,
        val route: JarvisUnifiedActionRouter.Route,
        val reason: String
    )

    fun decide(
        context: Context,
        intent: String,
        sensitive: Boolean = false,
        highImpact: Boolean = false
    ): Result {

        if (JarvisEmergencyStop.isStopped(context)) {
            return Result(
                Decision.BLOCK,
                JarvisUnifiedActionRouter.Route.SECURITY,
                "Emergency STOP active"
            )
        }

        if (JarvisTaskRecovery.isCancellationRequested(context)) {
            return Result(
                Decision.BLOCK,
                JarvisUnifiedActionRouter.Route.SECURITY,
                "Task cancellation requested"
            )
        }

        val route = JarvisUnifiedActionRouter.route(
            intent,
            sensitive || highImpact
        )

        val analysis = JarvisSecurityAnalysis.analyze(
            context,
            intent,
            requiresAuthorization = sensitive || highImpact
        )

        if (!analysis.allowed) {
            return Result(
                Decision.BLOCK,
                JarvisUnifiedActionRouter.Route.SECURITY,
                analysis.reason
            )
        }

        val decision = when {
            highImpact || sensitive -> Decision.CONFIRM
            else -> Decision.EXECUTE
        }

        return Result(
            decision,
            route.route,
            route.reason
        )
    }
}
