package com.jarvis.allinone

object JarvisProactiveMonitor {
    data class Alert(val source:String,val message:String,val priority:Int)

    private val alerts=ArrayDeque<Alert>()

    fun report(source:String,message:String,priority:Int=1){
        if(alerts.size>=100) alerts.removeFirst()
        alerts.addLast(Alert(source,message,priority))
    }

    fun recent(limit:Int=20)=alerts.toList().takeLast(limit)
    fun clear()=alerts.clear()
}
