package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisTaskProgressUI {
    fun progress(context: Context) =
        show(context, "JARVIS Task Progress UI Ready")

    fun running(context: Context) =
        show(context, "JARVIS Task Running UI Ready")

    fun complete(context: Context) =
        show(context, "JARVIS Task Complete UI Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
