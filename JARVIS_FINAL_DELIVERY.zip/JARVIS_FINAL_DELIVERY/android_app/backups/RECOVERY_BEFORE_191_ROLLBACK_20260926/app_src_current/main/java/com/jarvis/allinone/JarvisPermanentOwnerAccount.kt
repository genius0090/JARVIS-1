package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * #199 PERMANENT OWNER ACCOUNT
 *
 * Persistent device-independent owner identity boundary.
 *
 * This layer stores identity/state metadata only.
 * Authentication credentials, passkeys, biometrics and recovery
 * verification are intentionally handled by #200-#203.
 *
 * No plaintext passwords, biometric data or secret recovery codes
 * are stored here.
 */
object JarvisPermanentOwnerAccount {

    private const val PREFS = "jarvis_permanent_owner_account"

    private const val KEY_OWNER_ID = "owner_id"
    private const val KEY_DISPLAY_NAME = "display_name"
    private const val KEY_CREATED_AT = "created_at"
    private const val KEY_UPDATED_AT = "updated_at"
    private const val KEY_ACCOUNT_ACTIVE = "account_active"
    private const val KEY_TRANSFER_ENABLED = "transfer_enabled"
    private const val KEY_RECOVERY_ENABLED = "recovery_enabled"
    private const val KEY_SECURITY_NOTIFICATIONS = "security_notifications"
    private const val KEY_ALIAS_LIST = "aliases"
    private const val KEY_PREFERRED_NAME = "preferred_name"
    private const val KEY_PREFERRED_LANGUAGE = "preferred_language"
    private const val KEY_VOICE_PREFERENCE = "voice_preference"
    private const val KEY_BEHAVIOR_PREFERENCE = "behavior_preference"
    private const val KEY_PERSONAL_NOTES = "personal_notes"

    data class Account(
        val ownerId: String,
        val displayName: String,
        val createdAt: Long,
        val updatedAt: Long,
        val active: Boolean,
        val transferEnabled: Boolean,
        val recoveryEnabled: Boolean,
        val securityNotifications: Boolean,
        val aliases: List<String>,
        val preferredName: String,
        val preferredLanguage: String,
        val voicePreference: String,
        val behaviorPreference: String,
        val personalNotes: String
    ) {
        fun toJson(): String =
            JSONObject()
                .put("ownerId", ownerId)
                .put("displayName", displayName)
                .put("createdAt", createdAt)
                .put("updatedAt", updatedAt)
                .put("active", active)
                .put("transferEnabled", transferEnabled)
                .put("recoveryEnabled", recoveryEnabled)
                .put("securityNotifications", securityNotifications)
                .put("aliases", JSONArray(aliases))
                .toString()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun initialize(context: Context): Account {
        val p = prefs(context)
        val now = System.currentTimeMillis()

        var ownerId = p.getString(KEY_OWNER_ID, null)

        if (ownerId.isNullOrBlank()) {
            ownerId = "OWNER-" + UUID.randomUUID().toString()
            p.edit()
                .putString(KEY_OWNER_ID, ownerId)
                .putString(KEY_DISPLAY_NAME, "JARVIS Owner")
                .putLong(KEY_CREATED_AT, now)
                .putLong(KEY_UPDATED_AT, now)
                .putBoolean(KEY_ACCOUNT_ACTIVE, true)
                .putBoolean(KEY_TRANSFER_ENABLED, false)
                .putBoolean(KEY_RECOVERY_ENABLED, true)
                .putBoolean(KEY_SECURITY_NOTIFICATIONS, true)
                .putString(KEY_ALIAS_LIST, JSONArray().toString())
                .apply()

            JarvisAuditTrail.record("OWNER_ACCOUNT_CREATED", "SUCCESS")
        } else {
            p.edit()
                .putLong(KEY_UPDATED_AT, now)
                .apply()
        }

        return account(context)
    }

    fun ownerId(context: Context): String =
        prefs(context).getString(KEY_OWNER_ID, "") ?: ""

    fun isInitialized(context: Context): Boolean =
        ownerId(context).isNotBlank()

    fun isActive(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ACCOUNT_ACTIVE, false)

    fun setDisplayName(context: Context, name: String): Boolean {
        val clean = name.trim()

        if (clean.isBlank() || clean.length > 80) return false

        prefs(context)
            .edit()
            .putString(KEY_DISPLAY_NAME, clean)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record("OWNER_DISPLAY_NAME_CHANGED", "SUCCESS")
        return true
    }

    fun displayName(context: Context): String =
        prefs(context).getString(KEY_DISPLAY_NAME, "JARVIS Owner")
            ?: "JARVIS Owner"


    fun preferredName(context: Context): String =
        prefs(context).getString(KEY_PREFERRED_NAME, "") ?: ""

    fun preferredLanguage(context: Context): String =
        prefs(context).getString(KEY_PREFERRED_LANGUAGE, "") ?: ""

    fun voicePreference(context: Context): String =
        prefs(context).getString(KEY_VOICE_PREFERENCE, "") ?: ""

    fun behaviorPreference(context: Context): String =
        prefs(context).getString(KEY_BEHAVIOR_PREFERENCE, "") ?: ""

    fun personalNotes(context: Context): String =
        prefs(context).getString(KEY_PERSONAL_NOTES, "") ?: ""

    private fun setProfileField(
        context: Context,
        key: String,
        value: String,
        auditEvent: String
    ): Boolean {
        val clean = value.trim()
        if (clean.length > 5000) return false

        prefs(context).edit()
            .putString(key, clean)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record(auditEvent, "SUCCESS")
        return true
    }

    fun setPreferredName(context: Context, value: String): Boolean =
        setProfileField(
            context,
            KEY_PREFERRED_NAME,
            value,
            "OWNER_PREFERRED_NAME_CHANGED"
        )

    fun setPreferredLanguage(context: Context, value: String): Boolean =
        setProfileField(
            context,
            KEY_PREFERRED_LANGUAGE,
            value,
            "OWNER_LANGUAGE_PREFERENCE_CHANGED"
        )

    fun setVoicePreference(context: Context, value: String): Boolean =
        setProfileField(
            context,
            KEY_VOICE_PREFERENCE,
            value,
            "OWNER_VOICE_PREFERENCE_CHANGED"
        )

    fun setBehaviorPreference(context: Context, value: String): Boolean =
        setProfileField(
            context,
            KEY_BEHAVIOR_PREFERENCE,
            value,
            "OWNER_BEHAVIOR_PREFERENCE_CHANGED"
        )

    fun setPersonalNotes(context: Context, value: String): Boolean =
        setProfileField(
            context,
            KEY_PERSONAL_NOTES,
            value,
            "OWNER_PERSONAL_NOTES_CHANGED"
        )

    
    @Synchronized
    fun configurePersonalOwnerProfile(context: Context): Boolean {
        if (!setDisplayName(context, "Deepak Kumar Meena")) return false

        val aliasesToAdd = listOf("Deepu", "Genius", "Boss")
        for (alias in aliasesToAdd) {
            if (!aliases(context).any { it.equals(alias, ignoreCase = true) }) {
                addAlias(context, alias)
            }
        }

        if (!setPreferredName(context, "Boss")) return false
        if (!setPreferredLanguage(context, "Hindi")) return false
        if (!setVoicePreference(context, "Custom")) return false
        if (!setBehaviorPreference(
                context,
                "Mix reply style; friendly + respectful tone; direct instructions preferred"
            )) return false

        if (!setPersonalNotes(
                context,
                "Owner is building JARVIS. Remember project/workflow preferences. " +
                "Also remember device and JARVIS preferences. " +
                "Never store passwords, OTPs, or private credentials."
            )) return false

        JarvisAuditTrail.record("PERSONAL_OWNER_PROFILE_CONFIGURED", "SUCCESS")
        return true
    }

fun personalProfileJson(context: Context): String =
        JSONObject()
            .put("ownerId", ownerId(context))
            .put("displayName", displayName(context))
            .put("preferredName", preferredName(context))
            .put("preferredLanguage", preferredLanguage(context))
            .put("voicePreference", voicePreference(context))
            .put("behaviorPreference", behaviorPreference(context))
            .put("personalNotes", personalNotes(context))
            .put("aliases", JSONArray(aliases(context)))
            .toString()

    @Synchronized
    fun addAlias(context: Context, alias: String): Boolean {
        val clean = alias.trim()

        if (clean.isBlank() || clean.length > 80) return false

        val aliases = aliases(context).toMutableList()

        if (aliases.any { it.equals(clean, ignoreCase = true) }) {
            return false
        }

        aliases.add(clean)

        prefs(context)
            .edit()
            .putString(KEY_ALIAS_LIST, JSONArray(aliases).toString())
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record("OWNER_ALIAS_ADDED", "SUCCESS")
        return true
    }

    @Synchronized
    fun removeAlias(context: Context, alias: String): Boolean {
        val aliases = aliases(context).toMutableList()
        val removed = aliases.removeAll {
            it.equals(alias.trim(), ignoreCase = true)
        }

        if (!removed) return false

        prefs(context)
            .edit()
            .putString(KEY_ALIAS_LIST, JSONArray(aliases).toString())
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record("OWNER_ALIAS_REMOVED", "SUCCESS")
        return true
    }

    fun aliases(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_ALIAS_LIST, "[]") ?: "[]"

        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val value = array.optString(i).trim()
                    if (value.isNotBlank()) add(value)
                }
            }
        }.getOrDefault(emptyList())
    }

    fun setRecoveryEnabled(context: Context, enabled: Boolean) {
        prefs(context)
            .edit()
            .putBoolean(KEY_RECOVERY_ENABLED, enabled)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record(
            "OWNER_RECOVERY_SETTING",
            if (enabled) "ENABLED" else "DISABLED"
        )
    }

    fun setSecurityNotifications(context: Context, enabled: Boolean) {
        prefs(context)
            .edit()
            .putBoolean(KEY_SECURITY_NOTIFICATIONS, enabled)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        JarvisAuditTrail.record(
            "OWNER_SECURITY_NOTIFICATIONS",
            if (enabled) "ENABLED" else "DISABLED"
        )
    }

    fun recoveryEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_RECOVERY_ENABLED, true)

    fun securityNotificationsEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SECURITY_NOTIFICATIONS, true)

    fun transferEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_TRANSFER_ENABLED, false)

    /**
     * Ownership transfer is intentionally disabled by default.
     * Actual protected transfer workflow belongs to later security steps.
     */
    fun setTransferEnabled(context: Context, enabled: Boolean): Boolean {
        if (enabled) {
            JarvisAuditTrail.record(
                "OWNER_TRANSFER_REQUEST",
                "PROTECTED_WORKFLOW_REQUIRED"
            )
            return false
        }

        prefs(context)
            .edit()
            .putBoolean(KEY_TRANSFER_ENABLED, false)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()

        return true
    }

    fun account(context: Context): Account {
        val p = prefs(context)

        return Account(
            ownerId = p.getString(KEY_OWNER_ID, "") ?: "",
            displayName = p.getString(KEY_DISPLAY_NAME, "JARVIS Owner")
                ?: "JARVIS Owner",
            createdAt = p.getLong(KEY_CREATED_AT, 0L),
            updatedAt = p.getLong(KEY_UPDATED_AT, 0L),
            active = p.getBoolean(KEY_ACCOUNT_ACTIVE, false),
            transferEnabled = p.getBoolean(KEY_TRANSFER_ENABLED, false),
            recoveryEnabled = p.getBoolean(KEY_RECOVERY_ENABLED, true),
            securityNotifications =
                p.getBoolean(KEY_SECURITY_NOTIFICATIONS, true),
            aliases = aliases(context),
        preferredName = preferredName(context),
        preferredLanguage = preferredLanguage(context),
        voicePreference = voicePreference(context),
        behaviorPreference = behaviorPreference(context),
        personalNotes = personalNotes(context)
        )
    }

    fun statusJson(context: Context): String =
        account(context).toJson()

    fun healthCheck(context: Context): Boolean {
        val account = account(context)

        return account.ownerId.isNotBlank() &&
                account.createdAt > 0L &&
                account.active
    }

    /**
     * Account deletion is deliberately not exposed as an immediate
     * destructive operation. #200+ will add protected verification,
     * warnings and final confirmation.
     */
    fun deletionProtectionStatus(): String =
        "PROTECTED_DELETE_WORKFLOW_REQUIRED"
}
