package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JarvisProfessionalCreation {

    private const val PREFS = "jarvis_professional_creation"
    private const val DOCUMENTS = "documents"
    private const val PRESENTATIONS = "presentations"
    private const val SPREADSHEETS = "spreadsheets"
    private const val WEBSITES = "websites"
    private const val QA = "qa"
    private const val SCIENCE = "science"
    private const val TEMPLATES = "templates"
    private const val CONTEXT = "context_selection"
    private const val ASYNC = "async_clarification"
    private const val ENVIRONMENTS = "environments"
    private const val DESIGN = "design"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun add(context: Context, key: String, value: JSONObject) {
        val old = prefs(context).getString(key, "[]") ?: "[]"
        val array = JSONArray(old)
        array.put(value)
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun createDocument(
        context: Context,
        title: String,
        content: String,
        style: String = "professional"
    ): String {
        val item = JSONObject()
            .put("title", title)
            .put("content", content)
            .put("style", style)
            .put("createdAt", System.currentTimeMillis())
        add(context, DOCUMENTS, item)
        return item.toString()
    }

    fun createPresentation(
        context: Context,
        title: String,
        slides: List<String>,
        style: String = "professional"
    ): String {
        val item = JSONObject()
            .put("title", title)
            .put("slides", JSONArray(slides))
            .put("style", style)
            .put("createdAt", System.currentTimeMillis())
        add(context, PRESENTATIONS, item)
        return item.toString()
    }

    fun createSpreadsheet(
        context: Context,
        name: String,
        columns: List<String>,
        rows: List<List<String>>
    ): String {
        val rowArray = JSONArray()
        rows.forEach { rowArray.put(JSONArray(it)) }

        val item = JSONObject()
            .put("name", name)
            .put("columns", JSONArray(columns))
            .put("rows", rowArray)
            .put("createdAt", System.currentTimeMillis())

        add(context, SPREADSHEETS, item)
        return item.toString()
    }

    fun createWebsite(
        context: Context,
        name: String,
        description: String,
        files: List<String>
    ): String {
        val item = JSONObject()
            .put("name", name)
            .put("description", description)
            .put("files", JSONArray(files))
            .put("hosting", "pending")
            .put("createdAt", System.currentTimeMillis())

        add(context, WEBSITES, item)
        return item.toString()
    }

    fun recordQualityCheck(
        context: Context,
        target: String,
        passed: Boolean,
        issues: List<String> = emptyList()
    ): String {
        val item = JSONObject()
            .put("target", target)
            .put("passed", passed)
            .put("issues", JSONArray(issues))
            .put("timestamp", System.currentTimeMillis())

        add(context, QA, item)
        return item.toString()
    }

    fun recordScientificTask(
        context: Context,
        software: String,
        task: String,
        status: String = "planned"
    ): String {
        val item = JSONObject()
            .put("software", software)
            .put("task", task)
            .put("status", status)
            .put("timestamp", System.currentTimeMillis())

        add(context, SCIENCE, item)
        return item.toString()
    }

    fun saveTemplate(
        context: Context,
        name: String,
        source: String,
        styleRules: List<String>
    ): String {
        val item = JSONObject()
            .put("name", name)
            .put("source", source)
            .put("styleRules", JSONArray(styleRules))
            .put("timestamp", System.currentTimeMillis())

        add(context, TEMPLATES, item)
        return item.toString()
    }

    fun selectRelevantContext(
        context: Context,
        task: String,
        selectedItems: List<String>
    ): String {
        val item = JSONObject()
            .put("task", task)
            .put("selectedItems", JSONArray(selectedItems))
            .put("timestamp", System.currentTimeMillis())

        add(context, CONTEXT, item)
        return item.toString()
    }

    fun recordAsyncClarification(
        context: Context,
        task: String,
        question: String,
        continueWork: Boolean = true
    ): String {
        val item = JSONObject()
            .put("task", task)
            .put("question", question)
            .put("continueWork", continueWork)
            .put("timestamp", System.currentTimeMillis())

        add(context, ASYNC, item)
        return item.toString()
    }

    fun learnEnvironment(
        context: Context,
        environment: String,
        observations: List<String>
    ): String {
        val item = JSONObject()
            .put("environment", environment)
            .put("observations", JSONArray(observations))
            .put("timestamp", System.currentTimeMillis())

        add(context, ENVIRONMENTS, item)
        return item.toString()
    }

    fun recordDesignJudgment(
        context: Context,
        target: String,
        criteria: List<String>,
        notes: String
    ): String {
        val item = JSONObject()
            .put("target", target)
            .put("criteria", JSONArray(criteria))
            .put("notes", notes)
            .put("timestamp", System.currentTimeMillis())

        add(context, DESIGN, item)
        return item.toString()
    }

    fun status(context: Context): String {
        val result = JSONObject()

        listOf(
            DOCUMENTS,
            PRESENTATIONS,
            SPREADSHEETS,
            WEBSITES,
            QA,
            SCIENCE,
            TEMPLATES,
            CONTEXT,
            ASYNC,
            ENVIRONMENTS,
            DESIGN
        ).forEach { key ->
            result.put(key, JSONArray(prefs(context).getString(key, "[]")))
        }

        return result.toString()
    }
}
