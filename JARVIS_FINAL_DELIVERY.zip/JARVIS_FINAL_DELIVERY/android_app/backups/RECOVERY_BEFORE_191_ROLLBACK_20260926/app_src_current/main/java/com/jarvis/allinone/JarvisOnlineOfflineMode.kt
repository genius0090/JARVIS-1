package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisOnlineOfflineMode {
    private const val PREFS = "jarvis_online_offline_mode"
    private const val KEY_MODE = "mode"

    private fun prefs(c: Context) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(c: Context) {
        if (!prefs(c).contains(KEY_MODE)) {
            prefs(c).edit().putString(KEY_MODE, "AUTO").apply()
        }
    }

    fun setMode(c: Context, mode: String): Boolean {
        val normalized = mode.uppercase()
        if (normalized !in setOf("AUTO", "ONLINE", "OFFLINE")) return false
        prefs(c).edit().putString(KEY_MODE, normalized).apply()
        return true
    }

    fun mode(c: Context): String =
        prefs(c).getString(KEY_MODE, "AUTO") ?: "AUTO"

    fun effectiveMode(c: Context, onlineAvailable: Boolean): String {
        return when (mode(c)) {
            "OFFLINE" -> "OFFLINE"
            "ONLINE" -> if (onlineAvailable) "ONLINE" else "OFFLINE_FALLBACK"
            else -> if (onlineAvailable) "ONLINE" else "OFFLINE"
        }
    }

    fun healthCheck(c: Context) = JSONObject()
        .put("online_offline_behavior", "IMPLEMENTED")
        .put("auto_mode", "ENABLED")
        .put("online_mode", "ENABLED")
        .put("offline_mode", "ENABLED")
        .put("offline_fallback", "ENABLED")
        .put("local_core_continuity", "ENABLED")
        .put("remote_transport", "RESERVED")
}