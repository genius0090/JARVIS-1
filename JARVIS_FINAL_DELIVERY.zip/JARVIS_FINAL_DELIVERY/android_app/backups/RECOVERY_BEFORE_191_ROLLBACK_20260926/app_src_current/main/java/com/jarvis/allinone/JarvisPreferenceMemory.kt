package com.jarvis.allinone

object JarvisPreferenceMemory {
    private val preferences=mutableMapOf<String,String>()

    fun set(key:String,value:String){preferences[key]=value}
    fun get(key:String)=preferences[key]
    fun all()=preferences.toMap()
    fun remove(key:String){preferences.remove(key)}
    fun clear(){preferences.clear()}
}
