package com.jarvis.allinone

object JarvisCapabilityExplanation {
    fun explain(capability:String):String {
        return if(JarvisCapabilityAwareness.isAvailable(capability))
            "$capability is currently available."
        else
            "$capability is not currently available."
    }
}
