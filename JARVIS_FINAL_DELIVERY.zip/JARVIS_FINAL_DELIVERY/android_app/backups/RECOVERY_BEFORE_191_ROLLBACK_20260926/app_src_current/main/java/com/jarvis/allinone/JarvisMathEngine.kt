package com.jarvis.allinone

object JarvisMathEngine {
    fun calculate(operation:String,a:Double,b:Double):Double?=when(operation.lowercase()){
        "add","+"->a+b
        "subtract","-"->a-b
        "multiply","*"->a*b
        "divide","/"->if(b!=0.0)a/b else null
        else->null
    }
}
