package com.jarvis.allinone

object JarvisOwnerVerification {
    private var verified=false

    fun verify(){verified=true}
    fun revoke(){verified=false}
    fun isVerified()=verified

    fun requireOwner():Boolean=verified
}
