package com.jarvis.allinone

object JarvisCapabilityAwareness {
    private val capabilities = linkedMapOf(
        "voice" to true,
        "memory" to true,
        "browser" to true,
        "files" to true,
        "storage" to true,
        "downloads" to true,
        "vision" to true,
        "pc_bridge" to true,
        "security" to true,
        "self_repair" to true,
        "planning" to true,
        "reasoning" to true
    )

    fun isAvailable(name: String): Boolean =
        capabilities[name.lowercase()] == true

    fun available(): List<String> =
        capabilities.filterValues { it }.keys.toList()

    fun explain(name: String): String =
        if (isAvailable(name))
            "$name capability is available"
        else
            "$name capability is not currently available"

    fun status(): String =
        "${available().size} capabilities available"
}
