package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisWorkflowBuilderUI {
    fun builder(context: Context) =
        show(context, "JARVIS Workflow Builder UI Ready")

    fun steps(context: Context) =
        show(context, "JARVIS Workflow Steps UI Ready")

    fun save(context: Context) =
        show(context, "JARVIS Workflow Save UI Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
