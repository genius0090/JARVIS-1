package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisDashboardUI {
    fun dashboard(context: Context) =
        show(context, "JARVIS Dashboard UI Ready")

    fun deviceStatus(context: Context) =
        show(context, "JARVIS Device Status UI Ready")

    fun resourceStatus(context: Context) =
        show(context, "JARVIS Resource Status UI Ready")

    fun taskStatus(context: Context) =
        show(context, "JARVIS Task Status UI Ready")

    fun aiStatus(context: Context) =
        show(context, "JARVIS AI Status UI Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
