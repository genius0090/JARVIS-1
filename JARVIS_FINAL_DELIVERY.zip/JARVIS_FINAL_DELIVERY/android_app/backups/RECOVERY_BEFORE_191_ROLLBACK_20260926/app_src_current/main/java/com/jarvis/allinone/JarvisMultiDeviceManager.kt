package com.jarvis.allinone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object JarvisMultiDeviceManager {
    private const val PREFS = "jarvis_multi_device"
    private const val KEY_DEVICES = "devices"

    private fun prefs(c: Context) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun initialize(c: Context) {
        if (!prefs(c).contains(KEY_DEVICES)) {
            prefs(c).edit()
                .putString(KEY_DEVICES, JSONArray().toString())
                .apply()
        }
    }

    fun registerDevice(
        c: Context,
        deviceId: String = UUID.randomUUID().toString(),
        deviceType: String = "ANDROID",
        deviceName: String = "JARVIS Device"
    ): Boolean {
        val arr = JSONArray(prefs(c).getString(KEY_DEVICES, "[]") ?: "[]")

        for (i in 0 until arr.length()) {
            if (arr.optJSONObject(i)?.optString("device_id") == deviceId) {
                return true
            }
        }

        arr.put(
            JSONObject()
                .put("device_id", deviceId)
                .put("device_type", deviceType)
                .put("device_name", deviceName)
                .put("trusted", false)
                .put("active", true)
                .put("last_seen", System.currentTimeMillis())
        )

        prefs(c).edit().putString(KEY_DEVICES, arr.toString()).apply()
        return true
    }

    fun setTrusted(c: Context, deviceId: String, ownerVerified: Boolean): Boolean {
        if (!ownerVerified) return false

        val arr = JSONArray(prefs(c).getString(KEY_DEVICES, "[]") ?: "[]")
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("device_id") == deviceId) {
                o.put("trusted", true)
                o.put("last_seen", System.currentTimeMillis())
            }
        }

        prefs(c).edit().putString(KEY_DEVICES, arr.toString()).apply()
        return true
    }

    fun devices(c: Context): JSONArray =
        JSONArray(prefs(c).getString(KEY_DEVICES, "[]") ?: "[]")

    fun healthCheck(c: Context) = JSONObject()
        .put("multi_device_jarvis", "IMPLEMENTED")
        .put("device_registry", "ENABLED")
        .put("trusted_device_boundary", "ENABLED")
        .put("device_state_continuity", "ENABLED")
        .put("cross_device_identity", "ENABLED")
        .put("remote_transport", "RESERVED")
}