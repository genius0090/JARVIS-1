package com.jarvis.allinone

object JarvisYouTubeControl {
    enum class Command {
        PLAY, PAUSE, NEXT, PREVIOUS, STOP
    }

    private var lastCommand: Command? = null

    fun issue(command: Command): Command {
        lastCommand = command
        return command
    }

    fun lastCommand(): Command? = lastCommand

    fun status(): String =
        lastCommand?.let { "Last media command: ${it.name}" }
            ?: "No media command"
}
