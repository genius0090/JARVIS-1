package com.jarvis.allinone

object JarvisLiveTheme {
    enum class Theme { JARVIS_DARK,JARVIS_LIGHT,MISSION }

    private var theme=Theme.JARVIS_DARK

    fun set(themeValue:Theme){theme=themeValue}
    fun current()=theme
}
