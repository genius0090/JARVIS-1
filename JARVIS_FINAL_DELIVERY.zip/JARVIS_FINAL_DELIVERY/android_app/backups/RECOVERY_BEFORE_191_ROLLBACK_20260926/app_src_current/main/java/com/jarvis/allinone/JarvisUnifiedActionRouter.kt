package com.jarvis.allinone

object JarvisUnifiedActionRouter {
    enum class Route {
        CHAT, VOICE, MEMORY, FILES, STORAGE, BROWSER,
        VISION, PC, SYSTEM, MEDIA, DATA, PLANNING,
        SECURITY, REPAIR, UNKNOWN
    }

    data class Decision(
        val route: Route,
        val reason: String,
        val requiresApproval: Boolean = false
    )

    fun route(
        intent: String,
        sensitive: Boolean = false
    ): Decision {
        val text = intent.lowercase()

        val route = when {
            text.contains("file") || text.contains("folder") ->
                Route.FILES
            text.contains("storage") || text.contains("download") ->
                Route.STORAGE
            text.contains("website") || text.contains("browser") ||
                text.contains("search") ->
                Route.BROWSER
            text.contains("camera") || text.contains("image") ||
                text.contains("object") ->
                Route.VISION
            text.contains("pc") || text.contains("computer") ->
                Route.PC
            text.contains("battery") || text.contains("settings") ||
                text.contains("device") ->
                Route.SYSTEM
            text.contains("video") || text.contains("audio") ||
                text.contains("youtube") ->
                Route.MEDIA
            text.contains("data") || text.contains("csv") ||
                text.contains("spreadsheet") ->
                Route.DATA
            text.contains("plan") || text.contains("steps") ->
                Route.PLANNING
            text.contains("memory") || text.contains("remember") ->
                Route.MEMORY
            text.contains("security") || text.contains("permission") ->
                Route.SECURITY
            text.contains("repair") || text.contains("fix") ->
                Route.REPAIR
            else -> Route.CHAT
        }

        return Decision(
            route = route,
            reason = "Context-based capability routing",
            requiresApproval = sensitive
        )
    }
}
