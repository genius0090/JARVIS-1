package com.jarvis.allinone

import android.content.Context
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.widget.Toast

object JarvisScreenUnderstanding {

    var mediaProjection: MediaProjection? = null

    fun captureReady(): Boolean = mediaProjection != null

    fun screenState(context: Context): String {
        return if (mediaProjection != null)
            "SCREEN_CAPTURE_READY"
        else
            "SCREEN_CAPTURE_PERMISSION_REQUIRED"
    }

    fun visibleScreenUnderstanding(context: Context) {
        Toast.makeText(
            context,
            "JARVIS Screen Understanding Ready",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun ocrFoundation(context: Context) {
        Toast.makeText(
            context,
            "JARVIS OCR Foundation Ready",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun screenshot(bitmap: Bitmap?) {
        if (bitmap == null) return
    }

    fun screenRecordingReady(): Boolean =
        mediaProjection != null
}
