package com.jarvis.allinone

import android.content.Context
import android.widget.Toast

object JarvisOfficeUI {

    fun documents(context: Context) =
        show(context, "JARVIS Documents UI Ready")

    fun spreadsheets(context: Context) =
        show(context, "JARVIS Spreadsheet UI Ready")

    fun presentations(context: Context) =
        show(context, "JARVIS Presentation UI Ready")

    private fun show(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
