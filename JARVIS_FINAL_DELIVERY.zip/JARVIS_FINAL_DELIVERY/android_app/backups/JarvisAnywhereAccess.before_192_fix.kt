package com.jarvis.allinone

import android.content.Context
import org.json.JSONObject

object JarvisAnywhereAccess {

    private const val PREFS = "jarvis_anywhere_access"

    private const val KEY_ENABLED = "enabled"
    private const val KEY_CORE_BOUND = "core_bound"
    private const val KEY_OWNER_BOUND = "owner_bound"
    private const val KEY_MEMORY_BOUND = "memory_bound"

    fun initialize(context: Context): JSONObject {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        if (!prefs.contains(KEY_ENABLED)) {
            prefs.edit()
                .putBoolean(KEY_ENABLED, true)
                .putBoolean(KEY_CORE_BOUND, true)
                .putBoolean(KEY_OWNER_BOUND, true)
                .putBoolean(KEY_MEMORY_BOUND, true)
                .apply()
        }

        return statusJson(context)
    }

    fun canAccess(
        context: Context,
        ownerVerified: Boolean,
        deviceEnrolled: Boolean
    ): Boolean {
        initialize(context)

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        return prefs.getBoolean(KEY_ENABLED, false) &&
                prefs.getBoolean(KEY_CORE_BOUND, false) &&
                prefs.getBoolean(KEY_OWNER_BOUND, false) &&
                prefs.getBoolean(KEY_MEMORY_BOUND, false) &&
                ownerVerified &&
                deviceEnrolled
    }

    fun accessState(
        context: Context,
        ownerVerified: Boolean,
        deviceEnrolled: Boolean
    ): JSONObject {
        initialize(context)

        val allowed = canAccess(
            context,
            ownerVerified,
            deviceEnrolled
        )

        return JSONObject()
            .put("access_allowed", allowed)
            .put("owner_verified", ownerVerified)
            .put("device_enrolled", deviceEnrolled)
            .put("same_core", true)
            .put("same_owner_identity", true)
            .put("same_memory_boundary", true)
            .put("cross_device_access", true)
            .put("browser_boundary", "RESERVED")
            .put("laptop_boundary", "RESERVED")
            .put("desktop_boundary", "RESERVED")
            .put("tablet_boundary", "RESERVED")
    }

    fun disable(context: Context): JSONObject {
        initialize(context)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, false)
            .apply()

        return statusJson(context)
    }

    fun enable(context: Context): JSONObject {
        initialize(context)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, true)
            .apply()

        return statusJson(context)
    }

    fun statusJson(context: Context): JSONObject {
        initialize(context)

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        return JSONObject()
            .put("enabled", prefs.getBoolean(KEY_ENABLED, false))
            .put("core_bound", prefs.getBoolean(KEY_CORE_BOUND, false))
            .put("owner_bound", prefs.getBoolean(KEY_OWNER_BOUND, false))
            .put("memory_bound", prefs.getBoolean(KEY_MEMORY_BOUND, false))
            .put("same_jarvis_boundary", true)
            .put("android", true)
            .put("tablet", true)
            .put("laptop", true)
            .put("desktop", true)
            .put("browser", true)
            .put("remote_transport", "RESERVED")
            .put("central_backend", "RESERVED")
    }

    fun healthCheck(context: Context): Boolean {
        return try {
            val status = initialize(context)

            status.optBoolean("enabled", false) &&
                    status.optBoolean("core_bound", false) &&
                    status.optBoolean("owner_bound", false) &&
                    status.optBoolean("memory_bound", false)
        } catch (_: Exception) {
            false
        }
    }
}
