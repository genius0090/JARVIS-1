package com.jarvis.allinone

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val bg = Color.rgb(5, 10, 18)
    private val panel = Color.rgb(13, 22, 34)
    private val cyan = Color.rgb(0, 210, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 170, 185)

    
    private fun startJarvisOrbService() {
        try {
            if (Settings.canDrawOverlays(this)) {
                val intent = android.content.Intent(this, JarvisOrbService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
                android.util.Log.i("JARVIS_ORB", "Floating Orb service started")
            } else {
                android.util.Log.i("JARVIS_ORB", "Overlay permission not granted; Orb not started")
            }
        } catch (e: Throwable) {
            android.util.Log.e("JARVIS_ORB", "Orb service start failed", e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startJarvisOrbService()

        var checkpoint = "START"
        try {
        // #198 Permanent JARVIS Core bootstrap.
        // Existing foundations remain intact; this adds the persistent
        // core boundary and safe local fallback.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisPermanentCore.initialize")
            checkpoint = "JarvisPermanentCore.initialize"
        JarvisPermanentCore.initialize(this)

        // #199 Permanent Owner Account bootstrap.
        // Authentication and verification are intentionally handled
        // by the dedicated #200-#203 security layers.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisPermanentOwnerAccount.initialize")
            JarvisPermanentOwnerAccount.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisPermanentOwnerAccount.configurePersonalOwnerProfile")
            JarvisPermanentOwnerAccount.configurePersonalOwnerProfile(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisCentralMemory.remember")
            JarvisCentralMemory.remember(
                this,
                "owner_profile",
                JarvisPermanentOwnerAccount.personalProfileJson(this)
            )


        // #200 Owner Authentication bootstrap.
        // Concrete identity verification is supplied by #201-#203.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisOwnerAuthentication.initialize")
            JarvisOwnerAuthentication.initialize(this)

        // #201 Multiple Owner Identity Methods registry.
        // Actual platform verification is connected in #203.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisOwnerIdentityMethods.initialize")
            checkpoint = "JarvisOwnerIdentityMethods.initialize"
        JarvisOwnerIdentityMethods.initialize(this)

        // #202 Flexible verification selection.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisFlexibleVerification.select")
            checkpoint = "JarvisFlexibleVerification.select"
        JarvisFlexibleVerification.select(this)

        // #203 Android owner authentication capability bootstrap.
        // The actual prompt is invoked only when owner verification
        // is explicitly requested.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisAndroidOwnerAuthentication.capability")
            checkpoint = "JarvisAndroidOwnerAuthentication.capability"
        JarvisAndroidOwnerAuthentication.capability(this)

        // #204 Centralized JARVIS Memory foundation.
        // Central synchronization is added in later workflow stages.
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisCentralMemory.initialize")
            checkpoint = "JarvisCentralMemory.initialize"
        JarvisCentralMemory.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisBackupContinuity.initialize")
            checkpoint = "JarvisBackupContinuity.initialize"
        JarvisBackupContinuity.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisDeviceEnrollment.initialize")
            checkpoint = "JarvisDeviceEnrollment.initialize"
        JarvisDeviceEnrollment.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisAnywhereAccess.initialize")
            checkpoint = "JarvisAnywhereAccess.initialize"
        JarvisAnywhereAccess.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisLostPhoneRecovery.initialize")
            checkpoint = "JarvisLostPhoneRecovery.initialize"
        JarvisLostPhoneRecovery.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisDestroyedPhoneRecovery.initialize")
            checkpoint = "JarvisDestroyedPhoneRecovery.initialize"
        JarvisDestroyedPhoneRecovery.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisDeviceRevocation.initialize")
            checkpoint = "JarvisDeviceRevocation.initialize"
        JarvisDeviceRevocation.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisTrustedDeviceManager.initialize")
            checkpoint = "JarvisTrustedDeviceManager.initialize"
        JarvisTrustedDeviceManager.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisSessionManager.initialize")
            checkpoint = "JarvisSessionManager.initialize"
        JarvisSessionManager.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisRecoverySystem.initialize")
            checkpoint = "JarvisRecoverySystem.initialize"
        JarvisRecoverySystem.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisRecoveryCredentialProtection.initialize")
            checkpoint = "JarvisRecoveryCredentialProtection.initialize"
        JarvisRecoveryCredentialProtection.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisSensitiveActionAuth.initialize")
            checkpoint = "JarvisSensitiveActionAuth.initialize"
        JarvisSensitiveActionAuth.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisOwnerAuthorization.initialize")
            checkpoint = "JarvisOwnerAuthorization.initialize"
        JarvisOwnerAuthorization.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisSecurityIntegration.initialize")
            checkpoint = "JarvisSecurityIntegration.initialize"
        JarvisSecurityIntegration.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisSecureCoreCommunication.initialize")
            checkpoint = "JarvisSecureCoreCommunication.initialize"
        JarvisSecureCoreCommunication.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisCoreApiAccessControl.initialize")
            checkpoint = "JarvisCoreApiAccessControl.initialize"
        JarvisCoreApiAccessControl.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisOwnerSecurityDashboard.initialize")
            checkpoint = "JarvisOwnerSecurityDashboard.initialize"
        JarvisOwnerSecurityDashboard.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisEmergencyOwnerControls.initialize")
            checkpoint = "JarvisEmergencyOwnerControls.initialize"
        JarvisEmergencyOwnerControls.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisDataClearProtection.initialize")
            checkpoint = "JarvisDataClearProtection.initialize"
        JarvisDataClearProtection.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisApkUpdateContinuity.initialize")
            checkpoint = "JarvisApkUpdateContinuity.initialize"
        JarvisApkUpdateContinuity.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisMultiDeviceManager.initialize")
            checkpoint = "JarvisMultiDeviceManager.initialize"
        JarvisMultiDeviceManager.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisOnlineOfflineMode.initialize")
            checkpoint = "JarvisOnlineOfflineMode.initialize"
        JarvisOnlineOfflineMode.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisCoreFailureProtection.initialize")
            checkpoint = "JarvisCoreFailureProtection.initialize"
        JarvisCoreFailureProtection.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisRecoveryFailureProtection.initialize")
            checkpoint = "JarvisRecoveryFailureProtection.initialize"
        JarvisRecoveryFailureProtection.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisEndToEndOwnerRecovery.initialize")
            checkpoint = "JarvisEndToEndOwnerRecovery.initialize"
        JarvisEndToEndOwnerRecovery.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisAnywhereAccessVerification.initialize")
            checkpoint = "JarvisAnywhereAccessVerification.initialize"
        JarvisAnywhereAccessVerification.initialize(this)
            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE JarvisDeviceIndependentCore.initialize")
            checkpoint = "JarvisDeviceIndependentCore.initialize"
        JarvisDeviceIndependentCore.initialize(this)

            android.util.Log.e("JARVIS_CHECKPOINT", "BEFORE UI")
        } catch (e: Throwable) {
            android.widget.Toast.makeText(this, "JARVIS STARTUP ERROR at $checkpoint: ${e.javaClass.simpleName}: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            android.util.Log.e("JARVIS_STARTUP", "Startup initialization failed", e)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            alpha = 0.98f
            setPadding(22, 24, 22, 18)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 28f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
        }

        val online = TextView(this).apply {
            text = "   ● ONLINE"
            textSize = 13f
            setTextColor(Color.rgb(80, 220, 150))
        }

        header.addView(title)
        header.addView(online)
        root.addView(header)

        val core = TextView(this).apply {
            text = "◉\n\nJARVIS AI CORE\n\nReady for your command"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setBackgroundColor(panel)
            elevation = 8f
            setPadding(20, 50, 20, 50)
        }

        root.addView(
            core,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply {
                setMargins(0, 20, 0, 16)
            }
        )

        val input = EditText(this).apply {
            hint = "Ask JARVIS anything..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            setPadding(18, 14, 18, 14)
            setBackgroundColor(panel)
            elevation = 8f
        }

        root.addView(
            input,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val commandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val voice = Button(this).apply {
            text = "🎙 Voice"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "Voice interaction ready",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val send = Button(this).apply {
            text = "➤ Send"
            setOnClickListener {
                val command = input.text.toString().trim()
                if (command.isNotEmpty()) {                    val handled =
                        JarvisIntelligenceEngine.handleCommand(this@MainActivity, command) ||
                        JarvisDownloadManager.handleCommand(this@MainActivity, command) ||
                        JarvisBrowserManager.handleCommand(this@MainActivity, command)

                    core.text = if (handled) {
                        "◉\\n\\nJARVIS AI CORE\\n\\nBROWSER\nCOMMAND EXECUTED"
                    } else {
                        "◉\\n\\nJARVIS AI CORE\\n\\nUNDERSTANDING\nSELECTING TOOL\nREADY"
                    }
                }
            }
        }

        commandRow.addView(
            voice,
            LinearLayout.LayoutParams(0, 60, 1f)
        )
        commandRow.addView(
            send,
            LinearLayout.LayoutParams(0, 60, 1f)
        )

        root.addView(commandRow)

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        fun toolButton(label: String, action: () -> Unit): Button {
            return Button(this).apply {
                text = label
                textSize = 11f
                setOnClickListener { action() }
            }
        }

        tools.addView(toolButton("History") {
            Toast.makeText(this, "Conversation History", Toast.LENGTH_SHORT).show()
        })

        tools.addView(toolButton("Memory") {
            Toast.makeText(this, "JARVIS Memory", Toast.LENGTH_SHORT).show()
        })

        tools.addView(toolButton("Tools") {
            Toast.makeText(this, "Unified Tools", Toast.LENGTH_SHORT).show()
        })

        tools.addView(toolButton("Settings") {
            showSettings()
        })

        root.addView(tools)


        val extensions = TextView(this).apply {
            text = "JARVIS UI EXTENSIONS\nDashboard • Listening • Voice • Health • Resources • Models"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(8, 14, 8, 8)
        }
        root.addView(extensions)

            checkpoint = "JarvisNotificationCenter.setup"
        JarvisNotificationCenter.setup(this)

        setContentView(root)

        // A2 Browser Interaction: route browser/search commands automatically.
        input.setOnEditorActionListener { _, _, _ ->
            val command = input.text.toString().trim()
            if (command.isNotEmpty()) {
            checkpoint = "JarvisBrowserManager.handleCommand"
                JarvisBrowserManager.handleCommand(this, command)
            }
            false
        }
    }

    private fun showSettings() {
        val settings = arrayOf(
            "Voice Selection",
            "External CC Voice",
            "Original / Default JARVIS Voice",
            "Voice Language",
            "Voice Speed",
            "Voice Pitch",
            "Voice Volume",
            "Memory",
            "Security & Permissions"
        )

        AlertDialog.Builder(this)
            .setTitle("JARVIS Settings")
            .setItems(settings) { _, which ->
                Toast.makeText(
                    this,
                    settings[which] + " selected",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
